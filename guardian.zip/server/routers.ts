import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";

const reportInput = z.object({
  clientRequestId: z.string().min(8).max(64),
  category: z.string().min(1).max(64),
  severity: z.enum(["Low", "Medium", "High"]),
  description: z.string().min(1).max(4000),
  locationText: z.string().min(1).max(255),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  accuracy: z.number().nonnegative().max(100000).optional(),
  photoUri: z.string().max(2000).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  support: router({
    status: publicProcedure.query(() => ({
      enabled: Boolean(process.env.GUARDIAN_STRIPE_SECRET_KEY && process.env.GUARDIAN_STRIPE_WEBHOOK_SECRET && process.env.EXPO_PUBLIC_GUARDIAN_STRIPE_PUBLISHABLE_KEY),
      mode: "test" as const,
      message: "Optional support payments are not enabled until Stripe test credentials are configured.",
    })),
  }),
  reports: router({
    categorize: publicProcedure.input(z.object({ description: z.string().min(3).max(4000), photoDataUrl: z.string().max(8_000_000).optional() })).mutation(async ({ input }) => {
      const userContent: Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string; detail?: "auto" | "low" | "high" } }> = [{ type: "text", text: `Classify this non-emergency civic hazard description. Do not claim certainty, do not diagnose danger, and use only the allowed categories. Description: ${input.description}` }];
      if (input.photoDataUrl) userContent.push({ type: "image_url", image_url: { url: input.photoDataUrl, detail: "low" } });
      const response = await invokeLLM({
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: "You are Guardian's cautious civic-hazard classifier. Choose exactly one category from: Pothole, Flooding, Ice / snow, Streetlight, Traffic concern, Other. Suggest a severity from Low, Medium, High, but never override the user's safety judgment. If the description suggests immediate danger, include a short instruction to call 911. Return JSON only." },
          { role: "user", content: userContent },
        ],
        response_format: { type: "json_schema", json_schema: { name: "guardian_hazard_classification", strict: true, schema: { type: "object", properties: { category: { type: "string", enum: ["Pothole", "Flooding", "Ice / snow", "Streetlight", "Traffic concern", "Other"] }, suggestedSeverity: { type: "string", enum: ["Low", "Medium", "High"] }, confidence: { type: "number", minimum: 0, maximum: 1 }, rationale: { type: "string", maxLength: 240 }, safetyNote: { type: "string", maxLength: 240 } }, required: ["category", "suggestedSeverity", "confidence", "rationale", "safetyNote"], additionalProperties: false } } },
        maxTokens: 400,
      });
      const content = response.choices[0]?.message?.content;
      if (typeof content !== "string") throw new Error("AI categorization returned no result");
      return JSON.parse(content) as { category: string; suggestedSeverity: "Low" | "Medium" | "High"; confidence: number; rationale: string; safetyNote: string };
    }),
    create: publicProcedure.input(reportInput).mutation(async ({ ctx, input }) => {
      const report = await db.createOrGetHazardReport({
        clientRequestId: input.clientRequestId,
        userId: ctx.user?.id ?? null,
        category: input.category,
        severity: input.severity,
        description: input.description,
        locationText: input.locationText,
        latitude: input.latitude?.toFixed(7),
        longitude: input.longitude?.toFixed(7),
        accuracy: input.accuracy?.toFixed(2),
        photoUri: input.photoUri ?? null,
        source: "mobile",
        status: "received",
      });
      return {
        reportId: report.id,
        clientRequestId: report.clientRequestId,
        status: report.status,
        receivedAt: report.createdAt,
      };
    }),
    getByClientRequestId: publicProcedure.input(z.object({ clientRequestId: z.string().min(8).max(64) })).query(async ({ input }) => {
      const report = await db.getHazardReportByClientRequestId(input.clientRequestId);
      if (!report) return null;
      return { reportId: report.id, clientRequestId: report.clientRequestId, status: report.status, receivedAt: report.createdAt, updatedAt: report.updatedAt };
    }),
    mine: protectedProcedure.query(async ({ ctx }) => {
      const reports = await db.listHazardReportsForUser(ctx.user.id);
      return reports.map((report) => ({ reportId: report.id, clientRequestId: report.clientRequestId, category: report.category, severity: report.severity, status: report.status, createdAt: report.createdAt, updatedAt: report.updatedAt }));
    }),
    exportData: protectedProcedure.query(async ({ ctx }) => {
      const reports = await db.listHazardReportsForUser(ctx.user.id);
      return {
        exportedAt: new Date(),
        account: { userId: ctx.user.id, email: ctx.user.email ?? null },
        reports: reports.map((report) => ({
          reportId: report.id,
          clientRequestId: report.clientRequestId,
          category: report.category,
          severity: report.severity,
          description: report.description,
          locationText: report.locationText,
          latitude: report.latitude,
          longitude: report.longitude,
          accuracy: report.accuracy,
          status: report.status,
          source: report.source,
          createdAt: report.createdAt,
          updatedAt: report.updatedAt,
          hasPhotoAttachment: Boolean(report.photoUri),
        })),
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
