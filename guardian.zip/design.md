# Guardian Mobile Interface Design

## Product direction

Guardian is a calm, safety-first civic utility for Indianapolis residents. The interface is designed for portrait orientation, one-handed use, fast comprehension, large touch targets, and reliable recovery when location or network access is unavailable. It is not a replacement for 911 or official dispatch.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Home / Safety Hub | Emergency shortcut, safety status, quick actions, current alert summary, offline indicator, trusted resources |
| Emergency Mode | High-contrast call-911 action, emergency disclaimer, location status, approved first-aid/resource links |
| Report Hazard | Guided category selection, severity, description, location confirmation, optional photo, submit receipt |
| Report Confirmation | Report ID, received state, next steps, view history, return home |
| Alerts | Severity-sorted list of official or curated public-safety alerts with freshness and source labels |
| Alert Detail | Alert body, affected area, issued/updated time, recommended actions, official source link |
| Resources | 911, 311, shelters, warming centers, transportation, accessibility and city-service links |
| Profile / Settings | Notification preferences, location/privacy explanations, accessibility options, report history |
| Report History | Local report receipts and statuses, retry or delete pending drafts |
| Offline Queue | Pending drafts, connectivity state, retry and SMS fallback instructions |

## Key user flows

### Emergency flow

User taps the persistent emergency action, sees an unambiguous full-screen emergency view, and taps Call 911 to open the native phone dialer. Guardian does not silently call or imply that a responder has been contacted. The user can return to the app after the call.

### Hazard reporting flow

User taps Report hazard, chooses a category, selects severity, enters a short description, confirms or adjusts the location, optionally attaches a photo, reviews the report, and submits. The app stores a draft locally while the form is incomplete and shows a receipt after successful submission.

### Alert flow

User opens Alerts, scans severity and source labels, taps an alert, reads recommended actions and freshness information, and follows the official source link when needed. The app distinguishes verified, stale, and unavailable data.

### Offline flow

When disconnected, the app preserves the user's draft, shows an offline banner, keeps emergency calling available, and offers a user-editable SMS fallback. When connectivity returns, the draft can be retried without creating a duplicate.

## Visual system

Guardian uses deep civic navy (#0B1F33) for primary navigation, warm off-white (#F7F8FA) for backgrounds, slate (#415466) for supporting text, signal red (#C62828) for emergency actions, amber (#D97706) for caution, teal (#0E7490) for active information, and green (#1F7A4D) for confirmed states. Red is never the only severity cue; labels and icons accompany it.

Cards use 16px corner radii, 1px borders, and restrained shadows. Primary actions use a minimum 48px touch target. The bottom tab bar is persistent and labeled. Screen readers receive explicit labels, roles, hints, and state changes. Large-text mode must preserve action order and avoid clipping.

## Interaction rules

Primary buttons provide subtle scale and opacity feedback. Haptics are reserved for primary actions, success, and error. Forms are step-based rather than dense. Loading states preserve layout. Empty, stale, permission-denied, and offline states always provide a next action. No safety-critical copy is generated without an approved content path.

## First implementation slice

Build the visual tokens, tab navigation, Home, Emergency Mode, Report Hazard, Alerts, Resources, Profile, and local draft persistence first. Use curated local data for the initial UI while keeping domain types ready for a future typed API.
