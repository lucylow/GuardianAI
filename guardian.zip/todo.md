# Guardian Project TODO

- [x] Guardian visual theme tokens and branded home screen
- [x] Bottom tab navigation for Home, Report, Alerts, Resources, and Profile
- [x] Emergency Mode with Call 911 action and safety disclaimer
- [x] Hazard reporting wizard with category, severity, description, and location confirmation
- [x] Local draft persistence for incomplete hazard reports
- [x] Report confirmation receipt and local report history
- [x] Alerts feed and alert detail screen with source and freshness labels
- [x] Resources screen with emergency, city-service, shelter, and accessibility links
- [x] Profile and accessibility settings screen
- [x] Offline state banner and SMS fallback instructions
- [x] Add icon mappings for Guardian navigation and safety actions
- [x] Unit tests for hazard draft persistence and report validation
- [x] Type-check and lint pass
- [x] Visual verification of the core screens

- [x] Native foreground location capture with permission-denied fallback
- [x] Camera and photo-library attachment flow with preview and removal
- [x] Submission-ready report payload fields for coordinates, accuracy, and photo URI
- [x] SDK 54-compatible native package alignment for location, image picker, and SMS

- [x] Hazard report database schema and migration
- [x] Idempotent public report creation procedure
- [x] Guest receipt lookup and authenticated report history procedure
- [x] Mobile report submission mutation with offline draft preservation
- [x] Backend-ready report screen validation and preview verification

- [x] Backend report migration verified against the database
- [x] API, mobile, regression tests, lint, type checks, and server build pass

- [x] Authenticated report history route with status timeline cards
- [x] Profile navigation entry and guest-safe sign-in empty state
- [x] Report history loading, retry, and no-reports states
- [x] History route visual verification and regression checks

- [x] Profile sign-in action connected to existing OAuth portal
- [x] Authenticated profile identity state and focus refresh
- [x] Guest report-history sign-in prompt preserved
- [x] Auth flow visual and regression verification

- [x] Authenticated sign-out action with confirmation dialog
- [x] Guest state restored after sign-out
- [x] Account-control visual and regression verification

- [x] Privacy and data choices screen with local/server boundary explanation
- [x] Safe clear-local-data confirmation and local record count
- [x] Profile privacy navigation and visual verification

- [x] Protected report-data export procedure with privacy-scoped fields
- [x] Native JSON file creation and share-sheet export
- [x] Web download fallback and guest sign-in export state
- [x] Export control regression and visual verification

- [x] Deterministic privacy-scoped export serializer with schema version
- [x] Stable export filename and web/native output handling
- [x] Export helper regression coverage
- [x] Refined export flow visual verification

- [x] Filter and sort hazard report history by date and severity
- [x] Add animated submission progress and success confirmation screen
- [x] Add AI-assisted hazard categorization from description and optional photo

- [x] Filter and sort hazard report history by severity and date order
- [x] Add animated submission progress state and backend receipt confirmation
- [x] Add AI-assisted category suggestion from description with optional photo context
- [x] Add regression coverage for history filtering and sorting
- [x] Run feature validation and visual verification

- [x] Fix guest report-history sign-in CTA dead end by wiring it to OAuth
- [x] Re-run full type, lint, unit, server-build, and preview validation

- [x] Align native OAuth callback scheme with active Expo configuration
- [x] Re-run full validation and preview verification after the error fix

- [x] Remove remaining profile Switch whitespace text node causing React Native runtime errors
- [x] Confirm no unexpected text-node errors remain in current runtime logs

- [x] Use the active primary theme token for tab-bar active tint
- [x] Load native filesystem export support only on native platforms
- [x] Remove misleading OAuth HTTPS canOpenURL preflight
- [x] Re-run full validation and preview verification after warning cleanup

- [x] Demote expected guest auth responses from error logs to informational logs
- [x] Preserve error logs for unexpected auth failures
- [x] Re-run full validation and preview verification after diagnostics cleanup

- [x] Apply the pointerEvents warning filter at module scope for web rendering
- [x] Confirm core screens render with no actionable runtime errors
- [x] Re-run full validation after the final diagnostics fix

- [ ] Remove browser-extension-only MetaMask assumptions from Expo mobile runtime
- [ ] Add mobile-safe wallet provider detection and graceful connection fallback
- [ ] Add regression coverage for unavailable MetaMask providers

- [x] Remove browser-extension-only MetaMask assumptions from Expo mobile runtime
- [x] Add mobile-safe browser-preview fallback for injected MetaMask failures
- [x] Add regression coverage through type, lint, unit, build, and preview validation

- [x] Cache authenticated report history locally for offline viewing
- [x] Add pull-to-refresh and stale-data timestamp feedback
- [x] Add offline-aware retry and cached-history fallback states

- [x] Add connectivity-aware report-history refresh behavior
- [x] Show accessible online/offline status feedback in report history
- [x] Prevent unnecessary refresh attempts while offline

- [x] Show queued hazard reports clearly in the report flow
- [x] Add a manual retry action for queued reports
- [x] Retry queued reports when internet connectivity returns

- [x] Show queued-report count and recovery guidance on Home
- [x] Add direct navigation from Home to queued report recovery
- [x] Keep queued indicator synchronized with local storage changes

- [x] Add a dedicated Outbox screen for queued reports
- [x] Show queued report details and current submission state
- [x] Add direct Outbox navigation and retry guidance

- [x] Add a synchronized queued-report badge to the Report tab
- [x] Add accessible pending-report status text for tab navigation
- [x] Keep the tab badge updated when local queue state changes

- [x] Support multiple queued reports in local outbox storage
- [x] Preserve compatibility with the existing single queued-report record
- [x] Show multiple queued reports and count them in Outbox and navigation

- [x] Add isolated retry state for each queued report
- [x] Add per-report retry controls in Outbox
- [x] Show retrying and retry-failed status feedback per item

- [x] Persist retry-attempt count for each queued report
- [x] Persist a safe user-facing failure reason for retry failures
- [x] Display retry diagnostics and last-attempt time in Outbox

- [x] Add isolated clear action for individual queued reports
- [x] Require explicit confirmation before deleting queued report data
- [x] Refresh Outbox and badge state after individual deletion

- [x] Add a short undo window after clearing a queued report
- [x] Restore the exact cleared report when undo is selected
- [x] Expire undo state safely without reintroducing deleted data

- [x] Persist a privacy-scoped local Outbox activity log
- [x] Record queue, retry, clear, undo, and submission events
- [x] Display recent safe activity entries in Outbox

- [x] Add isolated activity-history clearing in Privacy settings
- [x] Require explicit confirmation before clearing activity history
- [x] Preserve queued reports, drafts, receipts, and report history when activity is cleared

- [x] Show the locally stored Outbox activity-event count in Privacy settings
- [x] Refresh the activity count after clearing history
- [x] Explain that the count excludes queued report content and submitted report data

- [x] Add capped automatic retry scheduling for queued reports
- [x] Persist next eligible retry time per queued report
- [x] Trigger retries only when connected and the app is active

- [x] Show a live countdown until each queued report's automatic retry
- [x] Refresh countdown labels without changing persisted queue state
- [x] Keep countdown feedback accessible and accurate when retry becomes due

- [x] Add a maximum automatic-retry attempt limit per queued report
- [x] Persist automatic-retry exhaustion state
- [x] Keep exhausted reports available for explicit manual retry

- [x] Persist automatic and manual retry attempt counts per queued report
- [x] Preserve compatibility with existing retry metadata
- [x] Display retry summary and exhausted guidance in Outbox

- [x] Add a filter for queued reports needing manual attention
- [x] Show filtered and total queue counts clearly
- [x] Add an accessible empty state when no reports match the filter

- [x] Add a scheduled-retry filter for queued reports
- [x] Show scheduled and total queue counts clearly
- [x] Display next retry timing and an accessible scheduled empty state

- [x] Add sorting by retry urgency and last attempt time in Outbox
- [x] Preserve sorting across All, Needs attention, and Scheduled filters
- [x] Add accessible sort controls and explanatory labels

- [x] Persist a user-controlled automatic-retry pause preference
- [x] Add pause and resume controls in Outbox
- [x] Preserve queued reports and manual retry access while paused

- [x] Show automatic-retry paused status on Home
- [x] Synchronize Home pause status from local storage on focus
- [x] Link Home pause guidance to Outbox controls

- [x] Add pause and resume event types to the local activity model
- [x] Record automatic-retry pause and resume actions from Outbox
- [x] Display safe pause/resume activity labels in Outbox history

- [x] Diagnose the current MetaMask connection error in Guardian web preview
- [x] Apply a narrow web-safe fallback without affecting native Expo behavior
- [x] Re-run web preview, type, lint, tests, and build validation

- [x] Add an automatic-retry-exhausted activity event type
- [x] Record exhaustion once per queued report when the automatic limit is reached
- [x] Display safe manual-attention transition guidance in Outbox activity

- [x] Add a manual-attention filter for Outbox activity events
- [x] Show filtered and total activity counts
- [x] Add an accessible empty state when no manual-attention events exist

- [x] Link manual-attention activity events to their queued report
- [x] Add a direct Retry now shortcut from manual-attention activity entries
- [x] Show a safe fallback when the linked queued report no longer exists

- [x] Add confirmation before Retry now from activity history
- [x] Preserve cancellation without changing queue state
- [x] Provide accessible retry-confirmation copy and feedback

- [x] Add retry-confirmed and retry-cancelled activity event types
- [x] Record decisions from activity-history retry confirmation
- [x] Display safe retry-decision labels in Outbox activity history

- [x] Add newest-first sorting to Outbox activity history
- [x] Add accessible activity sort controls and preserve manual-attention filtering
- [x] Validate activity ordering and mobile-safe rendering

- [x] Persist the Outbox activity order preference locally
- [x] Restore the saved activity order when Outbox opens
- [x] Validate preference persistence and mobile-safe behavior

- [x] Add a safe Retry all ready reports action to Outbox
- [x] Respect connectivity, pause state, retry limits, and serialized submission
- [x] Add accessible batch retry progress and completion feedback
- [x] Validate batch retry behavior and mobile-safe rendering

- [x] Add batch-retry-started and batch-retry-completed activity event types
- [x] Record privacy-scoped batch retry lifecycle outcomes
- [x] Display safe batch outcome labels in Outbox activity history
- [x] Validate batch activity logging and mobile-safe rendering

- [x] Track submitted, failed, and remaining reports during batch retry
- [x] Display an accessible batch outcome summary in Outbox
- [x] Validate batch outcome accounting and mobile-safe rendering

- [x] Add cancellation control for serialized batch retry
- [x] Preserve completed results and queued reports when cancellation is requested
- [x] Record safe batch-cancelled activity feedback
- [x] Validate cancellation behavior and mobile-safe rendering

- [x] Persist the latest privacy-scoped batch retry summary locally
- [x] Restore the latest batch summary when Outbox opens
- [x] Display an accessible persistent batch summary card
- [x] Validate summary persistence and mobile-safe rendering

- [x] Add a confirmation action to clear the recent batch summary
- [x] Keep queued reports, drafts, receipts, and activity history unchanged
- [x] Add accessible cleared-summary feedback and validate the privacy flow

- [x] Add a short undo window after clearing the recent batch summary
- [x] Restore the exact cleared summary when Undo is selected
- [x] Expire undo state without changing queued reports or activity history
- [x] Validate summary undo behavior and mobile-safe rendering

- [x] Show recent batch-summary status in Profile → Privacy
- [x] Add an isolated clear-summary action to Privacy settings
- [x] Preserve queued reports, drafts, receipts, and activity history
- [x] Validate privacy-screen summary management and mobile-safe rendering

- [x] Add a direct Privacy-to-Outbox activity-history link
- [x] Preserve local data and return navigation semantics
- [x] Validate accessible troubleshooting navigation and mobile-safe rendering

- [x] Add a direct Outbox-to-Privacy shortcut
- [x] Preserve queue state and navigation semantics
- [x] Validate accessible return navigation and mobile-safe rendering

- [x] Preserve Privacy as the source context when opening Outbox
- [x] Show a context-aware Back to Privacy return action
- [x] Keep default Outbox navigation unchanged for other entry points
- [x] Validate route context and mobile-safe rendering

- [x] Show queued, failed, and scheduled retry counts on Home
- [x] Keep Home recovery summary synchronized with local Outbox state
- [x] Add accessible Home-to-Outbox recovery navigation
- [x] Validate Home retry summary and mobile-safe rendering

- [x] Show the last synchronized time for Home retry status
- [x] Keep freshness copy synchronized with local queue loading
- [x] Add accessible timestamp wording and validate mobile-safe rendering

- [x] Add a manual refresh control for Home retry status
- [x] Show accessible refreshing and refreshed feedback
- [x] Keep refresh local-only and preserve existing Outbox behavior
- [x] Validate manual refresh and mobile-safe rendering

- [x] Add a manual refresh control to Outbox status
- [x] Refresh local queue and pause state without changing queued data
- [x] Add accessible refreshing and refreshed feedback
- [x] Validate Outbox manual refresh and mobile-safe rendering

- [x] Add pull-to-refresh support to the Outbox ScrollView
- [x] Reuse the existing local refresh flow without mutating queue state
- [x] Add accessible pull-to-refresh feedback
- [x] Validate Outbox pull-to-refresh and mobile-safe rendering

- [x] Add pull-to-refresh support to Report History
- [x] Reuse cached-history refresh behavior and preserve offline fallback
- [x] Add accessible refresh feedback
- [x] Validate Report History pull-to-refresh and mobile-safe rendering

- [x] Show last-refreshed time for Report History
- [x] Keep freshness status synchronized after successful refresh and cache updates
- [x] Add accessible timestamp wording and validate mobile-safe rendering

- [x] Distinguish offline cached history from failed online refresh
- [x] Preserve the last successful synchronization timestamp after refresh failure
- [x] Add accessible retry guidance for refresh errors
- [x] Validate Report History recovery states and mobile-safe rendering

- [ ] Keep emergency calling, core reporting, offline workflows, and safety alerts free
- [ ] Add optional monthly and annual supporter tiers
- [ ] Add optional one-time donation flow
- [ ] Create server-authoritative Stripe payment and entitlement model
- [ ] Verify Stripe webhook signatures and idempotently sync payment status
- [ ] Add payment failure, cancellation, and privacy-safe recovery states
- [ ] Validate monetization flows without storing card data

- [x] Keep live Stripe processing disabled until credentials are configured
- [x] Add supporter and donation presentation screens without collecting payment data
- [x] Add a credential-gated payment contract with a clear unavailable state
- [x] Validate that all core safety workflows remain free and unaffected

- [x] Add clearer monthly, annual, and one-time support comparison
- [x] Persist only the selected support intent locally, never payment data
- [x] Show disabled-safe payment feedback and preserve all free safety flows
- [x] Validate monetization UX and local intent recovery

- [x] Show the saved support interest with an explicit local-data explanation
- [x] Add a confirmed clear support-interest action
- [x] Preserve payment-disabled state and all free safety workflows
- [x] Validate support-interest privacy controls and recovery feedback

- [x] Explain Stripe readiness requirements without exposing credentials
- [x] Show a clear support-payment state and next-step guidance
- [x] Preserve local support intent and all free safety workflows
- [x] Validate disabled-state accessibility and monetization UX

- [x] Add a concise supporter-benefit summary without promising locked core safety access
- [x] Add a clear payment-setup unavailable recovery path
- [x] Preserve all free safety features and local support intent
- [x] Validate disabled-state accessibility and monetization UX

- [x] Add a local supporter-status presentation that is not treated as payment confirmation
- [x] Distinguish interest, pending setup, active, and unavailable states safely
- [x] Preserve all free safety workflows and avoid storing payment data
- [x] Validate supporter-status accessibility and disabled payment behavior

- [x] Add map-based location confirmation to hazard reporting
- [x] Provide permission-denied and services-disabled location fallback states
- [x] Keep map location data local until report submission
- [x] Add accessible location status and map controls
- [x] Validate mapping behavior and Expo-safe rendering

- [x] Add a native recenter map control for the captured location
- [x] Explain approximate accuracy and coordinate adjustments clearly
- [x] Preserve web coordinate fallback and local-only location behavior
- [x] Validate map controls and accessibility across supported platforms

- [x] Show a visible native accuracy radius around the captured location
- [x] Add an explicit Use this pin confirmation state after map adjustments
- [x] Preserve web fallback, privacy boundaries, and offline-safe submission
- [x] Validate accuracy and pin-confirmation interactions across supported platforms

- [x] Add a native standard/satellite map-style toggle
- [x] Persist the preferred map style locally and restore it on report flow load
- [x] Preserve web fallback, privacy boundaries, and offline-safe behavior
- [x] Validate map-style switching and preference persistence across supported platforms

- [x] Add optional reverse-geocoded street or intersection guidance after pin confirmation
- [x] Keep geocoding suggestions local and user-editable without replacing coordinates
- [x] Preserve offline-safe behavior, web fallback, and privacy boundaries
- [x] Validate geocoding loading, success, empty, and failure states

- [x] Cache the last successful geocoded label locally for draft recovery
- [x] Add a manual Refresh label action after pin confirmation
- [x] Preserve privacy, offline recovery, and coordinate integrity
- [x] Validate cached, refreshed, unavailable, and failure states

- [x] Show when the cached nearby label was last refreshed
- [x] Add a privacy-safe clear cached-label action
- [x] Preserve drafts, coordinates, reports, and other local data when clearing the label
- [x] Validate freshness, clear, and recovery states

- [x] Explain that nearby map labels are approximate guidance
- [x] Show a success confirmation after clearing the cached label
- [x] Preserve coordinates, drafts, reports, and offline workflows
- [x] Validate label explanation and clear-feedback states

- [x] Add a short undo window after clearing the cached nearby label
- [x] Restore the exact cached label and timestamp when Undo is selected
- [x] Expire undo state without changing drafts, coordinates, reports, or other data
- [x] Validate cached-label clear, undo, and expiry states

- [x] Add a live countdown indicator to the cached-label Undo action
- [x] Log cached-label clear and restore privacy activity events
- [x] Add a confirmation-protected Clear all location suggestions action
- [x] Preserve drafts, coordinates, reports, and unrelated local data
- [x] Validate countdown, activity, clear-all, and expiry states

- [x] Add a live native location-signal status card with permission and accuracy state
- [x] Show the last successful location refresh time
- [x] Add recovery actions for unavailable or denied location access
- [x] Preserve optional location, privacy, and offline-first reporting behavior
- [x] Validate native and web-safe location status states

- [x] Add a dynamic location signal-quality indicator based on accuracy
- [x] Explain strong, approximate, and weak location readings clearly
- [x] Preserve optional location, privacy, and offline-first behavior
- [x] Validate signal-quality states across native and web-safe flows

- [x] Persist latest location capture time and accuracy metadata with the local draft
- [x] Restore native location signal context after draft hydration
- [x] Preserve privacy and offline draft integrity without adding new location collection
- [x] Validate metadata persistence, restoration, and empty-draft states

- [x] Add a native Refresh location action for fresh accuracy metadata
- [x] Preserve manually entered text and the confirmed map pin during refresh
- [x] Persist refreshed timestamp and accuracy without extra background collection
- [x] Validate refresh loading, success, failure, and offline-safe states

- [x] Show a visible confirmation after a successful location refresh
- [x] Confirm that report text and the map pin were preserved
- [x] Keep refresh feedback local, optional, and offline-safe
- [x] Validate success, dismissal, and failure feedback states

- [x] Trigger a light native haptic after successful location refresh
- [x] Keep web previews and unsupported devices on the visual confirmation fallback
- [x] Avoid haptic feedback on failed or cancelled refreshes
- [x] Validate platform-safe haptic and visual feedback states

- [x] Add a local Accessibility preference for Guardian haptic feedback
- [x] Restore the haptics preference on app and report-flow load
- [x] Honor the preference for native location-refresh success haptics
- [x] Preserve visual feedback and web-safe behavior when haptics are disabled
- [x] Validate preference persistence and native refresh feedback states

- [x] Trigger preference-controlled native haptic feedback after confirming a moved map pin
- [x] Preserve visual pin-confirmation feedback for web and disabled-haptics users
- [x] Avoid haptics when a pin adjustment is cancelled or not confirmed
- [x] Validate pin confirmation feedback across native and web-safe flows

- [x] Trigger preference-controlled native success haptic after completed hazard-report submission
- [x] Preserve the existing success screen and offline queue outcome messaging
- [x] Keep visual confirmation for web and disabled-haptics users
- [x] Avoid haptics on failed, cancelled, or queued-only submissions
- [x] Validate submission success feedback across native and web-safe flows

- [x] Distinguish online-submitted and offline-queued confirmation states
- [x] Show dynamic status copy and a clear next action on the confirmation screen
- [x] Preserve resilient outbox behavior and preference-controlled native feedback
- [x] Validate submitted, queued, retry, and reset states across native and web-safe flows

- [x] Resolve transient Expo watcher/runtime errors and confirm a clean restart
- [x] Re-run Guardian type-check, lint, tests, and server build after the fix

- [x] Recheck current Guardian diagnostics and runtime logs for reported errors
- [x] Restart Expo services and confirm a clean running preview
- [x] Re-run type-check, lint, tests, and server build after the recheck

- [x] Confirm recurring Expo Premature close entries are transient client or proxy stream cancellations
- [x] Confirm no source-level error is reproduced by Guardian validation
- [x] Preserve real error visibility while documenting the benign development-log noise

- [x] Reproduce the latest reported Guardian errors with the full validation suite
- [x] Confirm current Expo logs contain only successful bundles after the last restart
- [x] Document historical lifecycle and Premature close entries without masking real errors

- [x] Refine report-flow status presentation for clearer native mobile hierarchy
- [x] Improve accessibility labels, live regions, and action semantics in the report flow
- [x] Extract or standardize repeated status-card presentation without changing behavior
- [x] Preserve offline, privacy, and native-safe behavior
- [x] Validate frontend changes across web and native-safe states

- [x] Create a reusable native-safe status-card component API
- [x] Adopt shared status presentation for location and queue states
- [x] Preserve accessibility semantics and existing status behavior
- [x] Validate reusable status cards across web and native-safe flows

- [x] Reuse GuardianStatusCard for native location signal presentation
- [x] Reuse GuardianStatusCard for submitted and offline confirmation states
- [x] Remove obsolete manual status-card styles without changing behavior
- [x] Validate shared status presentation with type-check, lint, tests, and server build

- [x] Standardize Outbox status presentation with GuardianStatusCard
- [x] Standardize Privacy summary and undo feedback with GuardianStatusCard
- [x] Preserve retry, clear, undo, privacy, and accessibility behavior
- [x] Validate Outbox and Privacy status presentation across web and native-safe flows

- [x] Add live undo countdown feedback to Outbox and Privacy restore states
- [x] Add clearer queued, ready, manual-attention, and scheduled counts to Outbox
- [x] Preserve retry, clear, undo, privacy, and accessibility behavior
- [x] Validate countdown and queue-summary interactions across web and native-safe flows

- [x] Make Queue at a glance counts actionable in the Outbox
- [x] Preserve filter state, retry behavior, and accessibility semantics
- [x] Validate actionable queue-summary interactions across web and native-safe flows

- [x] Add a Ready filter to the actionable Outbox queue summary
- [x] Preserve filter semantics, retry behavior, and accessible empty states
- [x] Validate the Ready filter across web and native-safe flows

- [x] Improve Home screen visual hierarchy and primary action affordances
- [x] Improve Outbox spacing, filter controls, and shared status-card presentation
- [x] Preserve safety workflows, tap targets, and accessibility semantics
- [x] Validate the interface polish across web and native-safe flows

- [x] Improve Alerts screen visual hierarchy and interactive card affordances
- [x] Improve Resources screen visual hierarchy and interactive card affordances
- [x] Preserve navigation, tap targets, and accessibility semantics
- [x] Validate the Alerts and Resources UI across web and native-safe flows

- [x] Improve Profile and settings navigation hierarchy
- [x] Improve Support and Privacy visual consistency without changing safety access
- [x] Preserve navigation, tap targets, privacy boundaries, and accessibility semantics
- [x] Validate the Profile, Support, and Privacy UI across web and native-safe flows

- [x] Improve Report flow step hierarchy and input affordances
- [x] Improve location, attachment, AI categorization, and submission feedback presentation
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate the Report flow UI across web and native-safe flows

- [x] Add inline validation guidance for incomplete Report fields
- [x] Improve restored-draft and saved-state feedback in the Report flow
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate validation and recovery feedback across web and native-safe flows

- [x] Add a clear local-save confirmation banner to the Report flow
- [x] Add description guidance and a concise character counter
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate save feedback and description guidance across web and native-safe flows

- [x] Improve attached-photo preview hierarchy and privacy messaging
- [x] Add safer photo removal feedback and confirmation
- [x] Preserve report privacy, offline queueing, native photo handling, and accessibility semantics
- [x] Validate photo attachment interactions across web and native-safe flows

- [x] Add a Change photo action to the attached-photo preview
- [x] Preserve privacy, local draft replacement, and accessibility semantics
- [x] Validate replacement-photo interactions across web and native-safe flows

- [x] Add meaningful bottom-tab icons for Alerts, Resources, and Profile
- [x] Refine screen-level back navigation affordances and labels
- [x] Preserve route behavior, tap targets, and accessibility semantics
- [x] Validate navigation UI across web and native-safe flows

- [x] Add stronger active and inactive tab visual feedback
- [x] Standardize route-aware back controls and labels
- [x] Preserve route behavior, tap targets, and accessibility semantics
- [x] Validate navigation feedback across web and native-safe flows

- [x] Standardize Outbox, Privacy, and Report History headers and back controls
- [x] Refine summary cards and section hierarchy across these screens
- [x] Preserve route behavior, offline recovery, privacy boundaries, and accessibility semantics
- [x] Validate consistency polish across web and native-safe flows

- [x] Improve one-handed report actions and recovery paths
- [x] Improve Outbox retry, undo, and filter feedback
- [x] Improve privacy and navigation feedback for mobile users
- [x] Preserve safety access, offline behavior, privacy boundaries, and accessibility semantics
- [x] Validate the mobile UX across web and native-safe flows

- [x] Keep focused Report fields visible above the keyboard
- [x] Preserve validation focus recovery and scroll behavior
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate keyboard-aware Report interactions across web and native-safe flows

- [x] Add a Next issue action for multiple incomplete Report fields
- [x] Preserve keyboard-aware focus recovery and validation clearing behavior
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate multi-error recovery across web and native-safe flows

- [x] Show active validation issue position and remaining count
- [x] Preserve keyboard-aware focus recovery and validation clearing behavior
- [x] Preserve report privacy, offline queueing, native location, and accessibility semantics
- [x] Validate validation-progress feedback across web and native-safe flows

- [x] Add clear completion feedback when the final Report validation issue is fixed
- [x] Preserve submit readiness, keyboard-aware behavior, privacy, and accessibility semantics
- [x] Validate validation-completion feedback across web and native-safe flows

- [x] Add a direct Review report action to the ready-to-submit card
- [x] Preserve keyboard-aware scrolling and submission-control visibility
- [x] Preserve report privacy, offline queueing, and accessibility semantics
- [x] Validate Review report navigation across web and native-safe flows

- [x] Make Save draft and Submit report easier to reach on smaller screens
- [x] Preserve draft persistence, submit behavior, keyboard handling, privacy, and accessibility semantics
- [x] Validate the final-action surface across web and native-safe flows

- [x] Add safe-area bottom padding to the Report mobile action bar
- [x] Emphasize Submit report only after validation is complete
- [x] Add smooth loading and press feedback to Submit report
- [x] Preserve submission, offline queueing, privacy, and accessibility semantics
- [x] Validate action-bar behavior across web and native-safe flows

- [x] Improve AI category confidence and rationale presentation
- [x] Add safer human confirmation before applying AI suggestions
- [x] Improve AI failure, low-confidence, and offline fallback guidance
- [x] Preserve privacy, offline-first reporting, and accessibility semantics
- [x] Validate AI categorization across web and native-safe flows

- [x] Add a concise Why this suggestion explanation to the AI card
- [x] Add a Keep my category action beside Apply suggestion
- [x] Preserve human control, privacy, offline reporting, and accessibility semantics
- [x] Validate AI explanation and category-choice interactions across web and native-safe flows

- [x] Add helpful and not-helpful feedback controls to the AI suggestion card
- [x] Keep feedback local and independent from report content and privacy settings
- [x] Preserve offline behavior and accessibility semantics
- [x] Validate AI feedback interactions across web and native-safe flows

- [x] Add an optional reason field after Not helpful AI feedback
- [x] Keep feedback local and independent from report content and privacy settings
- [x] Preserve offline behavior and accessibility semantics
- [x] Validate AI feedback-reason interactions across web and native-safe flows

- [x] Add selectable reason chips after Not helpful AI feedback
- [x] Keep chip feedback local and independent from report content and privacy settings
- [x] Preserve offline behavior and accessibility semantics
- [x] Validate AI feedback-chip interactions across web and native-safe flows

- [x] Add a local Privacy activity-log entry when AI feedback reasons are saved
- [x] Preserve privacy boundaries, offline behavior, and accessible confirmation
- [x] Validate AI feedback and Privacy activity-log interactions across web and native-safe flows

- [x] Detect missing hazard context before requesting an AI category suggestion
- [x] Show concise, accessible guidance without blocking manual category selection or offline reporting
- [x] Validate AI context guidance across report submission and failure flows

- [x] Add category-specific AI follow-up guidance for common hazard types
- [x] Keep guidance concise, accessible, and advisory without changing manual category control
- [x] Validate category-guidance rendering and AI fallback behavior

- [x] Add confidence-aware review copy for strong, tentative, and context-limited AI suggestions
- [x] Keep human confirmation required and preserve manual category control, privacy, and offline reporting
- [x] Validate confidence-aware AI review rendering and fallback behavior

- [x] Add a “What would improve confidence?” action to the AI suggestion card
- [x] Guide users to the specific missing report detail without overriding category control or expanding data sharing
- [x] Validate confidence-improvement guidance and accessible field focus behavior

- [x] Add an inline AI confidence meter with numeric and text labels
- [x] Ensure confidence is understandable without color and does not alter human review or offline behavior
- [x] Validate confidence-meter rendering and accessibility semantics

- [x] Diagnose and fix the currently reported Guardian runtime or build errors
- [x] Preserve AI, offline-first, privacy, and accessibility behavior while fixing errors
- [x] Re-run complete validation and confirm no actionable errors remain

- [x] Diagnose and fix any remaining actionable Guardian errors after the latest checkpoint
- [x] Preserve existing AI, offline-first, privacy, and accessibility behavior during the fix
- [x] Re-run complete validation and confirm the dev server is healthy

- [x] Diagnose and fix any newly reported actionable Guardian errors after the latest checkpoint
- [x] Preserve existing AI, offline-first, privacy, and accessibility behavior during the fix
- [x] Re-run complete validation and confirm the current dev server remains healthy

- [x] Diagnose and fix any newly reported actionable Guardian errors after the latest checkpoint
- [x] Preserve existing AI, offline-first, privacy, and accessibility behavior during the fix
- [x] Re-run complete validation and confirm the current dev server remains healthy

- [x] Diagnose and fix any newly reported actionable Guardian errors after the latest checkpoint
- [x] Preserve existing AI, offline-first, privacy, and accessibility behavior during the fix
- [x] Re-run complete validation and confirm the current dev server remains healthy

- [x] Diagnose and fix any newly reported actionable Guardian errors after the latest checkpoint
- [x] Preserve existing AI, offline-first, privacy, and accessibility behavior during the fix
- [x] Re-run complete validation and confirm the current dev server remains healthy

- [x] Strengthen pressed-state feedback and action discoverability for Home quick actions
- [x] Preserve accessibility labels, navigation destinations, and offline-safe behavior
- [x] Validate the Home interaction refinement across web and native-safe code paths

- [x] Extend pressed-state feedback and directional affordances to Alerts, Resources, and Profile
- [x] Preserve navigation, accessibility labels, privacy controls, and offline workflows
- [x] Validate the cross-screen UX refinement with static checks and live previews

- [x] Clarify touch targets and live feedback in Outbox and Privacy
- [x] Preserve local-first privacy boundaries, navigation, and existing data controls
- [x] Validate Outbox and Privacy accessibility behavior across web and native-safe code paths

- [x] Make Report History filter and sort controls clearer and easier to operate one-handed
- [x] Preserve report data, privacy boundaries, navigation, and accessibility semantics
- [x] Validate the Report History UX refinement with static checks and live preview

- [x] Persist Report History severity filter and date sort choices locally across visits
- [x] Preserve report data, privacy boundaries, navigation, and accessibility semantics
- [x] Validate preference restoration and filter interactions across web and native-safe code paths

- [x] Persist Outbox queue filter, sort, and activity-view choices locally across visits
- [x] Preserve queued report contents, privacy boundaries, navigation, and offline behavior
- [x] Validate preference restoration and Outbox interactions across web and native-safe code paths

- [x] Add reset-view actions for Report History and Outbox defaults
- [x] Preserve persisted preferences, report data, privacy settings, navigation, and offline behavior
- [x] Validate reset actions and preference persistence across web and native-safe code paths

- [x] Add accessible confirmation feedback after Report History and Outbox reset actions
- [x] Preserve persisted preferences, report data, privacy settings, navigation, and offline behavior
- [x] Validate reset confirmations across web and native-safe code paths

- [x] Add preference-aware native haptic feedback after Report History and Outbox resets
- [x] Preserve visual confirmations, accessibility, privacy boundaries, and offline behavior
- [x] Validate haptic reset feedback with native-safe mocks and complete project checks

- [x] Add an accessible persisted Haptics toggle to Profile
- [x] Preserve privacy, offline behavior, existing confirmations, and native-safe feedback flows
- [x] Validate Haptics preference restoration and action behavior across web and native-safe code paths

- [x] Add concise device-only privacy guidance beneath the Profile Haptics setting
- [x] Preserve accessibility, privacy boundaries, offline behavior, and existing haptic flows
- [x] Validate the Haptics privacy copy across web and native-safe code paths

- [x] Add explicit enabled or disabled state copy beside the Profile Haptics switch
- [x] Preserve persisted preferences, accessibility, privacy, and native-safe feedback behavior
- [x] Validate Haptics state-label rendering across web and native-safe code paths

- [x] Add explicit On or Off labels to Notifications and accessibility switches in Profile
- [x] Preserve persisted settings, accessibility, privacy, and native-safe behavior
- [x] Validate all Profile switch labels across web and native-safe code paths

- [x] Persist and restore Profile high-contrast, larger-text, notifications, and Haptics preferences
- [x] Preserve privacy, accessibility, native-safe feedback, and offline behavior
- [x] Validate Profile preference restoration across web and native-safe code paths

- [x] Apply the larger-text preference consistently across core Guardian screens
- [x] Preserve one-handed layout, accessibility semantics, offline behavior, and visual hierarchy
- [x] Validate larger-text rendering across web and native-safe paths

- [x] Extend larger-text scaling to Report, Outbox, Privacy, and report-history workflows
- [x] Preserve offline states, privacy boundaries, and accessible controls during scaling
- [x] Validate expanded larger-text rendering across web and native-safe paths

- [x] Extend larger-text scaling to Alert detail, Emergency guidance, and Support screens
- [x] Preserve safety actions, accessibility semantics, and offline guidance during scaling
- [x] Validate final larger-text rendering across web and native-safe paths

- [x] Add accessible live confirmation when Larger text changes
- [x] Preserve device-local privacy and typography scaling behavior
- [x] Validate assistive-technology feedback and visual confirmation

- [x] Add accessible live confirmation when High-contrast emergency mode changes
- [x] Add accessible live confirmation when Safety alerts changes
- [x] Preserve local persistence, privacy, accessibility, and safety behavior
- [x] Validate Profile preference feedback across web and native-safe paths

- [x] Add accessible live confirmation when Haptic feedback changes
- [x] Preserve device-only privacy guidance and native-safe feedback behavior
- [x] Validate Haptic preference feedback across web and native-safe paths

- [x] Improve accessible success feedback for report submission
- [x] Improve accessible success feedback for queued retry and undo actions
- [x] Respect persisted Haptic feedback preference and preserve offline privacy
- [x] Validate action feedback across web and native-safe paths

- [x] Add accessible retry-failure confirmation and recovery guidance
- [x] Preserve on-device queue privacy and retry semantics
- [x] Validate failed-retry feedback across web and native-safe paths

- [x] Add a direct Try again action to retry-failure feedback
- [x] Preserve queue privacy, retry rules, and accessible state feedback
- [x] Validate direct retry recovery across web and native-safe paths

- [x] Show next scheduled retry time in retry-failure feedback
- [x] Preserve queue privacy, retry semantics, and accessible recovery actions
- [x] Validate scheduled-retry feedback across web and native-safe paths

- [x] Add a live countdown for the next scheduled retry while Outbox is open
- [x] Preserve accessibility, queue privacy, and retry recovery actions
- [x] Validate countdown behavior across web and native-safe paths

- [x] Add a clear retry-due-now state when the countdown reaches zero
- [x] Preserve automatic retry behavior, accessibility, privacy, and recovery actions
- [x] Validate due-now status across web and native-safe paths

- [x] Add a prominent Retry now action when a scheduled retry becomes due
- [x] Preserve automatic retry behavior, privacy, accessibility, and Haptic preference behavior
- [x] Validate due-now actions across web and native-safe paths

- [x] Add a focused filter for reports ready to retry now
- [x] Preserve persisted filters, queue privacy, retry behavior, and accessibility
- [x] Validate ready-now filtering across web and native-safe paths

- [x] Add a bulk Retry due reports action for multiple ready scheduled retries
- [x] Preserve confirmation safeguards, privacy, accessibility, haptics, and retry semantics
- [x] Validate bulk due-retry behavior across web and native-safe paths

- [x] Add polite live announcements for bulk retry progress and completion
- [x] Preserve batch cancellation, privacy, haptics, and visual feedback
- [x] Validate batch announcements across web and native-safe paths

- [x] Add a persisted preference for reducing or disabling repeated bulk-retry progress announcements
- [x] Preserve essential start, completion, failure, cancellation, privacy, accessibility, and haptic feedback
- [x] Validate announcement-frequency behavior across web and native-safe paths

- [x] Add the bulk-retry announcement preference to Profile with an accessible On/Off control
- [x] Preserve Outbox synchronization, device-local privacy, accessibility, and haptics
- [x] Validate Profile and Outbox announcement preference behavior across web and native-safe paths

- [x] Add clear visual and assistive-technology confirmation when bulk-retry announcements change
- [x] Preserve persistence, Outbox synchronization, privacy, and essential feedback
- [x] Validate announcement-setting confirmation across web and native-safe paths

- [x] Add a compact visual example explaining bulk-retry announcement On versus Off
- [x] Add dismissible preference confirmation behavior to the Outbox announcement control
- [x] Validate Profile and Outbox switch semantics and confirmation timing for VoiceOver and TalkBack

- [x] Improve dynamic map hazard visibility and refresh behavior
- [x] Add one-handed map controls plus loading, empty, and offline states
- [x] Preserve native/web map compatibility, local privacy, and accessible marker interactions
- [x] Validate dynamic map states across web and native-safe paths

- [x] Add native map loading and unavailable recovery states
- [x] Add a compact confirmed-pin summary with accuracy and last-updated context
- [x] Preserve web fallback, privacy, one-handed controls, and accessible map semantics
- [x] Validate map state behavior across web and native-safe paths

- [x] Add a Use saved coordinates without map recovery action
- [x] Preserve local privacy, pin confirmation, accessibility, and map retry behavior
- [x] Validate saved-coordinate recovery across web and native-safe paths

- [x] Add a lightweight refreshed-location indicator after accuracy updates
- [x] Preserve confirmed pin, privacy, accessibility, and map fallback behavior
- [x] Validate refreshed-location feedback across web and native-safe paths

- [x] Add a compact location accepted without map indicator to final report review
- [x] Preserve saved-coordinate privacy, submission behavior, and accessible status semantics
- [x] Validate final-review location status across web and native-safe paths

- [x] Add a compact location-status row to Outbox queued report details
- [x] Preserve local privacy, queue semantics, accessibility, and offline behavior
- [x] Validate Outbox location status across web and native-safe paths

- [x] Add a revise-location action for queued reports before retry
- [x] Preserve queued draft privacy, retry semantics, and accessible actions
- [x] Validate queued-location editing across web and native-safe paths

- [x] Add a clear confirmation after saving revised queued-report location details
- [x] Preserve local privacy, retry reset, accessibility, and Outbox navigation
- [x] Validate revised-location confirmation across web and native-safe paths

- [x] Add a visible last-location-refresh timestamp to queued report location summaries
- [x] Add a dedicated location_revised activity event for queued report edits
- [x] Preserve local privacy, retry reset, map metadata, and accessible feedback
- [x] Validate the dynamic-map improvements across web and native-safe paths


- [x] Add a compact map freshness legend for captured, refreshed, and accepted-without-map states
- [x] Improve map unavailable recovery guidance without changing saved coordinates
- [x] Preserve offline privacy, retry semantics, and accessible one-handed controls
- [x] Validate the dynamic-map clarity improvements across web and native-safe paths


- [x] Add a useful web location preview for saved coordinates
- [x] Preserve native map behavior and saved-coordinate recovery
- [x] Keep web map preview privacy-scoped and accessible
- [x] Validate native/web map consistency across automated and visual checks


- [x] Add an explicit confirmation-protected open-in-maps action for attached coordinates
- [x] Keep the handoff privacy-aware and unavailable when no coordinates are saved
- [x] Preserve offline safeguards and accessible handoff feedback
- [x] Validate the external map handoff across automated and visual checks


- [x] Add a privacy-scoped activity event when a user confirms an external map handoff
- [x] Keep provider details and coordinates out of the activity log
- [x] Preserve offline behavior and accessible handoff confirmation feedback
- [x] Validate map-handoff privacy logging across automated and visual checks


- [x] Add the confirmation-protected Open in maps control to the native map card
- [x] Preserve the generic privacy-scoped external_map_opened activity event
- [x] Keep native/web handoff feedback and accessibility behavior consistent
- [x] Validate native handoff parity across automated and visual checks


- [x] Make the external handoff confirmation identify the destination map service clearly
- [x] Keep provider and coordinate details out of the local activity log
- [x] Preserve offline recovery and accessible native/web handoff feedback
- [x] Validate provider-aware handoff messaging across automated and visual checks


- [x] Add platform-aware map-provider options for native and web handoff
- [x] Protect provider selection with explicit confirmation
- [x] Keep provider choice and coordinates out of the local activity log
- [x] Validate platform-aware handoff behavior across automated and visual checks


- [x] Add a device-local preferred map provider for supported platforms
- [x] Preserve explicit confirmation before every external handoff
- [x] Keep provider preference and handoff details outside the activity log
- [x] Validate preference persistence, reset behavior, and accessibility feedback

