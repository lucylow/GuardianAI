import { describe, expect, it } from "vitest";

import { buildGuardianExportFilename, serializeGuardianExport } from "../lib/guardian-export";

describe("Guardian export helpers", () => {
  it("uses a stable date-based filename", () => {
    expect(buildGuardianExportFilename(new Date("2026-08-15T12:00:00.000Z"))).toBe("guardian-report-data-2026-08-15.json");
  });

  it("serializes a versioned privacy-scoped export", () => {
    const json = serializeGuardianExport({
      exportedAt: new Date("2026-08-15T12:00:00.000Z"),
      account: { userId: 7, email: "resident@example.com" },
      reports: [{
        reportId: 3,
        clientRequestId: "guardian-test-123456",
        category: "Pothole",
        severity: "Medium",
        description: "Large pothole",
        locationText: "5th and Meridian",
        latitude: "39.7667",
        longitude: "-86.1620",
        accuracy: "12.00",
        status: "received",
        source: "mobile",
        createdAt: new Date("2026-08-15T12:00:00.000Z"),
        updatedAt: new Date("2026-08-15T12:01:00.000Z"),
        hasPhotoAttachment: false,
      }],
    });
    const parsed = JSON.parse(json);
    expect(parsed.schemaVersion).toBe(1);
    expect(parsed.reports[0].createdAt).toBe("2026-08-15T12:00:00.000Z");
    expect(parsed.reports[0].hasPhotoAttachment).toBe(false);
  });
});
