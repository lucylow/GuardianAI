import { describe, expect, it } from "vitest";

import { buildSmsReportMessage, validateGuardianReport } from "../lib/guardian-report";

describe("Guardian report helpers", () => {
  it("requires category, description, and location", () => {
    expect(validateGuardianReport({ category: "", severity: "Medium", description: " ", location: "" })).toEqual({
      category: "Choose a category.",
      description: "Add a short description.",
      location: "Add a landmark, intersection, or address.",
    });
  });

  it("accepts a complete report", () => {
    expect(validateGuardianReport({ category: "Pothole", severity: "Medium", description: "Large pothole", location: "5th and Meridian" })).toEqual({});
  });

  it("builds a concise SMS fallback message", () => {
    expect(buildSmsReportMessage({ category: "Flooding", severity: "High", description: "Water covers the sidewalk", location: "5th and Meridian" })).toBe("Flooding at 5th and Meridian: Water covers the sidewalk");
  });
});
