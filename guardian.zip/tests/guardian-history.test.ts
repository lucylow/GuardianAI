import { describe, expect, it } from "vitest";

import { filterAndSortReports } from "../lib/guardian-history";

const reports = [
  { category: "Pothole", severity: "High", status: "received", clientRequestId: "a-report-1234", createdAt: "2026-08-10T12:00:00.000Z", updatedAt: "2026-08-10T12:00:00.000Z" },
  { category: "Streetlight", severity: "Low", status: "resolved", clientRequestId: "b-report-1234", createdAt: "2026-08-12T12:00:00.000Z", updatedAt: "2026-08-12T12:00:00.000Z" },
  { category: "Flooding", severity: "High", status: "triaged", clientRequestId: "c-report-1234", createdAt: "2026-08-11T12:00:00.000Z", updatedAt: "2026-08-11T12:00:00.000Z" },
];

describe("Guardian history helpers", () => {
  it("filters by severity", () => {
    expect(filterAndSortReports(reports, "High", "newest").map((report) => report.category)).toEqual(["Flooding", "Pothole"]);
  });

  it("sorts reports oldest first", () => {
    expect(filterAndSortReports(reports, "All", "oldest").map((report) => report.category)).toEqual(["Pothole", "Flooding", "Streetlight"]);
  });
});
