import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import * as Network from "expo-network";
import { Link } from "expo-router";
import { startOAuthLogin } from "@/constants/oauth";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";
import { trpc } from "@/lib/trpc";
import { filterAndSortReports, type GuardianHistoryReport } from "@/lib/guardian-history";

const statusLabels: Record<string, string> = { received: "Received", queued: "Queued", triaged: "Under review", in_progress: "In progress", resolved: "Resolved", rejected: "Closed" };
const statusColors: Record<string, "primary" | "warning" | "success" | "error"> = { received: "primary", queued: "primary", triaged: "warning", in_progress: "warning", resolved: "success", rejected: "error" };
const HISTORY_CACHE_KEY = "guardian.report.history.cache.v1";
const HISTORY_PREFERENCES_KEY = "guardian.report.history.preferences.v1";

export default function ReportHistoryScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const { isAuthenticated, loading: authLoading } = useAuth();
  const history = trpc.reports.mine.useQuery(undefined, { enabled: isAuthenticated, retry: 1 });
  const networkState = Network.useNetworkState();
  const isOnline = networkState.isInternetReachable !== false && networkState.isConnected !== false;
  const [cachedReports, setCachedReports] = useState<GuardianHistoryReport[]>([]);
  const [cachedAt, setCachedAt] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string | null>(null);
  const [refreshError, setRefreshError] = useState(false);
  const [severityFilter, setSeverityFilter] = useState("All");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");
  const [historyPreferencesLoaded, setHistoryPreferencesLoaded] = useState(false);
  const [resetFeedback, setResetFeedback] = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(HISTORY_PREFERENCES_KEY).then((value) => {
      if (value) {
        const parsed = JSON.parse(value) as { severityFilter?: string; sortOrder?: "newest" | "oldest" };
        if (["All", "Low", "Medium", "High"].includes(parsed.severityFilter ?? "")) setSeverityFilter(parsed.severityFilter ?? "All");
        if (parsed.sortOrder === "newest" || parsed.sortOrder === "oldest") setSortOrder(parsed.sortOrder);
      }
    }).catch(() => undefined).finally(() => setHistoryPreferencesLoaded(true));
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;
    AsyncStorage.getItem(HISTORY_CACHE_KEY).then((value) => {
      if (!value) return;
      const parsed = JSON.parse(value) as { reports?: GuardianHistoryReport[]; cachedAt?: string };
      if (parsed.reports) setCachedReports(parsed.reports);
      if (parsed.cachedAt) { setCachedAt(parsed.cachedAt); setLastRefreshedAt(parsed.cachedAt); }
    }).catch(() => undefined);
  }, [isAuthenticated]);

  useEffect(() => {
    if (!history.data) return;
    const timestamp = new Date().toISOString();
    setCachedReports(history.data);
    setCachedAt(timestamp);
    setLastRefreshedAt(timestamp);
    AsyncStorage.setItem(HISTORY_CACHE_KEY, JSON.stringify({ reports: history.data, cachedAt: timestamp })).catch(() => undefined);
  }, [history.data]);

  const refreshHistory = async () => {
    if (!isOnline) return;
    setRefreshing(true);
    setRefreshError(false);
    try { await history.refetch(); } catch { setRefreshError(true); } finally { setRefreshing(false); }
  };
  useEffect(() => {
    if (!historyPreferencesLoaded) return;
    AsyncStorage.setItem(HISTORY_PREFERENCES_KEY, JSON.stringify({ severityFilter, sortOrder })).catch(() => undefined);
  }, [historyPreferencesLoaded, severityFilter, sortOrder]);

  const availableReports = history.data ?? cachedReports;
  const usingCachedReports = !history.data && cachedReports.length > 0;
  const filteredReports = useMemo(() => filterAndSortReports(availableReports, severityFilter, sortOrder), [availableReports, severityFilter, sortOrder]);
  const resetHistoryView = async () => { setSeverityFilter("All"); setSortOrder("newest"); setResetFeedback("Report history view reset to all severities, newest first."); if (Platform.OS !== "web" && (await AsyncStorage.getItem("guardian.setting.hapticsEnabled")) !== "false") await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} refreshControl={isAuthenticated ? <RefreshControl refreshing={refreshing} onRefresh={refreshHistory} tintColor={colors.primary} colors={[colors.primary]} /> : undefined}>
        <Link href="/profile" asChild><Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to profile"><Text style={styles.backText}>‹  Back to profile</Text></Pressable></Link>
        <Text style={styles.eyebrow}>YOUR REPORTS</Text>
        <Text style={styles.title}>Report history</Text>
        <Text style={styles.subtitle}>Follow the status of concerns submitted through Guardian.</Text>
        <View accessible accessibilityLabel={refreshing ? "Refreshing report history." : isOnline ? "Online. Pull down to refresh report history." : "Offline. Showing saved report history."} style={[styles.networkBanner, isOnline ? styles.networkOnline : styles.networkOffline]}><View style={[styles.networkDot, { backgroundColor: isOnline ? colors.success : colors.warning }]} /><Text style={styles.networkText}>{refreshing ? "Refreshing report history…" : isOnline ? "Online · pull to refresh" : "Offline · showing saved data"}</Text></View>
        {lastRefreshedAt && <Text accessibilityLabel={`Report history last refreshed at ${new Date(lastRefreshedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`} style={styles.freshnessText}>Last refreshed {new Date(lastRefreshedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</Text>}
        {refreshError && cachedReports.length > 0 && <View style={styles.errorBanner} accessible accessibilityLiveRegion="polite"><Text style={styles.errorTitle}>Couldn’t refresh right now</Text><Text style={styles.errorBody}>Your last successful history sync remains available{lastRefreshedAt ? ` · ${new Date(lastRefreshedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : ""}.</Text><Pressable onPress={refreshHistory} style={({ pressed }) => [styles.retryButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.retryText}>Try again</Text></Pressable></View>}
        {usingCachedReports && !refreshError && <View style={styles.staleBanner}><Text style={styles.staleIcon}>↻</Text><Text style={styles.staleText}>Showing your last saved history{cachedAt ? ` · ${new Date(cachedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : ""}. Pull to refresh when connected.</Text></View>}
        {authLoading ? <View style={styles.centerState}><ActivityIndicator color={colors.primary} /><Text style={styles.stateText}>Checking your account…</Text></View> : !isAuthenticated ? <GuestState styles={styles} /> : history.isLoading && cachedReports.length === 0 ? <View style={styles.centerState}><ActivityIndicator color={colors.primary} /><Text style={styles.stateText}>Loading your reports…</Text></View> : history.isError && cachedReports.length === 0 ? <View style={styles.emptyCard}><Text style={styles.emptyTitle}>History is temporarily unavailable</Text><Text style={styles.emptyBody}>Your local drafts are still safe on this device. Try again when you have a connection.</Text><Pressable onPress={refreshHistory} style={({ pressed }) => [styles.retryButton, pressed && styles.pressed]}><Text style={styles.retryText}>Try again</Text></Pressable></View> : availableReports.length ? <><HistoryControls severityFilter={severityFilter} setSeverityFilter={setSeverityFilter} sortOrder={sortOrder} setSortOrder={setSortOrder} historyPreferencesLoaded={historyPreferencesLoaded} onReset={resetHistoryView} styles={styles} colors={colors} />{resetFeedback && <View style={styles.confirmationBanner} accessible accessibilityLiveRegion="polite"><Text style={styles.confirmationText}>{resetFeedback}</Text><Pressable onPress={() => setResetFeedback(null)} accessibilityRole="button" accessibilityLabel="Dismiss report history reset confirmation" style={({ pressed }) => [styles.confirmationDismiss, pressed && styles.pressed]}><Text style={styles.confirmationDismissText}>Dismiss</Text></Pressable></View>}{filteredReports.length ? <View style={styles.list}>{filteredReports.map((report) => <ReportCard key={report.clientRequestId} report={report} styles={styles} colors={colors} />)}</View> : <View style={styles.emptyCard}><Text style={styles.emptyTitle}>No reports match these filters</Text><Text style={styles.emptyBody}>Try a different severity or sort option.</Text><Pressable onPress={() => setSeverityFilter("All")} style={({ pressed }) => [styles.retryButton, pressed && styles.pressed]}><Text style={styles.retryText}>Clear severity filter</Text></Pressable></View>}</> : <View style={styles.emptyCard}><Text style={styles.emptyTitle}>No submitted reports yet</Text><Text style={styles.emptyBody}>When you submit a non-emergency hazard report, its receipt and status timeline will appear here.</Text><Link href="/report" asChild><Pressable style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}><Text style={styles.primaryButtonText}>Report a hazard</Text></Pressable></Link></View>}
      </ScrollView>
    </ScreenContainer>
  );
}

function HistoryControls({ severityFilter, setSeverityFilter, sortOrder, setSortOrder, historyPreferencesLoaded, onReset, styles, colors }: { severityFilter: string; setSeverityFilter: (value: string) => void; sortOrder: "newest" | "oldest"; setSortOrder: (value: "newest" | "oldest") => void; historyPreferencesLoaded: boolean; onReset: () => void; styles: ReturnType<typeof createStyles>; colors: ReturnType<typeof useColors> }) {
  const severities = ["All", "Low", "Medium", "High"];
  return <View style={styles.controlsCard}><View style={styles.controlHeader}><View><Text style={styles.controlTitle}>Filter and sort</Text><Text style={styles.controlSummary} accessibilityLiveRegion="polite">Showing {severityFilter === "All" ? "all severities" : `${severityFilter.toLowerCase()} priority`} · {sortOrder === "newest" ? "newest first" : "oldest first"}</Text></View><View style={styles.controlHeaderActions}><Text style={styles.controlHint}>{historyPreferencesLoaded ? "Saved on this device" : "Loading preference…"}</Text><Pressable onPress={onReset} accessibilityRole="button" accessibilityLabel="Reset report history view" accessibilityHint="Returns to all severities and newest first." style={({ pressed }) => [styles.resetButton, pressed && styles.pressed]}><Text style={styles.resetButtonText}>Reset view</Text></Pressable></View></View><Text style={styles.controlLabel}>Severity</Text><View style={styles.chipRow} accessibilityRole="tablist" accessibilityLabel="Filter report history by severity">{severities.map((severity) => <Pressable key={severity} onPress={() => setSeverityFilter(severity)} accessibilityRole="tab" accessibilityState={{ selected: severityFilter === severity }} accessibilityLabel={`${severity} severity${severityFilter === severity ? ", selected" : ""}`} accessibilityHint={`Shows ${severity === "All" ? "reports of every severity" : `${severity.toLowerCase()} priority reports`}.`} style={({ pressed }) => [styles.chip, severityFilter === severity && styles.chipActive, pressed && styles.pressed]}><Text style={[styles.chipText, severityFilter === severity && styles.chipTextActive]}>{severity}</Text></Pressable>)}</View><Text style={styles.controlLabel}>Date</Text><View style={styles.chipRow} accessibilityRole="radiogroup" accessibilityLabel="Sort report history by date"><Pressable onPress={() => setSortOrder("newest")} accessibilityRole="radio" accessibilityState={{ selected: sortOrder === "newest" }} accessibilityLabel="Newest first" style={({ pressed }) => [styles.chip, sortOrder === "newest" && styles.chipActive, pressed && styles.pressed]}><Text style={[styles.chipText, sortOrder === "newest" && styles.chipTextActive]}>Newest first</Text></Pressable><Pressable onPress={() => setSortOrder("oldest")} accessibilityRole="radio" accessibilityState={{ selected: sortOrder === "oldest" }} accessibilityLabel="Oldest first" style={({ pressed }) => [styles.chip, sortOrder === "oldest" && styles.chipActive, pressed && styles.pressed]}><Text style={[styles.chipText, sortOrder === "oldest" && styles.chipTextActive]}>Oldest first</Text></Pressable></View></View>;
}

function GuestState({ styles }: { styles: ReturnType<typeof createStyles> }) {
  return <View style={styles.emptyCard}><View style={styles.lockIcon}><Text style={styles.lockText}>G</Text></View><Text style={styles.emptyTitle}>Sign in to track reports</Text><Text style={styles.emptyBody}>Guest mode keeps drafts on this device. Sign in when you want submitted reports and status updates to follow your account.</Text><Pressable onPress={() => { startOAuthLogin().catch(() => undefined); }} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.primaryButtonText}>Sign in to Guardian</Text></Pressable><Text style={styles.disclaimer}>You can continue reporting without an account.</Text></View>;
}

function ReportCard({ report, styles, colors }: { report: { category: string; severity: string; status: string; clientRequestId: string; createdAt: Date | string; updatedAt: Date | string }; styles: ReturnType<typeof createStyles>; colors: ReturnType<typeof useColors> }) {
  const tone = colors[statusColors[report.status] ?? "primary"];
  const created = new Date(report.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  const updated = new Date(report.updatedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const steps = ["received", "triaged", "in_progress", "resolved"];
  const activeIndex = Math.max(0, steps.indexOf(report.status));
  return <View style={styles.reportCard}><View style={styles.cardHeader}><View style={styles.categoryIcon}><Text style={styles.categoryIconText}>✓</Text></View><View style={styles.cardCopy}><Text style={styles.cardTitle}>{report.category}</Text><Text style={styles.cardMeta}>{report.severity} priority · Submitted {created}</Text></View><View style={[styles.statusPill, { backgroundColor: `${tone}18` }]}><Text style={[styles.statusPillText, { color: tone }]}>{statusLabels[report.status] ?? report.status}</Text></View></View><View style={styles.timeline}>{steps.map((step, index) => <View key={step} style={styles.timelineStep}><View style={[styles.timelineDot, index <= activeIndex && { backgroundColor: tone }, index < activeIndex && { borderColor: tone }]} />{index < steps.length - 1 && <View style={[styles.timelineLine, index < activeIndex && { backgroundColor: tone }]} />}<Text style={[styles.timelineText, index <= activeIndex && { color: colors.foreground }]}>{statusLabels[step]}</Text></View>)}</View><View style={styles.cardFooter}><Text style={styles.reference}>Ref {report.clientRequestId.slice(-10).toUpperCase()}</Text><Text style={styles.updated}>Updated {updated}</Text></View></View>;
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 13 }, networkBanner: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 7, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 }, networkOnline: { backgroundColor: "#EAF7EF" }, networkOffline: { backgroundColor: "#FFF7E8" }, networkDot: { width: 7, height: 7, borderRadius: 4 },     freshnessText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: -7 }, networkText: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "800" },     errorBanner: { backgroundColor: "#FFF1F0", borderColor: "#F2B8B5", borderWidth: 1, borderRadius: 13, padding: 11, gap: 3 }, errorTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, errorBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, staleBanner: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#FFF7E8", borderColor: "#F3D49B", borderWidth: 1, borderRadius: 13, padding: 11 }, staleIcon: { color: colors.warning, fontSize: scaleTextSize(16, largeText), fontWeight: "900" }, staleText: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 16, flex: 1 }, controlsCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 14, gap: 9 }, controlHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 10 }, controlHeaderActions: { alignItems: "flex-end", gap: 5 }, controlTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, controlHint: { color: colors.muted, fontSize: scaleTextSize(10, largeText) }, controlSummary: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", marginTop: 3 }, resetButton: { minHeight: 34, borderRadius: 9, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 9, alignItems: "center", justifyContent: "center" }, resetButtonText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, confirmationBanner: { flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: colors.success + "18", borderColor: colors.success + "55", borderWidth: 1, borderRadius: 12, padding: 10 }, confirmationText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800" }, confirmationDismiss: { minHeight: 34, borderRadius: 8, borderWidth: 1, borderColor: colors.success + "66", paddingHorizontal: 9, alignItems: "center", justifyContent: "center" }, confirmationDismissText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, controlLabel: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800", marginTop: 2 }, chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, chip: { minHeight: 40, borderRadius: 12, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 12, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }, chipActive: { backgroundColor: colors.primary, borderColor: colors.primary }, chipText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, chipTextActive: { color: "#FFFFFF" }, back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" }, backText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1, marginTop: 14 }, title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "900", marginTop: 2 }, subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginBottom: 5 }, list: { gap: 12 }, reportCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 15, gap: 14 }, cardHeader: { flexDirection: "row", alignItems: "center", gap: 10 }, categoryIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#E8F5F7", alignItems: "center", justifyContent: "center" }, categoryIconText: { color: colors.primary, fontSize: scaleTextSize(18, largeText), fontWeight: "900" }, cardCopy: { flex: 1 }, cardTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900" }, cardMeta: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: 3 }, statusPill: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 6 }, statusPillText: { fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, timeline: { flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 3 }, timelineStep: { flex: 1, alignItems: "center", position: "relative" }, timelineDot: { width: 11, height: 11, borderRadius: 6, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.surface, zIndex: 2 }, timelineLine: { height: 2, backgroundColor: colors.border, position: "absolute", top: 4, left: "50%", right: "-50%" }, timelineText: { color: colors.muted, fontSize: scaleTextSize(9, largeText), textAlign: "center", marginTop: 6 }, cardFooter: { flexDirection: "row", justifyContent: "space-between", borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 11 }, reference: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, updated: { color: colors.muted, fontSize: scaleTextSize(10, largeText) }, centerState: { alignItems: "center", justifyContent: "center", paddingVertical: 80, gap: 12 }, stateText: { color: colors.muted, fontSize: scaleTextSize(13, largeText) }, emptyCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 20, alignItems: "center", marginTop: 12 }, lockIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: colors.foreground, alignItems: "center", justifyContent: "center", marginBottom: 13 }, lockText: { color: "#FFFFFF", fontSize: scaleTextSize(24, largeText), fontWeight: "900" }, emptyTitle: { color: colors.foreground, fontSize: scaleTextSize(17, largeText), fontWeight: "900", textAlign: "center" }, emptyBody: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 19, textAlign: "center", marginTop: 7 }, primaryButton: { minHeight: 48, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 18, marginTop: 17, width: "100%" }, primaryButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, retryButton: { marginTop: 15, paddingVertical: 8 }, retryText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, disclaimer: { color: colors.muted, fontSize: scaleTextSize(10, largeText), textAlign: "center", marginTop: 12 }, pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
