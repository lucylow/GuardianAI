import { useLocalSearchParams, Link } from "expo-router";
import { useMemo } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

export default function AlertDetailScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const params = useLocalSearchParams<{ title?: string; body?: string; source?: string; time?: string }>();
  const title = params.title ?? "Safety alert";
  const body = params.body ?? "Review the latest official guidance and follow recommended actions.";
  const source = params.source ?? "Guardian verified source";
  const time = params.time ?? "Freshness unavailable";
  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/alerts" asChild><Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to alerts"><Text style={styles.backText}>‹  Back to alerts</Text></Pressable></Link>
        <View style={styles.badge}><Text style={styles.badgeText}>CURRENT UPDATE</Text></View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.meta}>{source}  •  {time}</Text>
        <View style={styles.heroCard}><Text style={styles.heroLabel}>WHAT TO KNOW</Text><Text style={styles.heroBody}>{body}</Text></View>
        <Text style={styles.sectionTitle}>Recommended actions</Text>
        <View style={styles.action}><Text style={styles.actionNumber}>01</Text><Text style={styles.actionText}>Check official updates before changing plans or traveling.</Text></View>
        <View style={styles.action}><Text style={styles.actionNumber}>02</Text><Text style={styles.actionText}>Share only verified information with neighbors and family.</Text></View>
        <View style={styles.action}><Text style={styles.actionNumber}>03</Text><Text style={styles.actionText}>Call 911 if the situation becomes an immediate emergency.</Text></View>
        <View style={styles.sourceCard}><Text style={styles.sourceLabel}>SOURCE</Text><Text style={styles.sourceName}>{source}</Text><Text style={styles.sourceNote}>Guardian displays source and freshness so you can make an informed decision.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 13 },
    back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" },
    backText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    badge: { alignSelf: "flex-start", backgroundColor: colors.warning + "20", borderRadius: 8, paddingHorizontal: 9, paddingVertical: 6, marginTop: 16 },
    badgeText: { color: colors.warning, fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 0.8 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "900", lineHeight: 35, marginTop: 2 },
    meta: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 },
    heroCard: { backgroundColor: colors.foreground, borderRadius: 18, padding: 17, marginTop: 8 },
    heroLabel: { color: "#A8DCE5", fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 1 },
    heroBody: { color: "#FFFFFF", fontSize: scaleTextSize(18, largeText), lineHeight: 27, fontWeight: "700", marginTop: 9 },
    sectionTitle: { color: colors.foreground, fontSize: scaleTextSize(16, largeText), fontWeight: "900", marginTop: 9 },
    action: { flexDirection: "row", gap: 13, paddingVertical: 12, borderBottomColor: colors.border, borderBottomWidth: 1 },
    actionNumber: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900", width: 22 },
    actionText: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 19, flex: 1 },
    sourceCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 16, marginTop: 10 },
    sourceLabel: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 1 },
    sourceName: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900", marginTop: 7 },
    sourceNote: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 5 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
