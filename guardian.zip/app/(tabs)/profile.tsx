import { ProfileScreen } from "@/components/guardian/profile-screen";

export default ProfileScreen;
