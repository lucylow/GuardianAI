import { AlertsScreen } from "@/components/guardian/alerts-screen";

export default AlertsScreen;
