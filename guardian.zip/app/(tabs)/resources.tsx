import { ResourcesScreen } from "@/components/guardian/resources-screen";

export default ResourcesScreen;
