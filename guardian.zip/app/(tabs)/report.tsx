import { ReportScreen } from "@/components/guardian/report-screen";

export default ReportScreen;
