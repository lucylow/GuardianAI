import { Link, useFocusEffect } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { readAutoRetryPaused, readQueuedReports, type GuardianQueuedReport } from "@/lib/guardian-queue";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

const needsManualAttention = (report: GuardianQueuedReport) => Boolean(report.autoRetryExhausted || (report.lastFailureReason && !report.nextRetryAt));

const quickActions = [
  { label: "Report hazard", detail: "Potholes, flooding, ice", href: "/report" as const, icon: "＋" },
  { label: "View alerts", detail: "Weather and city updates", href: "/alerts" as const, icon: "!" },
  { label: "Find resources", detail: "Shelters, 311, services", href: "/resources" as const, icon: "⌖" },
];

const signalCards = [
  { title: "Local conditions", value: "Clear", detail: "No active weather warning", tone: "success" as const },
  { title: "Community reports", value: "12 open", detail: "Across Indianapolis today", tone: "primary" as const },
];

export default function HomeScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const [queuedReports, setQueuedReports] = useState<GuardianQueuedReport[]>([]);
  const [autoRetryPaused, setAutoRetryPaused] = useState(false);
  const [queueLastSyncedAt, setQueueLastSyncedAt] = useState<number | null>(null);
  const [isRefreshingQueue, setIsRefreshingQueue] = useState(false);
  const hasQueuedReport = queuedReports.length > 0;
  const failedCount = queuedReports.filter((report) => needsManualAttention(report)).length;
  const scheduledCount = queuedReports.filter((report) => report.nextRetryAt && new Date(report.nextRetryAt).getTime() > Date.now()).length;

  const refreshQueue = useCallback(async (showFeedback = false) => {
    if (showFeedback) setIsRefreshingQueue(true);
    try {
      const [reports, paused] = await Promise.all([readQueuedReports(), readAutoRetryPaused()]);
      setQueuedReports(reports);
      setAutoRetryPaused(paused);
      setQueueLastSyncedAt(Date.now());
    } finally {
      if (showFeedback) setIsRefreshingQueue(false);
    }
  }, []);

  useFocusEffect(useCallback(() => {
    void refreshQueue();
  }, [refreshQueue]));

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>INDIANAPOLIS • SAFETY HUB</Text>
            <Text style={styles.title}>Good morning.</Text>
            <Text style={styles.subtitle}>Stay informed. Help your neighborhood.</Text>
          </View>
          <Link href="/profile" asChild>
            <Pressable style={({ pressed }) => [styles.profileButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Open profile and settings">
              <Text style={styles.profileInitial}>G</Text>
            </Pressable>
          </Link>
        </View>

        <View style={styles.emergencyCard}>
          <View style={styles.emergencyCopy}>
            <Text style={styles.emergencyKicker}>IMMEDIATE DANGER?</Text>
            <Text style={styles.emergencyTitle}>Call 911 first.</Text>
            <Text style={styles.emergencyBody}>Guardian helps with information and non-emergency reporting.</Text>
          </View>
          <Link href="/emergency" asChild>
            <Pressable style={({ pressed }) => [styles.callButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Open emergency mode to call 911">
              <Text style={styles.callButtonText}>CALL 911</Text>
            </Pressable>
          </Link>
        </View>

        {hasQueuedReport && <><Link href="/outbox" asChild><Pressable style={({ pressed }) => [styles.queueBanner, failedCount > 0 && styles.queueBannerAttention, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Open Outbox. ${queuedReports.length} queued, ${failedCount} needing attention, ${scheduledCount} scheduled for retry. ${queueLastSyncedAt ? `Status last synchronized at ${new Date(queueLastSyncedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}.` : "Status is synchronizing."}`}><View style={styles.queueBadge}><Text style={styles.queueBadgeText}>!</Text></View><View style={styles.queueCopy}><Text style={styles.queueTitle}>{queuedReports.length} report{queuedReports.length === 1 ? "" : "s"} waiting to send</Text><Text style={styles.queueDetail}>{failedCount > 0 ? `${failedCount} need${failedCount === 1 ? "s" : ""} manual attention` : scheduledCount > 0 ? `${scheduledCount} scheduled to retry automatically` : "Ready to retry when you are online"} · {queueLastSyncedAt ? `Updated ${new Date(queueLastSyncedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : "Synchronizing"} · Open Outbox for recovery.</Text></View><Text style={styles.chevron}>›</Text></Pressable></Link><Pressable onPress={() => void refreshQueue(true)} disabled={isRefreshingQueue} accessibilityRole="button" accessibilityLabel={isRefreshingQueue ? "Refreshing local retry status" : "Refresh local retry status"} style={({ pressed }) => [styles.refreshStatusButton, isRefreshingQueue && styles.disabled, pressed && styles.pressed]}><Text style={styles.refreshStatusText}>{isRefreshingQueue ? "Refreshing local status…" : "Refresh local status"}</Text></Pressable></>}
        {autoRetryPaused && <Link href="/outbox" asChild><Pressable style={({ pressed }) => [styles.pauseBanner, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Automatic retries are paused. Open Outbox to resume them"><View style={styles.pauseBadge}><Text style={styles.pauseBadgeText}>Ⅱ</Text></View><View style={styles.queueCopy}><Text style={styles.pauseTitle}>Automatic retries paused</Text><Text style={styles.queueDetail}>Queued reports remain safe. Open Outbox to resume automatic sending.</Text></View><Text style={styles.chevron}>›</Text></Pressable></Link>}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Quick actions</Text>
          <Text style={styles.sectionHint}>One tap away</Text>
        </View>
        <View style={styles.quickGrid}>
          {quickActions.map((action) => (
            <Link key={action.label} href={action.href} asChild>
              <Pressable style={({ pressed }) => [styles.actionCard, pressed && styles.actionCardPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`${action.label}. ${action.detail}`} accessibilityHint="Opens this Guardian section.">
                <View style={styles.actionIcon}><Text style={styles.actionIconText}>{action.icon}</Text></View>
                <Text style={styles.actionLabel}>{action.label}</Text>
                <Text style={styles.actionDetail}>{action.detail}</Text>
                <Text style={styles.actionChevron} accessibilityElementsHidden>›</Text>
              </Pressable>
            </Link>
          ))}
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Neighborhood pulse</Text>
          <Text style={styles.sectionHint}>Updated just now</Text>
        </View>
        <View style={styles.signalRow}>
          {signalCards.map((card) => (
            <View key={card.title} style={styles.signalCard}>
              <View style={styles.signalHeader}>
                <Text style={styles.signalTitle}>{card.title}</Text>
                <View style={[styles.signalDot, { backgroundColor: card.tone === "success" ? colors.success : colors.primary }]} />
              </View>
              <Text style={styles.signalValue}>{card.value}</Text>
              <Text style={styles.signalDetail}>{card.detail}</Text>
            </View>
          ))}
        </View>

        <Link href="/alerts" asChild>
          <Pressable style={({ pressed }) => [styles.alertBanner, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="View the latest safety alerts">
            <View style={styles.alertBadge}><Text style={styles.alertBadgeText}>!</Text></View>
            <View style={styles.alertBannerCopy}>
              <Text style={styles.alertBannerTitle}>Stay ready for change</Text>
              <Text style={styles.alertBannerDetail}>See official updates, weather notices, and neighborhood reports.</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </Pressable>
        </Link>

        <View style={styles.footerNote}>
          <Text style={styles.footerNoteTitle}>No internet? You still have options.</Text>
          <Text style={styles.footerNoteBody}>Your drafts stay on this device. You can also use SMS from the report flow.</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    scrollContent: { paddingTop: 22, paddingBottom: 36, gap: 20 },
    header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.2 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "800", marginTop: 7, letterSpacing: -0.5 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(14, largeText), marginTop: 5 },
    profileButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
    profileInitial: { color: "#FFFFFF", fontSize: scaleTextSize(16, largeText), fontWeight: "800" },
    emergencyCard: { backgroundColor: colors.foreground, borderRadius: 22, padding: 19, flexDirection: "row", alignItems: "center", gap: 16, elevation: 3 },
    emergencyCopy: { flex: 1 },
    emergencyKicker: { color: "#FFB4B4", fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1 },
    emergencyTitle: { color: "#FFFFFF", fontSize: scaleTextSize(21, largeText), fontWeight: "800", marginTop: 5 },
    emergencyBody: { color: "#C9D6E3", fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 5 },
    callButton: { backgroundColor: colors.error, borderRadius: 14, minHeight: 52, minWidth: 92, paddingHorizontal: 16, alignItems: "center", justifyContent: "center" },
    callButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(13, largeText), fontWeight: "900", letterSpacing: 0.5 },
    sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline" },
    sectionTitle: { color: colors.foreground, fontSize: scaleTextSize(18, largeText), fontWeight: "800" },
    sectionHint: { color: colors.muted, fontSize: scaleTextSize(12, largeText) },
    quickGrid: { flexDirection: "row", gap: 10 },
    actionCard: { flex: 1, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 15, minHeight: 126, elevation: 1 },
    actionCardPressed: { backgroundColor: colors.primary + "12", borderColor: colors.primary },
    actionIcon: { width: 30, height: 30, borderRadius: 10, backgroundColor: colors.primary + "18", alignItems: "center", justifyContent: "center", marginBottom: 12 },
    actionIconText: { color: colors.primary, fontSize: scaleTextSize(20, largeText), fontWeight: "700" },
    actionLabel: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    actionDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 5 },
    actionChevron: { color: colors.primary, fontSize: scaleTextSize(22, largeText), lineHeight: 22, fontWeight: "300", alignSelf: "flex-end", marginTop: 4 },
    signalRow: { flexDirection: "row", gap: 10 },
    signalCard: { flex: 1, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 16, minHeight: 96, elevation: 1 },
    signalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
    signalTitle: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "700" },
    signalDot: { width: 8, height: 8, borderRadius: 4 },
    signalValue: { color: colors.foreground, fontSize: scaleTextSize(19, largeText), fontWeight: "800", marginTop: 12 },
    signalDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 15, marginTop: 3 },
    queueBanner: { backgroundColor: "#FFF7E8", borderColor: "#F3D49B", borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
    queueBannerAttention: { backgroundColor: "#FFF0F0", borderColor: colors.error + "55" },
    refreshStatusButton: { alignSelf: "flex-start", minHeight: 34, borderColor: colors.border, borderWidth: 1, borderRadius: 10, paddingHorizontal: 11, justifyContent: "center" },
    refreshStatusText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    disabled: { opacity: 0.55 },
    pauseBanner: { backgroundColor: "#F3F0FF", borderColor: "#D7CCFF", borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
    pauseBadge: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
    pauseBadgeText: { color: "#FFFFFF", fontSize: scaleTextSize(15, largeText), fontWeight: "900" },
    pauseTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    queueBadge: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.warning, alignItems: "center", justifyContent: "center" },
    queueBadgeText: { color: "#FFFFFF", fontSize: scaleTextSize(18, largeText), fontWeight: "900" },
    queueCopy: { flex: 1 },
    queueTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    queueDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 3 },
    alertBanner: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 17, padding: 15, minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12 },
    alertBadge: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.warning, alignItems: "center", justifyContent: "center" },
    alertBadgeText: { color: "#FFFFFF", fontSize: scaleTextSize(19, largeText), fontWeight: "900" },
    alertBannerCopy: { flex: 1 },
    alertBannerTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    alertBannerDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 3 },
    chevron: { color: colors.primary, fontSize: scaleTextSize(27, largeText), fontWeight: "300" },
    footerNote: { borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 16 },
    footerNoteTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "800" },
    footerNoteBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 4 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
