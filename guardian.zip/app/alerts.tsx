import { Link } from "expo-router";
import { useMemo } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const alerts = [
  { title: "Weather and city updates", detail: "Review official conditions before changing plans or traveling.", source: "Indianapolis safety desk", time: "Updated today", tone: "warning" as const },
  { title: "Neighborhood reports", detail: "See recent non-emergency reports and follow verified updates.", source: "Guardian community feed", time: "Updated today", tone: "primary" as const },
  { title: "Emergency guidance", detail: "Call 911 first when there is immediate danger or a life-threatening situation.", source: "Emergency guidance", time: "Always available", tone: "error" as const },
];

export default function AlertsScreen() {
  const colors = useColors();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/(tabs)" asChild>
          <Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to home">
            <Text style={styles.backText}>‹  Back to home</Text>
          </Pressable>
        </Link>
        <Text style={styles.eyebrow}>INDIANAPOLIS SAFETY UPDATES</Text>
        <View style={styles.titleRow}>
          <View style={styles.titleCopy}>
            <Text style={styles.title}>Stay ready for change</Text>
            <Text style={styles.subtitle}>Official guidance and community context in one calm, readable view.</Text>
          </View>
          <View style={styles.countBadge}><Text style={styles.countBadgeText}>{alerts.length}</Text></View>
        </View>

        <View style={styles.infoCard} accessible accessibilityRole="summary">
          <View style={styles.infoIcon}><Text style={styles.infoIconText}>!</Text></View>
          <View style={styles.infoCopy}>
            <Text style={styles.infoTitle}>Read the source and freshness</Text>
            <Text style={styles.infoBody}>Guardian separates official guidance from community context so you can decide what to do next.</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Latest updates</Text>
        <View style={styles.list}>
          {alerts.map((alert) => (
            <Link key={alert.title} href={{ pathname: "/alert-detail", params: { title: alert.title, body: alert.detail, source: alert.source, time: alert.time } }} asChild>
              <Pressable style={({ pressed }) => [styles.alertCard, pressed && styles.alertCardPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`${alert.title}. ${alert.detail}`} accessibilityHint="Opens the full alert details.">
                <View style={[styles.alertMarker, { backgroundColor: alert.tone === "error" ? colors.error : alert.tone === "warning" ? colors.warning : colors.primary }]} />
                <View style={styles.alertCopy}>
                  <View style={styles.alertHeader}><Text style={styles.alertTitle}>{alert.title}</Text><Text style={styles.chevron}>›</Text></View>
                  <Text style={styles.alertDetail}>{alert.detail}</Text>
                  <Text style={styles.alertMeta}>{alert.source}  ·  {alert.time}</Text>
                </View>
              </Pressable>
            </Link>
          ))}
        </View>

        <Link href="/emergency" asChild>
          <Pressable style={({ pressed }) => [styles.emergencyLink, pressed && styles.emergencyLinkPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Open emergency guidance" accessibilityHint="Opens emergency guidance and 911-first instructions.">
            <Text style={styles.emergencyLinkTitle}>Immediate danger?</Text>
            <Text style={styles.emergencyLinkBody}>Call 911 first. Open emergency guidance for next steps.</Text>
            <Text style={styles.emergencyLinkAction}>Open emergency guidance  ›</Text>
          </Pressable>
        </Link>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 36, gap: 14 },
    back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" },
    backText: { color: colors.primary, fontSize: 13, fontWeight: "900" },
    eyebrow: { color: colors.primary, fontSize: 11, fontWeight: "800", letterSpacing: 1.1, marginTop: 12 },
    titleRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
    titleCopy: { flex: 1 },
    title: { color: colors.foreground, fontSize: 29, lineHeight: 34, fontWeight: "900", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: 13, lineHeight: 19, marginTop: 6 },
    countBadge: { minWidth: 36, height: 36, borderRadius: 18, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", marginTop: 3 },
    countBadgeText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
    infoCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 18, padding: 15 },
    infoIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
    infoIconText: { color: "#FFFFFF", fontSize: 18, fontWeight: "900" },
    infoCopy: { flex: 1, gap: 3 },
    infoTitle: { color: colors.foreground, fontSize: 13, fontWeight: "900" },
    infoBody: { color: colors.muted, fontSize: 11, lineHeight: 16 },
    sectionTitle: { color: colors.foreground, fontSize: 16, fontWeight: "900", marginTop: 5 },
    list: { gap: 10 },
    alertCard: { flexDirection: "row", gap: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 15, elevation: 1 },
    alertCardPressed: { backgroundColor: colors.primary + "12", borderColor: colors.primary },
    alertMarker: { width: 6, borderRadius: 4, alignSelf: "stretch", minHeight: 68 },
    alertCopy: { flex: 1, gap: 5 },
    alertHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
    alertTitle: { color: colors.foreground, fontSize: 14, fontWeight: "900", flex: 1 },
    alertDetail: { color: colors.muted, fontSize: 12, lineHeight: 17 },
    alertMeta: { color: colors.primary, fontSize: 10, fontWeight: "800", marginTop: 2 },
    chevron: { color: colors.primary, fontSize: 24, fontWeight: "300" },
    emergencyLink: { backgroundColor: colors.foreground, borderRadius: 18, padding: 16, marginTop: 4 },
    emergencyLinkPressed: { backgroundColor: colors.foreground + "E6" },
    emergencyLinkTitle: { color: "#FFB4B4", fontSize: 11, fontWeight: "900", letterSpacing: 0.8 },
    emergencyLinkBody: { color: "#FFFFFF", fontSize: 14, fontWeight: "800", marginTop: 5 },
    emergencyLinkAction: { color: "#A8DCE5", fontSize: 11, fontWeight: "900", marginTop: 10 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
