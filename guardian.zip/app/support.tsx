import AsyncStorage from "@react-native-async-storage/async-storage";
import { Link } from "expo-router";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useEffect, useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { GuardianStatusCard } from "@/components/guardian/status-card";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";
import { trpc } from "@/lib/trpc";

const SUPPORT_INTENT_KEY = "guardian.support.intent";
type SupportIntent = "monthly" | "annual" | "donation";

export default function SupportGuardianScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = createStyles(colors, largeText);
  const paymentStatus = trpc.support.status.useQuery();
  const paymentsEnabled = paymentStatus.data?.enabled === true;
  const [selectedIntent, setSelectedIntent] = useState<SupportIntent | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(SUPPORT_INTENT_KEY).then((value) => {
      if (value === "monthly" || value === "annual" || value === "donation") setSelectedIntent(value);
    }).catch(() => undefined);
  }, []);

  const clearSupportIntent = () => {
    Alert.alert("Clear saved support interest?", "This removes only the support preference saved on this device. It does not affect payments, reports, drafts, or activity history.", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear", style: "destructive", onPress: () => { AsyncStorage.removeItem(SUPPORT_INTENT_KEY).catch(() => undefined); setSelectedIntent(null); } },
    ]);
  };

  const explainPaymentSetup = () => {
    Alert.alert("Payment setup unavailable", "A Guardian administrator must configure Stripe test credentials and webhook verification before supporters can be charged. No action is required from you, and core safety features remain free.");
  };

  const paymentUnavailable = (intent: SupportIntent) => {
    setSelectedIntent(intent);
    AsyncStorage.setItem(SUPPORT_INTENT_KEY, intent).catch(() => undefined);
    Alert.alert(
      "Payments are not enabled yet",
      "Guardian is ready for optional supporter payments, but Stripe credentials have not been configured. Core safety features remain free and available."
    );
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/profile" asChild>
          <Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to profile">
            <Text style={styles.backText}>‹  Back to profile</Text>
          </Pressable>
        </Link>
        <Text style={styles.eyebrow}>OPTIONAL SUPPORT</Text>
        <Text style={styles.title}>Support Guardian</Text>
        <Text style={styles.subtitle}>Help keep civic safety tools accessible for Indianapolis neighbors.</Text>

        {!paymentsEnabled && <GuardianStatusCard title="Support payments are not active yet" body={paymentStatus.data?.message ?? "Stripe payment setup is pending. You can still use every core safety feature for free."} meta="When enabled: secure PaymentSheet → verified server payment → receipt and supporter status. No card numbers are stored in Guardian." badge="Not active" tone="warning" accessibilityLabel="Support payments are not active yet. Core safety features remain free."><Pressable onPress={explainPaymentSetup} style={({ pressed }) => [styles.setupButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Learn why payment setup is unavailable"><Text style={styles.setupButtonText}>Why is this unavailable?</Text></Pressable></GuardianStatusCard>}
        {selectedIntent && <View style={styles.intentCard} accessible accessibilityLabel={`Saved support interest: ${selectedIntent === "monthly" ? "monthly supporter" : selectedIntent === "annual" ? "annual supporter" : "one-time donation"}`}><Text style={styles.intentTitle}>Your saved support interest</Text><Text style={styles.statusPill}>Interest saved · not subscribed</Text><Text style={styles.intentBody}>{selectedIntent === "monthly" ? "Monthly supporter" : selectedIntent === "annual" ? "Annual supporter" : "One-time donation"}. This is stored only on this device and is not a payment or commitment.</Text><Pressable onPress={clearSupportIntent} style={({ pressed }) => [styles.clearIntentButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.clearIntentText}>Clear saved interest</Text></Pressable></View>}

        <View style={styles.benefitCard} accessible accessibilityLabel="Supporter benefits summary"><Text style={styles.benefitTitle}>What support helps fund</Text><Text style={styles.benefitBody}>Your optional support helps maintain offline reliability, accessibility improvements, civic data review, and neighborhood safety education.</Text></View>

        <GuardianStatusCard title="Core safety stays free" body="Emergency guidance, 911 access, hazard reporting, offline drafts, alerts, and SMS fallback are never locked behind payment." badge="Always free" tone="success" accessibilityLabel="Core safety features remain free. Emergency guidance, hazard reporting, offline drafts, alerts, and SMS fallback are never locked behind payment." />

        <Text style={styles.sectionTitle}>Supporter plans</Text>
        <View style={styles.planCard}>
          <View style={styles.planHeader}><Text style={styles.planName}>Monthly supporter</Text><Text style={styles.planPrice}>$4.99 / month</Text></View>
          <Text style={styles.planDetail}>Help fund maintenance, accessibility improvements, and neighborhood safety research.</Text>
          <Pressable onPress={() => paymentUnavailable("monthly")} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Choose monthly supporter plan">
            <Text style={styles.primaryButtonText}>Choose monthly</Text>
          </Pressable>
        </View>
        <View style={styles.planCard}>
          <View style={styles.planHeader}><Text style={styles.planName}>Annual supporter</Text><Text style={styles.planPrice}>$49.99 / year</Text></View>
          <Text style={styles.planDetail}>A lower-cost yearly way to sustain Guardian’s free safety mission.</Text>
          <Pressable onPress={() => paymentUnavailable("annual")} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Choose annual supporter plan">
            <Text style={styles.secondaryButtonText}>Choose annual</Text>
          </Pressable>
        </View>

        <Text style={styles.sectionTitle}>One-time donation</Text>
        <View style={styles.donationCard}>
          <Text style={styles.donationTitle}>Give what works for you</Text>
          <Text style={styles.donationBody}>Make a one-time contribution without creating a recurring commitment.</Text>
          <Pressable onPress={() => paymentUnavailable("donation")} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Make a one-time donation">
            <Text style={styles.secondaryButtonText}>Donate once</Text>
          </Pressable>
        </View>

        <Text style={styles.disclaimer}>Payments will use Stripe’s secure payment interface when enabled. Guardian will not store card numbers. You can continue using every core safety feature without supporting financially.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 22, paddingBottom: 40, gap: 14 },
    back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" },
    backText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1, marginTop: 14 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "800", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginBottom: 8 },
    disabledCard: { backgroundColor: "#FFF7E8", borderColor: "#F3D49B", borderWidth: 1, borderRadius: 17, padding: 14 },
    disabledTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    disabledBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 4 },
    disabledStep: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 8, fontWeight: "800" },
    disabledNote: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, marginTop: 5 },
    setupButton: { alignSelf: "flex-start", paddingTop: 9 },
    setupButtonText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    benefitCard: { backgroundColor: "#EEF7F1", borderColor: "#C6E5CF", borderWidth: 1, borderRadius: 17, padding: 14 },
    benefitTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    benefitBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 4 },
    intentCard: { backgroundColor: "#F0ECFF", borderColor: "#D9D0FF", borderWidth: 1, borderRadius: 17, padding: 14 },
    intentTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    statusPill: { alignSelf: "flex-start", color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900", marginTop: 6 },
    intentBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 4 },
    clearIntentButton: { alignSelf: "flex-start", paddingTop: 9 },
    clearIntentText: { color: colors.error, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    freeCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 17, padding: 16 },
    freeTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900" },
    freeBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 18, marginTop: 5 },
    sectionTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900", marginTop: 6 },
    planCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 17, gap: 9, elevation: 1 },
    planHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 8 },
    planName: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900", flex: 1 },
    planPrice: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    planDetail: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17 },
    primaryButton: { minHeight: 46, borderRadius: 13, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 3 },
    primaryButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    secondaryButton: { minHeight: 46, borderRadius: 13, borderWidth: 1, borderColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 3 },
    secondaryButtonText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    donationCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 17, gap: 8, elevation: 1 },
    donationTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900" },
    donationBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17 },
    disclaimer: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, textAlign: "center", marginTop: 4 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}

