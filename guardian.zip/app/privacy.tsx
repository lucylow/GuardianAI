import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Sharing from "expo-sharing";
import { Link } from "expo-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useAuth } from "@/hooks/use-auth";
import { trpc } from "@/lib/trpc";
import { buildGuardianExportFilename, serializeGuardianExport } from "@/lib/guardian-export";
import { appendActivityEvent, clearBatchSummary, OUTBOX_ACTIVITY_KEY, readActivityEvents, readBatchSummary, setBatchSummary, type GuardianBatchSummary } from "@/lib/guardian-queue";
import { useColors } from "@/hooks/use-colors";

const LOCAL_PREFIXES = ["guardian.report.", "guardian.setting."];
const LOCAL_EXACT_KEYS = ["guardian.report.draft"];
const LABEL_CACHE_KEY = "guardian.report.geocodedLabel";
const LABEL_CACHE_PREFIX = "guardian.report.geocodedLabel";
const HAPTICS_KEY = "guardian.setting.hapticsEnabled";

export default function PrivacyScreen() {
  const colors = useColors();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const [localCount, setLocalCount] = useState(0);
  const [activityCount, setActivityCount] = useState(0);
  const [batchSummary, setBatchSummaryState] = useState<GuardianBatchSummary | null>(null);
  const [recentlyClearedSummary, setRecentlyClearedSummary] = useState<GuardianBatchSummary | null>(null);
  const [cachedLabelRefreshedAt, setCachedLabelRefreshedAt] = useState<number | null>(null);
  const [cachedLabelMessage, setCachedLabelMessage] = useState<string | null>(null);
  const [recentlyClearedLabels, setRecentlyClearedLabels] = useState<[string, string][] | null>(null);
  const [undoSecondsLeft, setUndoSecondsLeft] = useState(0);
  const [hapticsEnabled, setHapticsEnabled] = useState(true);
  const [loading, setLoading] = useState(true);
  const { isAuthenticated } = useAuth();
  const exportQuery = trpc.reports.exportData.useQuery(undefined, { enabled: false, retry: false });

  const refreshCount = useCallback(async () => {
    setLoading(true);
    try {
      const [keys, activityEvents, storedBatchSummary, cachedLabelValue, storedHaptics] = await Promise.all([AsyncStorage.getAllKeys(), readActivityEvents(), readBatchSummary(), AsyncStorage.getItem(LABEL_CACHE_KEY), AsyncStorage.getItem(HAPTICS_KEY)]);
      setLocalCount(keys.filter((key) => LOCAL_EXACT_KEYS.includes(key) || LOCAL_PREFIXES.some((prefix) => key.startsWith(prefix))).length);
      setActivityCount(activityEvents.length);
      setBatchSummaryState(storedBatchSummary);
      setHapticsEnabled(storedHaptics !== "false");
      if (cachedLabelValue) { try { const cached = JSON.parse(cachedLabelValue) as { refreshedAt?: number }; setCachedLabelRefreshedAt(cached.refreshedAt ?? null); } catch { setCachedLabelRefreshedAt(null); } } else setCachedLabelRefreshedAt(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refreshCount(); }, [refreshCount]);

  useEffect(() => {
    if (!recentlyClearedLabels) return;
    setUndoSecondsLeft(6);
    const timer = setInterval(() => setUndoSecondsLeft((seconds) => { if (seconds <= 1) { setRecentlyClearedLabels(null); return 0; } return seconds - 1; }), 1000);
    return () => clearInterval(timer);
  }, [recentlyClearedLabels]);

  const exportData = async () => {
    if (!isAuthenticated) {
      Alert.alert("Sign in to export", "Report exports include submitted account data and are available after sign-in.");
      return;
    }
    try {
      const result = await exportQuery.refetch();
      if (!result.data) throw new Error("No export data returned");
      const json = serializeGuardianExport(result.data);
      if (typeof window !== "undefined" && window.document) {
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const anchor = window.document.createElement("a");
        anchor.href = url;
        anchor.download = buildGuardianExportFilename();
        anchor.click();
        URL.revokeObjectURL(url);
        return;
      }
      const FileSystem = await import("expo-file-system/legacy");
      const fileUri = `${FileSystem.cacheDirectory}${buildGuardianExportFilename()}`;
      await FileSystem.writeAsStringAsync(fileUri, json, { encoding: FileSystem.EncodingType.UTF8 });
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert("Export created", "Sharing is unavailable on this device, but the JSON export is ready in Guardian's temporary files.");
        return;
      }
      await Sharing.shareAsync(fileUri, { mimeType: "application/json", dialogTitle: "Export Guardian report data" });
    } catch {
      Alert.alert("Export unavailable", "We could not prepare your report data right now. Try again when you have a connection.");
    }
  };

  const clearActivityHistory = () => {
    Alert.alert("Clear Outbox activity?", "This removes only recent queue and retry events from this device. Queued reports, drafts, receipts, and report history will not be changed.", [
      { text: "Keep activity", style: "cancel" },
      { text: "Clear activity", style: "destructive", onPress: async () => {
        await AsyncStorage.removeItem(OUTBOX_ACTIVITY_KEY);
        setActivityCount(0);
        Alert.alert("Activity cleared", "Your queued reports and report data were not changed.");
      } },
    ]);
  };

  const clearBatchSummaryFromPrivacy = () => {
    if (!batchSummary) return;
    Alert.alert("Clear recent batch summary?", "This removes only the local summary. Queued reports, drafts, receipts, and activity history will stay unchanged.", [
      { text: "Keep summary", style: "cancel" },
      { text: "Clear summary", style: "destructive", onPress: async () => { await clearBatchSummary(); setRecentlyClearedSummary(batchSummary); setBatchSummaryState(null); } },
    ]);
  };

  const undoBatchSummaryClear = async () => {
    if (!recentlyClearedSummary) return;
    await setBatchSummary(recentlyClearedSummary);
    setBatchSummaryState(recentlyClearedSummary);
    setRecentlyClearedSummary(null);
  };

  const clearCachedLabel = () => {
    Alert.alert("Clear all location suggestions?", "This removes all locally cached street or intersection suggestions. Drafts, coordinates, reports, receipts, and preferences will stay unchanged.", [
      { text: "Keep label", style: "cancel" },
      { text: "Clear label", style: "destructive", onPress: async () => { const keys = (await AsyncStorage.getAllKeys()).filter((key) => key.startsWith(LABEL_CACHE_PREFIX)); const pairs = (await AsyncStorage.multiGet(keys)).filter((entry): entry is [string, string] => typeof entry[0] === "string" && typeof entry[1] === "string"); if (pairs.length === 0) return; await AsyncStorage.multiRemove(keys); setRecentlyClearedLabels(pairs); setCachedLabelRefreshedAt(null); setCachedLabelMessage(`${pairs.length} cached location suggestion${pairs.length === 1 ? "" : "s"} cleared. Coordinates and drafts were not changed.`); await appendActivityEvent("location_label_cleared"); await refreshCount(); } },
    ]);
  };

  const undoCachedLabelClear = async () => {
    if (!recentlyClearedLabels) return;
    await AsyncStorage.multiSet(recentlyClearedLabels);
    setRecentlyClearedLabels(null);
    setUndoSecondsLeft(0);
    setCachedLabelMessage("Nearby label restored. Other local data was unchanged.");
    await appendActivityEvent("location_label_restored");
    await refreshCount();
  };

  const toggleHaptics = async (enabled: boolean) => {
    setHapticsEnabled(enabled);
    await AsyncStorage.setItem(HAPTICS_KEY, String(enabled));
  };

  const clearLocalData = () => {
    Alert.alert("Clear local Guardian data?", "This removes drafts, local report receipts, and saved preferences from this device. Submitted reports stored on the server are not deleted.", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear local data", style: "destructive", onPress: async () => {
        const keys = await AsyncStorage.getAllKeys();
        const removable = keys.filter((key) => LOCAL_EXACT_KEYS.includes(key) || LOCAL_PREFIXES.some((prefix) => key.startsWith(prefix)));
        await AsyncStorage.multiRemove(removable);
        await refreshCount();
        Alert.alert("Local data cleared", "Your Guardian account and server-submitted reports were not changed.");
      } },
    ]);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/profile" asChild><Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to profile"><Text style={styles.backText}>‹  Back to profile</Text></Pressable></Link>
        <Text style={styles.eyebrow}>PRIVACY & DATA</Text>
        <Text style={styles.title}>Your data choices</Text>
        <Text style={styles.subtitle}>Guardian separates information kept on this device from reports submitted to the service.</Text>
        <View style={styles.summaryCard}><Text style={styles.summaryTitle}>Clear, practical boundaries</Text><Text style={styles.summaryBody}>Guardian only requests location or photos when you choose those actions. Guest drafts stay local. Submitted reports include the details you choose to send so the reviewing team can understand the concern.</Text></View>
        <Text style={styles.sectionTitle}>Stored on this device</Text>
        <DataRow title="Drafts and report receipts" detail="Used to recover incomplete reports and show confirmation references" styles={styles} colors={colors} />
        <DataRow title="Accessibility and notification preferences" detail="Used to keep the app configured the way you prefer" styles={styles} colors={colors} />
        <View style={styles.preferenceRow}><View style={styles.preferenceCopy}><Text style={styles.dataTitle}>Haptic feedback</Text><Text style={styles.dataDetail}>Use subtle native confirmation feedback after successful location refreshes. Visual confirmations remain available.</Text></View><Switch value={hapticsEnabled} onValueChange={(enabled) => void toggleHaptics(enabled)} accessibilityRole="switch" accessibilityLabel="Haptic feedback" accessibilityState={{ checked: hapticsEnabled }} /></View>
        <View style={styles.countRow}><Text style={styles.countLabel}>Local Guardian records</Text><Text style={styles.countValue}>{loading ? "…" : String(localCount)}</Text></View>
        <Pressable onPress={clearLocalData} style={({ pressed }) => [styles.clearButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear local Guardian data" accessibilityHint="Removes drafts, local receipts, and preferences from this device after confirmation."><Text style={styles.clearText}>Clear local data</Text></Pressable>
        {cachedLabelMessage && <View style={styles.successBanner} accessible accessibilityLiveRegion="polite"><Text style={styles.successBannerText}>{cachedLabelMessage}</Text>{recentlyClearedLabels ? <Pressable onPress={() => void undoCachedLabelClear()} style={({ pressed }) => [styles.successDismiss, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Undo cached nearby label clear. ${undoSecondsLeft} seconds remaining.`} accessibilityHint="Restores the cached location suggestions without changing coordinates or drafts."><Text style={styles.successDismissText}>Undo ({undoSecondsLeft}s)</Text></Pressable> : <Pressable onPress={() => setCachedLabelMessage(null)} style={({ pressed }) => [styles.successDismiss, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Dismiss cached label confirmation" accessibilityHint="Hides this confirmation message."><Text style={styles.successDismissText}>Dismiss</Text></Pressable>}</View>}
        <View style={styles.activityCard}><View style={styles.activityHeader}><Text style={styles.activityTitle}>Nearby map label</Text><Text style={styles.activityCount}>{loading ? "…" : cachedLabelRefreshedAt ? "Stored locally" : "None"}</Text></View><Text style={styles.activityBody}>{cachedLabelRefreshedAt ? `A nearby street or intersection suggestion is cached on this device. Last refreshed ${new Date(cachedLabelRefreshedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}. It never changes saved coordinates.` : "No nearby map label is cached on this device."}</Text>{cachedLabelRefreshedAt && <Pressable onPress={clearCachedLabel} style={({ pressed }) => [styles.activityButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear all location suggestions" accessibilityHint="Removes locally cached street and intersection labels while keeping coordinates and drafts."><Text style={styles.activityButtonText}>Clear all location suggestions</Text></Pressable>}</View>
        <View style={styles.activityCard}><View style={styles.activityHeader}><Text style={styles.activityTitle}>Outbox activity history</Text><Text accessibilityLabel={`${activityCount} local activity events`} style={styles.activityCount}>{loading ? "…" : String(activityCount)}</Text></View><Text style={styles.activityBody}>Recent queue, retry, clear, undo, and receipt events are stored locally for troubleshooting. This does not include report descriptions or locations.</Text><Link href={{ pathname: "/outbox", params: { from: "privacy" } }} asChild><Pressable style={({ pressed }) => [styles.activityButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.activityButtonText}>View activity in Outbox</Text></Pressable></Link><Pressable onPress={clearActivityHistory} style={({ pressed }) => [styles.activityButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear activity history" accessibilityHint="Removes local queue and retry events without changing queued reports or drafts."><Text style={styles.activityButtonText}>Clear activity history</Text></Pressable></View>
        <View style={styles.activityCard}><View style={styles.activityHeader}><Text style={styles.activityTitle}>Recent batch retry summary</Text><Text style={styles.activityCount}>{loading ? "…" : batchSummary ? "Stored locally" : "None"}</Text></View><Text style={styles.activityBody}>{batchSummary ? `${batchSummary.submitted} submitted · ${batchSummary.failed} failed · ${batchSummary.remaining} remaining in Outbox.` : "No recent batch summary is stored on this device."}</Text>{batchSummary && <Pressable onPress={clearBatchSummaryFromPrivacy} style={({ pressed }) => [styles.activityButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear recent batch retry summary" accessibilityHint="Removes only the local batch summary."><Text style={styles.activityButtonText}>Clear batch summary</Text></Pressable>}</View>
        {recentlyClearedSummary && <View style={styles.undoBanner} accessible accessibilityLiveRegion="polite"><View style={styles.undoCopy}><Text style={styles.undoTitle}>Summary cleared</Text><Text style={styles.undoBody}>Only the recent batch summary was removed.</Text></View><Pressable onPress={() => void undoBatchSummaryClear()} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.undoButtonText}>Undo</Text></Pressable></View>}
        <Text style={styles.sectionTitle}>Submitted to Guardian</Text>
        <View style={styles.exportCard}><Text style={styles.exportTitle}>Export your report data</Text><Text style={styles.exportBody}>Download a JSON copy of submitted reports, statuses, locations, and attachment indicators.</Text><Pressable onPress={exportData} disabled={exportQuery.isFetching} style={({ pressed }) => [styles.exportButton, exportQuery.isFetching && { opacity: 0.6 }, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={exportQuery.isFetching ? "Preparing report data export" : isAuthenticated ? "Download report data" : "Sign in to export report data"} accessibilityHint="Creates a JSON copy of submitted report data."><Text style={styles.exportButtonText}>{exportQuery.isFetching ? "Preparing export…" : isAuthenticated ? "Download report data" : "Sign in to export"}</Text></Pressable></View>
        <DataRow title="Hazard report details" detail="Category, urgency, description, location, and optional attachment metadata" styles={styles} colors={colors} />
        <View style={styles.noteCard}><Text style={styles.noteTitle}>Need a server-side deletion request?</Text><Text style={styles.noteBody}>Sign in and contact the service owner through the account support process. Clearing local data cannot remove a report already submitted to the server.</Text></View>
        <Text style={styles.footer}>Guardian is an information and non-emergency reporting tool. Call 911 for immediate danger.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function DataRow({ title, detail, styles, colors }: { title: string; detail: string; styles: ReturnType<typeof createStyles>; colors: ReturnType<typeof useColors> }) {
  return <View style={styles.dataRow}><View style={[styles.dataIcon, { backgroundColor: colors.primary + "18" }]}><Text style={styles.dataIconText}>i</Text></View><View style={styles.dataCopy}><Text style={styles.dataTitle}>{title}</Text><Text style={styles.dataDetail}>{detail}</Text></View></View>;
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 13 }, back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" }, backText: { color: colors.primary, fontSize: 13, fontWeight: "900" }, eyebrow: { color: colors.primary, fontSize: 11, fontWeight: "800", letterSpacing: 1.1, marginTop: 14 }, title: { color: colors.foreground, fontSize: 30, fontWeight: "800", marginTop: 2 }, subtitle: { color: colors.muted, fontSize: 13, lineHeight: 18, marginBottom: 5 }, summaryCard: { backgroundColor: colors.foreground, borderRadius: 18, padding: 17, gap: 6, elevation: 2 }, summaryTitle: { color: "#FFFFFF", fontSize: 15, fontWeight: "900" }, summaryBody: { color: "#C9D6E3", fontSize: 12, lineHeight: 18, marginTop: 6 }, sectionTitle: { color: colors.foreground, fontSize: 15, fontWeight: "900", marginTop: 7 }, dataRow: { flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, padding: 14 }, preferenceRow: { flexDirection: "row", alignItems: "center", gap: 12, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 }, preferenceCopy: { flex: 1, gap: 3 }, dataIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" }, dataIconText: { color: colors.primary, fontSize: 17, fontWeight: "900" }, dataCopy: { flex: 1 }, dataTitle: { color: colors.foreground, fontSize: 13, fontWeight: "800" }, dataDetail: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 }, countRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 4 }, countLabel: { color: colors.muted, fontSize: 12, fontWeight: "700" }, countValue: { color: colors.foreground, fontSize: 14, fontWeight: "900" }, clearButton: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.error + "55", backgroundColor: colors.error + "0D", alignItems: "center", justifyContent: "center" }, clearText: { color: colors.error, fontSize: 13, fontWeight: "900" }, activityCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, padding: 14, gap: 8 }, activityHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, activityTitle: { color: colors.foreground, fontSize: 13, fontWeight: "900" }, activityCount: { color: colors.primary, fontSize: 14, fontWeight: "900" }, activityBody: { color: colors.muted, fontSize: 11, lineHeight: 17 }, activityButton: { minHeight: 46, borderRadius: 12, borderColor: colors.border, borderWidth: 1, alignItems: "center", justifyContent: "center" },     activityButtonText: { color: colors.primary, fontSize: 12, fontWeight: "900" },
    successBanner: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.success + "18", borderColor: colors.success + "55", borderWidth: 1, borderRadius: 14, padding: 12 },
    successBannerText: { flex: 1, color: colors.foreground, fontSize: 12, lineHeight: 17, fontWeight: "800" },
    successDismiss: { minHeight: 38, borderRadius: 9, borderWidth: 1, borderColor: colors.success + "66", paddingHorizontal: 11, alignItems: "center", justifyContent: "center" },
    successDismissText: { color: colors.foreground, fontSize: 11, fontWeight: "900" }, undoBanner: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 12 }, undoCopy: { flex: 1, gap: 2 }, undoTitle: { color: colors.foreground, fontSize: 12, fontWeight: "900" }, undoBody: { color: colors.muted, fontSize: 11, lineHeight: 16 }, undoButton: { minHeight: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 14 }, undoButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },     exportCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 16 },
    exportTitle: { color: colors.foreground, fontSize: 14, fontWeight: "900" },
    exportBody: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 5 },
    exportButton: { minHeight: 46, borderRadius: 13, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", marginTop: 12 },
    exportButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },
    noteCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 17, padding: 16 }, noteTitle: { color: colors.foreground, fontSize: 14, fontWeight: "900" }, noteBody: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 5 }, footer: { color: colors.muted, fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 4 }, pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
