import { Link } from "expo-router";
import { useMemo } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const resources = [
  { title: "Report a hazard", detail: "Share potholes, flooding, unsafe crossings, and other non-emergency concerns.", action: "Open report flow", href: "/report" as const, icon: "+", tone: "primary" as const },
  { title: "Emergency guidance", detail: "If someone is in immediate danger, call 911 first and follow dispatcher instructions.", action: "Open emergency mode", href: "/emergency" as const, icon: "!", tone: "error" as const },
  { title: "Support Guardian", detail: "Optional supporter plans help maintain offline reliability and accessibility. Core safety stays free.", action: "View support options", href: "/support" as const, icon: "♥", tone: "success" as const },
];

export default function ResourcesScreen() {
  const colors = useColors();
  const styles = useMemo(() => createStyles(colors), [colors]);

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/(tabs)" asChild>
          <Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Back to home">
            <Text style={styles.backText}>‹  Back to home</Text>
          </Pressable>
        </Link>
        <Text style={styles.eyebrow}>CIVIC SAFETY TOOLKIT</Text>
        <Text style={styles.title}>Find resources</Text>
        <Text style={styles.subtitle}>Start with the path that matches what you need. Guardian keeps essential safety actions available without requiring payment.</Text>

        <View style={styles.boundaryCard} accessible accessibilityRole="summary">
          <View style={styles.boundaryIcon}><Text style={styles.boundaryIconText}>⌖</Text></View>
          <View style={styles.boundaryCopy}><Text style={styles.boundaryTitle}>Designed for one-handed help</Text><Text style={styles.boundaryBody}>Large actions, readable status, and local-first drafts help you keep moving when conditions are changing.</Text></View>
        </View>

        <Text style={styles.sectionTitle}>Start here</Text>
        <View style={styles.list}>
          {resources.map((resource) => (
            <Link key={resource.title} href={resource.href} asChild>
              <Pressable style={({ pressed }) => [styles.resourceCard, pressed && styles.resourceCardPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`${resource.title}. ${resource.detail}`} accessibilityHint={`Opens ${resource.action.toLowerCase()}.`}>
                <View style={[styles.resourceIcon, { backgroundColor: resource.tone === "error" ? colors.error : resource.tone === "success" ? colors.success : colors.primary }]}><Text style={styles.resourceIconText}>{resource.icon}</Text></View>
                <View style={styles.resourceCopy}><Text style={styles.resourceTitle}>{resource.title}</Text><Text style={styles.resourceDetail}>{resource.detail}</Text><Text style={styles.resourceAction}>{resource.action}  ›</Text></View>
              </Pressable>
            </Link>
          ))}
        </View>

        <View style={styles.localCard} accessible accessibilityLabel="Local-first support note">
          <Text style={styles.localTitle}>No internet? You still have options.</Text>
          <Text style={styles.localBody}>Drafts stay on this device, and the report flow includes an SMS fallback when available.</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 36, gap: 14 },
    back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" },
    backText: { color: colors.primary, fontSize: 13, fontWeight: "900" },
    eyebrow: { color: colors.primary, fontSize: 11, fontWeight: "800", letterSpacing: 1.1, marginTop: 12 },
    title: { color: colors.foreground, fontSize: 30, fontWeight: "900", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: 13, lineHeight: 19, marginBottom: 5 },
    boundaryCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#EEF7F1", borderColor: "#C6E5CF", borderWidth: 1, borderRadius: 18, padding: 15 },
    boundaryIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: colors.success, alignItems: "center", justifyContent: "center" },
    boundaryIconText: { color: "#FFFFFF", fontSize: 20, fontWeight: "900" },
    boundaryCopy: { flex: 1, gap: 3 },
    boundaryTitle: { color: colors.foreground, fontSize: 13, fontWeight: "900" },
    boundaryBody: { color: colors.muted, fontSize: 11, lineHeight: 16 },
    sectionTitle: { color: colors.foreground, fontSize: 16, fontWeight: "900", marginTop: 5 },
    list: { gap: 10 },
    resourceCard: { flexDirection: "row", alignItems: "flex-start", gap: 13, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 15, elevation: 1 },
    resourceCardPressed: { backgroundColor: colors.primary + "12", borderColor: colors.primary },
    resourceIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
    resourceIconText: { color: "#FFFFFF", fontSize: 20, fontWeight: "900" },
    resourceCopy: { flex: 1, gap: 4 },
    resourceTitle: { color: colors.foreground, fontSize: 15, fontWeight: "900" },
    resourceDetail: { color: colors.muted, fontSize: 12, lineHeight: 17 },
    resourceAction: { color: colors.primary, fontSize: 11, fontWeight: "900", marginTop: 3 },
    localCard: { borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 16, marginTop: 5 },
    localTitle: { color: colors.foreground, fontSize: 13, fontWeight: "900" },
    localBody: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 4 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
