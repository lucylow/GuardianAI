import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import * as Network from "expo-network";
import { Link, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Alert, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { GuardianStatusCard } from "@/components/guardian/status-card";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";
import { appendActivityEvent, clearBatchSummary, MAX_AUTOMATIC_RETRIES, readActivityEvents, readActivitySortNewest, readAutoRetryPaused, readBatchSummary, removeQueuedReport, readQueuedReports, setActivitySortNewest as persistActivitySortNewest, setAutoRetryPaused, setBatchSummary, upsertQueuedReport, type GuardianActivityEvent, type GuardianBatchSummary, type GuardianQueuedReport } from "@/lib/guardian-queue";
import { trpc } from "@/lib/trpc";

export default function OutboxScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const { from } = useLocalSearchParams<{ from?: string }>();
  const router = useRouter();
  const cameFromPrivacy = from === "privacy";
  const networkState = Network.useNetworkState();
  const isOnline = networkState.isInternetReachable !== false && networkState.isConnected !== false;
  const [queuedReports, setQueuedReports] = useState<GuardianQueuedReport[]>([]);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [failedId, setFailedId] = useState<string | null>(null);
  const [recentlyCleared, setRecentlyCleared] = useState<GuardianQueuedReport | null>(null);
  const [undoExpiresAt, setUndoExpiresAt] = useState<number | null>(null);
  const [activityEvents, setActivityEvents] = useState<GuardianActivityEvent[]>([]);
  const [activityManualOnly, setActivityManualOnly] = useState(false);
  const [activitySortNewest, setActivitySortNewest] = useState(true);
  const [autoRetryPaused, setAutoRetryPausedState] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [filterMode, setFilterMode] = useState<"all" | "ready" | "due" | "manual" | "scheduled">("all");
  const [sortMode, setSortMode] = useState<"urgency" | "recent">("urgency");
  const [outboxPreferencesLoaded, setOutboxPreferencesLoaded] = useState(false);
  const [resetFeedback, setResetFeedback] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [failedRetryReport, setFailedRetryReport] = useState<GuardianQueuedReport | null>(null);
  const [batchRetryProgress, setBatchRetryProgress] = useState<{ completed: number; total: number; submitted: number; failed: number; done: boolean; cancelled: boolean; cancelRequested: boolean } | null>(null);
  const [batchAnnouncement, setBatchAnnouncement] = useState("");
  const [announceBatchSteps, setAnnounceBatchSteps] = useState(true);
  const [announcementPreferenceFeedback, setAnnouncementPreferenceFeedback] = useState<string | null>(null);
  const [recentBatchSummary, setRecentBatchSummary] = useState<GuardianBatchSummary | null>(null);
  const [isRefreshingOutbox, setIsRefreshingOutbox] = useState(false);
  const [recentlyClearedSummary, setRecentlyClearedSummary] = useState<GuardianBatchSummary | null>(null);
  const [summaryUndoExpiresAt, setSummaryUndoExpiresAt] = useState<number | null>(null);
  const batchCancelRef = useRef(false);
  const manualAttentionCount = queuedReports.filter(needsManualAttention).length;
  const scheduledRetryCount = queuedReports.filter((report) => isScheduledRetry(report, now)).length;
  const manualActivityCount = activityEvents.filter((event) => event.type === "auto_retry_exhausted").length;
  const visibleActivityEvents = useMemo(() => {
    const filtered = activityManualOnly ? activityEvents.filter((event) => event.type === "auto_retry_exhausted") : activityEvents;
    return [...filtered].sort((a, b) => {
      const difference = new Date(b.at).getTime() - new Date(a.at).getTime();
      return activitySortNewest ? difference : -difference;
    });
  }, [activityManualOnly, activityEvents, activitySortNewest]);
  const readyReports = useMemo(() => queuedReports.filter((report) => !report.autoRetryExhausted && (!report.nextRetryAt || new Date(report.nextRetryAt).getTime() <= now)), [now, queuedReports]);
  const visibleReports = useMemo(() => {
    const filtered = filterMode === "ready" ? readyReports : filterMode === "due" ? queuedReports.filter((report) => report.nextRetryAt && !report.autoRetryExhausted && new Date(report.nextRetryAt).getTime() <= now) : filterMode === "manual" ? queuedReports.filter(needsManualAttention) : filterMode === "scheduled" ? queuedReports.filter((report) => isScheduledRetry(report, now)) : queuedReports;
    return [...filtered].sort((a, b) => sortMode === "recent" ? lastAttemptTime(b) - lastAttemptTime(a) : retryUrgencyTime(a, now) - retryUrgencyTime(b, now));
  }, [filterMode, now, queuedReports, readyReports, sortMode]);
  const nextScheduledRetry = useMemo(() => queuedReports.filter((report) => report.nextRetryAt && new Date(report.nextRetryAt).getTime() > now).sort((a, b) => new Date(a.nextRetryAt ?? 0).getTime() - new Date(b.nextRetryAt ?? 0).getTime())[0] ?? null, [now, queuedReports]);
  const dueRetryReports = useMemo(() => queuedReports.filter((report) => report.nextRetryAt && !report.autoRetryExhausted && new Date(report.nextRetryAt).getTime() <= now), [now, queuedReports]);
  const dueRetryCount = dueRetryReports.length;
  const undoTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const summaryUndoTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const createReport = trpc.reports.create.useMutation();
  const OUTBOX_PREFERENCES_KEY = "guardian.outbox.preferences.v1";
  const provideSuccessFeedback = useCallback(async () => {
    if (Platform.OS !== "web" && (await AsyncStorage.getItem("guardian.setting.hapticsEnabled")) !== "false") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, []);
  const provideErrorFeedback = useCallback(async () => {
    if (Platform.OS !== "web" && (await AsyncStorage.getItem("guardian.setting.hapticsEnabled")) !== "false") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  }, []);
  const resetOutboxView = useCallback(async () => { setFilterMode("all"); setSortMode("urgency"); setActivityManualOnly(false); setActivitySortNewest(true); setResetFeedback("Outbox view reset to all reports, urgency order, and all activity."); if (Platform.OS !== "web" && (await AsyncStorage.getItem("guardian.setting.hapticsEnabled")) !== "false") await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); }, []);

  useEffect(() => () => {
    if (undoTimer.current) clearTimeout(undoTimer.current);
    if (summaryUndoTimer.current) clearTimeout(summaryUndoTimer.current);
  }, []);

  useEffect(() => {
    if (!actionFeedback) return;
    const timeout = setTimeout(() => setActionFeedback(null), 5000);
    return () => clearTimeout(timeout);
  }, [actionFeedback]);

  useEffect(() => {
    if (from === "location-revised") {
      setActionFeedback("Location changes saved on this device. Retry timing was reset; review the queued report before sending.");
      setFailedRetryReport(null);
    }
  }, [from]);

  useEffect(() => {
    if (!announcementPreferenceFeedback) return;
    const timeout = setTimeout(() => setAnnouncementPreferenceFeedback(null), 5000);
    return () => clearTimeout(timeout);
  }, [announcementPreferenceFeedback]);

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(OUTBOX_PREFERENCES_KEY), AsyncStorage.getItem("guardian.setting.batchAnnounceSteps")]).then(([value, announceStepsValue]) => {
      if (value) {
        const parsed = JSON.parse(value) as { filterMode?: "all" | "ready" | "manual" | "scheduled"; sortMode?: "urgency" | "recent"; activityManualOnly?: boolean; activitySortNewest?: boolean };
        if (["all", "ready", "manual", "scheduled"].includes(parsed.filterMode ?? "")) setFilterMode(parsed.filterMode ?? "all");
        if (parsed.sortMode === "urgency" || parsed.sortMode === "recent") setSortMode(parsed.sortMode);
        if (typeof parsed.activityManualOnly === "boolean") setActivityManualOnly(parsed.activityManualOnly);
        if (typeof parsed.activitySortNewest === "boolean") setActivitySortNewest(parsed.activitySortNewest);
      }
      if (announceStepsValue === "false") setAnnounceBatchSteps(false);
    }).catch(() => undefined).finally(() => setOutboxPreferencesLoaded(true));
  }, []);

  useEffect(() => {
    if (!outboxPreferencesLoaded) return;
    AsyncStorage.setItem(OUTBOX_PREFERENCES_KEY, JSON.stringify({ filterMode, sortMode, activityManualOnly, activitySortNewest })).catch(() => undefined);
    AsyncStorage.setItem("guardian.setting.batchAnnounceSteps", String(announceBatchSteps)).catch(() => undefined);
  }, [activityManualOnly, activitySortNewest, announceBatchSteps, filterMode, outboxPreferencesLoaded, sortMode]);

  const toggleBatchAnnounceSteps = useCallback(() => {
    setAnnounceBatchSteps((current) => {
      const next = !current;
      setAnnouncementPreferenceFeedback(next ? "Bulk retry step announcements are on. Each completed report will be announced." : "Bulk retry step announcements are off. Guardian will still announce batch start, completion, failures, and cancellation.");
      return next;
    });
  }, []);

  const loadQueue = useCallback((showFeedback = false) => {
    if (showFeedback) setIsRefreshingOutbox(true);
    return Promise.all([readQueuedReports(), readActivityEvents(), readAutoRetryPaused(), readActivitySortNewest(), readBatchSummary()]).then(([queue, events, paused, activityNewest, batchSummary]) => { setQueuedReports(queue); setActivityEvents(events); setAutoRetryPausedState(paused); setActivitySortNewest(activityNewest); setRecentBatchSummary(batchSummary); }).catch(() => { setQueuedReports([]); setActivityEvents([]); setAutoRetryPausedState(false); setActivitySortNewest(true); setRecentBatchSummary(null); }).finally(() => { if (showFeedback) setIsRefreshingOutbox(false); });
  }, []);

  const toggleAutoRetry = useCallback(async () => {
    const next = await setAutoRetryPaused(!autoRetryPaused);
    setAutoRetryPausedState(next);
    await appendActivityEvent(next ? "auto_retry_paused" : "auto_retry_resumed");
    setActivityEvents(await readActivityEvents());
  }, [autoRetryPaused]);

  const clearReport = useCallback((report: GuardianQueuedReport) => {
    Alert.alert("Delete queued report?", "This removes only this report from Guardian’s local outbox. It cannot be recovered afterward.", [
      { text: "Keep report", style: "cancel" },
      { text: "Delete report", style: "destructive", onPress: () => { void removeQueuedReport(report.clientRequestId).then(async () => { await appendActivityEvent("cleared", report.clientRequestId); setFailedId(null); setRecentlyCleared(report); setUndoExpiresAt(Date.now() + 6000); loadQueue(); if (undoTimer.current) clearTimeout(undoTimer.current); undoTimer.current = setTimeout(() => { setRecentlyCleared(null); setUndoExpiresAt(null); }, 6000); }).catch(() => undefined); } },
    ]);
  }, [loadQueue]);

  const undoClear = useCallback(async () => {
    if (!recentlyCleared) return;
    await upsertQueuedReport(recentlyCleared);
    await appendActivityEvent("undo", recentlyCleared.clientRequestId);
    setRecentlyCleared(null);
    setUndoExpiresAt(null);
    if (undoTimer.current) clearTimeout(undoTimer.current);
    setActionFeedback("Report restored to the Outbox. It remains on this device until you retry it.");
    await provideSuccessFeedback();
    loadQueue();
  }, [loadQueue, provideSuccessFeedback, recentlyCleared]);

  const retryReport = useCallback(async (report: GuardianQueuedReport, automatic = false) => {
    if (!isOnline || (automatic && autoRetryPaused) || retryingId) return false;
    setRetryingId(report.clientRequestId);
    setFailedId(null);
    await appendActivityEvent("retry_started", report.clientRequestId);
    const attempt = { ...report, retryCount: report.retryCount + 1, lastAttemptAt: new Date().toISOString(), lastFailureReason: undefined, nextRetryAt: undefined, autoRetryExhausted: automatic ? report.autoRetryExhausted : false, automaticRetryCount: (report.automaticRetryCount ?? 0) + (automatic ? 1 : 0), manualRetryCount: (report.manualRetryCount ?? 0) + (automatic ? 0 : 1) };
    await upsertQueuedReport(attempt);
    loadQueue();
    try {
      const receipt = await createReport.mutateAsync({
        clientRequestId: report.clientRequestId,
        category: report.draft.category,
        severity: report.draft.severity as "Low" | "Medium" | "High",
        description: report.draft.description.trim(),
        locationText: report.draft.location.trim(),
        latitude: report.draft.latitude,
        longitude: report.draft.longitude,
        accuracy: report.draft.accuracy,
        photoUri: report.draft.photoUri,
      });
      await AsyncStorage.setItem(`guardian.report.receipt.${report.clientRequestId}`, JSON.stringify(receipt));
      await removeQueuedReport(report.clientRequestId);
      await appendActivityEvent("submitted", report.clientRequestId);
      setActionFeedback("Queued report submitted successfully and removed from the Outbox.");
      setFailedRetryReport(null);
      await provideSuccessFeedback();
      loadQueue();
      return true;
    } catch {
      const failureReason = "Guardian could not reach the reporting service. Check your connection and try again.";
      const exhausted = automatic && attempt.retryCount >= MAX_AUTOMATIC_RETRIES;
      const delayMs = Math.min(5000 * 2 ** Math.max(0, attempt.retryCount - 1), 300000);
      const failedAttempt = { ...attempt, lastFailureReason: failureReason, nextRetryAt: exhausted ? undefined : new Date(Date.now() + delayMs).toISOString(), autoRetryExhausted: exhausted };
      await upsertQueuedReport(failedAttempt);
      await appendActivityEvent("retry_failed", report.clientRequestId);
      if (exhausted && !report.autoRetryExhausted) await appendActivityEvent("auto_retry_exhausted", report.clientRequestId);
      loadQueue();
      setFailedId(report.clientRequestId);
      setFailedRetryReport(failedAttempt);
      const retryTiming = failedAttempt.nextRetryAt ? `Next automatic retry is scheduled for ${new Date(failedAttempt.nextRetryAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}.` : "No automatic retry is scheduled; use Try again when ready.";
      setActionFeedback(`Retry could not connect. The report remains safely queued on this device. ${retryTiming}`);
      await provideErrorFeedback();
      return false;
    } finally {
      setRetryingId(null);
    }
  }, [autoRetryPaused, createReport, isOnline, loadQueue, provideErrorFeedback, provideSuccessFeedback, retryingId]);

  const runBatchRetry = useCallback(async (reports: GuardianQueuedReport[]) => {
    if (!isOnline || autoRetryPaused || retryingId || batchRetryProgress?.done === false || reports.length === 0) return;
    batchCancelRef.current = false;
    setBatchRetryProgress({ completed: 0, total: reports.length, submitted: 0, failed: 0, done: false, cancelled: false, cancelRequested: false });
    setBatchAnnouncement(`Bulk retry started for ${reports.length} report${reports.length === 1 ? "" : "s"}.`);
    await appendActivityEvent("batch_retry_started");
    setActivityEvents(await readActivityEvents());
    let submitted = 0;
    let failed = 0;
    for (const report of reports) {
      if (batchCancelRef.current) break;
      const didSubmit = await retryReport(report);
      if (didSubmit) submitted += 1;
      else failed += 1;
      setBatchRetryProgress((current) => current ? { ...current, completed: current.completed + 1, submitted, failed } : current);
      if (announceBatchSteps) setBatchAnnouncement(`Bulk retry progress: ${submitted + failed} of ${reports.length} complete. ${submitted} submitted, ${failed} failed.`);
    }
    const cancelled = batchCancelRef.current && submitted + failed < reports.length;
    await appendActivityEvent(cancelled ? "batch_retry_cancelled" : "batch_retry_completed");
    setActivityEvents(await readActivityEvents());
    const summary: GuardianBatchSummary = { completedAt: new Date().toISOString(), total: reports.length, submitted, failed, remaining: reports.length - submitted, cancelled };
    await setBatchSummary(summary);
    setRecentBatchSummary(summary);
    setBatchRetryProgress({ completed: submitted + failed, total: reports.length, submitted, failed, done: true, cancelled, cancelRequested: false });
    setBatchAnnouncement(`${cancelled ? "Bulk retry stopped" : "Bulk retry finished"}. ${submitted} submitted, ${failed} failed, and ${reports.length - submitted} remain queued.`);
  }, [announceBatchSteps, autoRetryPaused, batchRetryProgress?.done, isOnline, retryReport, retryingId]);

  const clearRecentBatchSummary = useCallback(() => {
    if (!recentBatchSummary) return;
    Alert.alert("Clear recent batch summary?", "This removes only the summary from this device. Queued reports, drafts, receipts, and activity history will stay unchanged.", [{ text: "Keep summary", style: "cancel" }, { text: "Clear summary", style: "destructive", onPress: async () => { await clearBatchSummary(); setRecentlyClearedSummary(recentBatchSummary); setSummaryUndoExpiresAt(Date.now() + 6000); setRecentBatchSummary(null); if (summaryUndoTimer.current) clearTimeout(summaryUndoTimer.current); summaryUndoTimer.current = setTimeout(() => { setRecentlyClearedSummary(null); setSummaryUndoExpiresAt(null); }, 6000); } }]);
  }, [recentBatchSummary]);

  const undoClearSummary = useCallback(async () => {
    if (!recentlyClearedSummary) return;
    await setBatchSummary(recentlyClearedSummary);
    setRecentBatchSummary(recentlyClearedSummary);
    setRecentlyClearedSummary(null);
    setSummaryUndoExpiresAt(null);
    if (summaryUndoTimer.current) clearTimeout(summaryUndoTimer.current);
    setActionFeedback("Batch summary restored. Queued reports and activity history were unchanged.");
    await provideSuccessFeedback();
  }, [provideSuccessFeedback, recentlyClearedSummary]);

  const requestBatchCancel = useCallback(() => {
    if (batchRetryProgress?.done === false) {
      batchCancelRef.current = true;
      setBatchRetryProgress((current) => current ? { ...current, cancelRequested: true } : current);
    }
  }, [batchRetryProgress?.done]);

  const confirmRetryAll = useCallback(() => {
    if (!isOnline || autoRetryPaused || retryingId || batchRetryProgress?.done === false || readyReports.length === 0) return;
    Alert.alert("Retry ready reports?", `Guardian will submit ${readyReports.length} ready report${readyReports.length === 1 ? "" : "s"} one at a time. Reports that fail remain safely queued.`, [{ text: "Cancel", style: "cancel" }, { text: "Retry all", onPress: () => void runBatchRetry(readyReports) }]);
  }, [autoRetryPaused, batchRetryProgress?.done, isOnline, readyReports, retryingId, runBatchRetry]);

  const confirmRetryDue = useCallback(() => {
    if (!isOnline || autoRetryPaused || retryingId || batchRetryProgress?.done === false || dueRetryReports.length === 0) return;
    Alert.alert("Retry due reports now?", `Guardian will submit ${dueRetryReports.length} due report${dueRetryReports.length === 1 ? "" : "s"} one at a time. Reports that fail remain safely queued.`, [{ text: "Cancel", style: "cancel" }, { text: "Retry due reports", onPress: () => void runBatchRetry(dueRetryReports) }]);
  }, [autoRetryPaused, batchRetryProgress?.done, dueRetryReports, isOnline, retryingId, runBatchRetry]);

  const attemptDueRetry = useCallback(async () => {
    if (!isOnline || autoRetryPaused || retryingId) return;
    const latest = await readQueuedReports();
    const due = latest.find((report) => !report.autoRetryExhausted && (!report.nextRetryAt || new Date(report.nextRetryAt).getTime() <= Date.now()));
    if (due) await retryReport(due, true);
  }, [autoRetryPaused, isOnline, retryReport, retryingId]);

  useFocusEffect(useCallback(() => {
    loadQueue();
    if (!isOnline || autoRetryPaused) return undefined;
    void attemptDueRetry();
    const interval = setInterval(() => void attemptDueRetry(), 15000);
    return () => clearInterval(interval);
  }, [attemptDueRetry, autoRetryPaused, isOnline, loadQueue]));

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={isRefreshingOutbox} onRefresh={() => void loadQueue(true)} />} >
        <Link href={cameFromPrivacy ? "/privacy" : "/profile"} asChild><Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={cameFromPrivacy ? "Back to Privacy" : "Back to profile"}><Text style={styles.backText}>{cameFromPrivacy ? "‹  Back to Privacy" : "‹  Back to profile"}</Text></Pressable></Link>
        <Link href="/privacy" asChild><Pressable style={({ pressed }) => [styles.privacyLink, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.privacyLinkText}>Privacy and data choices  ›</Text></Pressable></Link>
        <Text style={styles.eyebrow}>REPORT OUTBOX</Text>
        <View style={styles.titleRow}><View style={styles.titleCopy}><Text style={styles.title}>Waiting to send</Text><Text style={styles.subtitle}>Reports saved here stay on this device until Guardian can submit them.</Text></View>{queuedReports.length > 0 && <View style={styles.countBadge}><Text style={styles.countText}>{queuedReports.length}</Text></View>}</View>
        <GuardianStatusCard title={isOnline ? "Online" : "Offline"} body={isOnline ? "Queued reports can retry when ready." : "Queued reports stay safely stored on this device until connectivity returns."} badge={isOnline ? "Ready" : "Local"} tone={isOnline ? "success" : "neutral"} accessibilityLabel={isOnline ? "Online. Ready to retry queued reports." : "Offline. Queued reports will stay on this device."} />
        <GuardianStatusCard title="Queue at a glance" body={`${queuedReports.length} queued · ${readyReports.length} ready · ${manualAttentionCount} need attention · ${scheduledRetryCount} scheduled${dueRetryCount ? ` · ${dueRetryCount} due now` : ""}`} meta={autoRetryPaused ? "Automatic retries are paused." : dueRetryCount > 0 ? `${dueRetryCount} automatic ${dueRetryCount === 1 ? "retry is" : "retries are"} ready now.` : nextScheduledRetry ? `Next automatic retry in ${formatRetryCountdown(nextScheduledRetry.nextRetryAt, now)}.` : "Automatic retries are active while the Outbox is open."} badge={queuedReports.length === 0 ? "Clear" : dueRetryCount > 0 || manualAttentionCount > 0 ? "Review" : "Steady"} tone={dueRetryCount > 0 || manualAttentionCount > 0 ? "warning" : queuedReports.length === 0 ? "success" : "neutral"} accessibilityLabel={`Queue at a glance. ${queuedReports.length} queued, ${readyReports.length} ready, ${manualAttentionCount} need attention, and ${scheduledRetryCount} scheduled.${dueRetryCount ? ` ${dueRetryCount} automatic ${dueRetryCount === 1 ? "retry is" : "retries are"} ready now.` : nextScheduledRetry ? ` Next automatic retry in ${formatRetryCountdown(nextScheduledRetry.nextRetryAt, now)}.` : ""}`}><View style={styles.queueSummaryActions} accessibilityRole="tablist" accessibilityLabel="Filter queued reports"><Pressable onPress={() => setFilterMode("all")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "all" }} style={({ pressed }) => [styles.filterChip, filterMode === "all" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "all" && styles.filterChipTextActive]}>All {queuedReports.length}</Text></Pressable><Pressable onPress={() => setFilterMode("ready")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "ready" }} style={({ pressed }) => [styles.filterChip, filterMode === "ready" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "ready" && styles.filterChipTextActive]}>Ready {readyReports.length}</Text></Pressable><Pressable onPress={() => setFilterMode("due")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "due" }} style={({ pressed }) => [styles.filterChip, filterMode === "due" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "due" && styles.filterChipTextActive]}>Retry now {dueRetryCount}</Text></Pressable><Pressable onPress={() => setFilterMode("manual")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "manual" }} style={({ pressed }) => [styles.filterChip, filterMode === "manual" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "manual" && styles.filterChipTextActive]}>Needs attention {manualAttentionCount}</Text></Pressable><Pressable onPress={() => setFilterMode("scheduled")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "scheduled" }} style={({ pressed }) => [styles.filterChip, filterMode === "scheduled" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "scheduled" && styles.filterChipTextActive]}>Scheduled {scheduledRetryCount}</Text></Pressable></View></GuardianStatusCard>
        {actionFeedback && <View style={styles.resetConfirmation} accessible accessibilityLiveRegion="polite" accessibilityLabel={actionFeedback}><Text style={styles.resetConfirmationText}>{actionFeedback}</Text>{failedRetryReport && <Pressable disabled={!isOnline || retryingId !== null} onPress={() => { setActionFeedback("Retrying queued report…"); void retryReport(failedRetryReport); }} accessibilityRole="button" accessibilityLabel={isOnline ? "Try the failed report again now" : "Try again when you are back online"} accessibilityHint="Attempts to submit the safely queued report again." style={({ pressed }) => [styles.resetConfirmationDismiss, (!isOnline || retryingId !== null) && styles.disabled, pressed && styles.pressed]}><Text style={styles.resetConfirmationDismissText}>{retryingId === failedRetryReport.clientRequestId ? "Retrying…" : "Try again"}</Text></Pressable>}<Pressable onPress={() => { setActionFeedback(null); setFailedRetryReport(null); }} accessibilityRole="button" accessibilityLabel="Dismiss Outbox action confirmation" style={({ pressed }) => [styles.resetConfirmationDismiss, pressed && styles.pressed]}><Text style={styles.resetConfirmationDismissText}>Dismiss</Text></Pressable></View>}<Pressable onPress={() => void loadQueue(true)} disabled={isRefreshingOutbox} accessibilityRole="button" accessibilityLabel={isRefreshingOutbox ? "Refreshing Outbox status" : "Refresh Outbox status"} accessibilityHint="Refreshes local queue status and connectivity information." style={({ pressed }) => [styles.refreshStatusButton, isRefreshingOutbox && styles.disabled, pressed && styles.pressed]}><Text style={styles.refreshStatusText}>{isRefreshingOutbox ? "Refreshing Outbox…" : "Refresh Outbox status"}</Text></Pressable>
        <Pressable onPress={() => void toggleAutoRetry()} accessibilityRole="switch" accessibilityState={{ checked: !autoRetryPaused }} accessibilityLabel={autoRetryPaused ? "Automatic retries paused. Resume automatic retries." : "Automatic retries active. Pause automatic retries."} accessibilityHint="Changes only automatic retry behavior; queued reports stay on this device." style={({ pressed }) => [styles.pauseButton, autoRetryPaused && styles.pauseButtonActive, pressed && styles.pressed]}><Text style={[styles.pauseText, autoRetryPaused && styles.pauseTextActive]}>{autoRetryPaused ? "Resume automatic retries" : "Pause automatic retries"}</Text></Pressable>
        <Pressable onPress={resetOutboxView} accessibilityRole="button" accessibilityLabel="Reset Outbox view" accessibilityHint="Returns to all reports, urgency order, and all activity events." style={({ pressed }) => [styles.resetViewButton, pressed && styles.pressed]}><Text style={styles.resetViewText}>Reset Outbox view</Text></Pressable>{resetFeedback && <View style={styles.resetConfirmation} accessible accessibilityLiveRegion="polite"><Text style={styles.resetConfirmationText}>{resetFeedback}</Text><Pressable onPress={() => setResetFeedback(null)} accessibilityRole="button" accessibilityLabel="Dismiss Outbox reset confirmation" style={({ pressed }) => [styles.resetConfirmationDismiss, pressed && styles.pressed]}><Text style={styles.resetConfirmationDismissText}>Dismiss</Text></Pressable></View>}

        {recentBatchSummary && <GuardianStatusCard title="Recent batch retry" body={`${recentBatchSummary.cancelled ? "Stopped safely. " : "Finished. "}${recentBatchSummary.submitted} submitted · ${recentBatchSummary.failed} failed · ${recentBatchSummary.remaining} remaining in Outbox.`} meta={`Completed ${new Date(recentBatchSummary.completedAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`} badge={recentBatchSummary.cancelled ? "Stopped" : "Complete"} tone={recentBatchSummary.cancelled ? "warning" : "success"} accessibilityLabel={`Recent batch retry. ${recentBatchSummary.submitted} submitted, ${recentBatchSummary.failed} failed, ${recentBatchSummary.remaining} remaining.`}><Pressable onPress={clearRecentBatchSummary} accessibilityRole="button" style={({ pressed }) => [styles.summaryClearButton, pressed && styles.pressed]}><Text style={styles.summaryClearText}>Clear summary</Text></Pressable></GuardianStatusCard>}

        {queuedReports.length > 0 && <><View style={styles.batchRetryPanel} accessible accessibilityLiveRegion="polite"><Pressable onPress={toggleBatchAnnounceSteps} accessibilityRole="switch" accessibilityState={{ checked: announceBatchSteps }} accessibilityLabel={announceBatchSteps ? "Announce each bulk retry step is on" : "Announce each bulk retry step is off"} accessibilityHint="When off, Guardian still announces the batch start, completion, failures, and cancellation." style={({ pressed }) => [styles.announcementPreference, pressed && styles.pressed]}><Text style={styles.announcementPreferenceText}>Announce each retry step: {announceBatchSteps ? "On" : "Off"}</Text></Pressable>{announcementPreferenceFeedback ? <View accessible accessibilityRole="alert" accessibilityLiveRegion="polite" accessibilityLabel={announcementPreferenceFeedback} style={styles.announcementPreferenceConfirmation}><Text style={styles.announcementPreferenceConfirmationText}>{announcementPreferenceFeedback}</Text><Pressable onPress={() => setAnnouncementPreferenceFeedback(null)} accessibilityRole="button" accessibilityLabel="Dismiss announcement preference confirmation" style={({ pressed }) => [styles.announcementPreferenceDismiss, pressed && styles.pressed]}><Text style={styles.announcementPreferenceDismissText}>Dismiss</Text></Pressable></View> : null}{batchAnnouncement ? <View accessible accessibilityLiveRegion="polite" accessibilityRole="text" accessibilityLabel={batchAnnouncement} style={styles.batchAnnouncement}><Text style={styles.batchAnnouncementText}>{batchAnnouncement}</Text></View> : null}{dueRetryReports.length > 0 && <Pressable onPress={confirmRetryDue} disabled={!isOnline || autoRetryPaused || retryingId !== null || batchRetryProgress?.done === false} accessibilityRole="button" accessibilityLabel={`Retry ${dueRetryReports.length} due report${dueRetryReports.length === 1 ? "" : "s"} now`} accessibilityHint="Submits only reports whose scheduled retry is due. Reports that fail remain safely queued." style={({ pressed }) => [styles.primaryButton, styles.batchRetryButton, styles.dueRetryButton, (!isOnline || autoRetryPaused || retryingId !== null || batchRetryProgress?.done === false) && styles.disabled, pressed && styles.pressed]}><Text style={styles.primaryButtonText}>Retry due reports now ({dueRetryReports.length})</Text></Pressable>}<Pressable onPress={batchRetryProgress?.done === false ? requestBatchCancel : confirmRetryAll} disabled={!isOnline || autoRetryPaused || retryingId !== null || (!batchRetryProgress && readyReports.length === 0)} accessibilityRole="button" accessibilityLabel={readyReports.length ? `Retry all ${readyReports.length} ready reports` : "No reports are ready for retry"} style={({ pressed }) => [styles.primaryButton, styles.batchRetryButton, (!isOnline || autoRetryPaused || retryingId !== null || (!batchRetryProgress && readyReports.length === 0)) && styles.disabled, pressed && styles.pressed]}><Text style={styles.primaryButtonText}>{batchRetryProgress?.done === false ? (batchRetryProgress.cancelRequested ? "Stopping after current report…" : `Cancel batch retry · ${batchRetryProgress.completed} of ${batchRetryProgress.total}`) : batchRetryProgress?.done ? (batchRetryProgress.cancelled ? `Batch stopped · Submitted ${batchRetryProgress.submitted} · Failed ${batchRetryProgress.failed}` : `Submitted ${batchRetryProgress.submitted} · Failed ${batchRetryProgress.failed} · Remaining ${batchRetryProgress.total - batchRetryProgress.submitted}`) : readyReports.length ? `Retry all ready reports (${readyReports.length})` : "No reports ready for retry"}</Text></Pressable>{batchRetryProgress?.done && <Text style={styles.batchRetryHint}>{batchRetryProgress.cancelled ? "Batch retry stopped safely. " : "Batch retry finished. "}{batchRetryProgress.submitted} submitted, {batchRetryProgress.failed} failed, and {batchRetryProgress.total - batchRetryProgress.submitted} remain queued.</Text>}</View><View style={styles.filterRow} accessibilityRole="tablist"><Pressable onPress={() => setFilterMode("all")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "all" }} style={({ pressed }) => [styles.filterChip, filterMode === "all" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "all" && styles.filterChipTextActive]}>All ({queuedReports.length})</Text></Pressable><Pressable onPress={() => setFilterMode("ready")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "ready" }} style={({ pressed }) => [styles.filterChip, filterMode === "ready" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "ready" && styles.filterChipTextActive]}>Ready ({readyReports.length})</Text></Pressable><Pressable onPress={() => setFilterMode("due")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "due" }} style={({ pressed }) => [styles.filterChip, filterMode === "due" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "due" && styles.filterChipTextActive]}>Retry now ({dueRetryCount})</Text></Pressable><Pressable onPress={() => setFilterMode("manual")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "manual" }} style={({ pressed }) => [styles.filterChip, filterMode === "manual" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "manual" && styles.filterChipTextActive]}>Needs attention ({manualAttentionCount})</Text></Pressable><Pressable onPress={() => setFilterMode("scheduled")} accessibilityRole="tab" accessibilityState={{ selected: filterMode === "scheduled" }} style={({ pressed }) => [styles.filterChip, filterMode === "scheduled" && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, filterMode === "scheduled" && styles.filterChipTextActive]}>Scheduled ({scheduledRetryCount})</Text></Pressable></View><View style={styles.sortRow} accessibilityRole="radiogroup"><Text style={styles.sortLabel}>Sort by</Text><Pressable onPress={() => setSortMode("urgency")} accessibilityRole="radio" accessibilityState={{ selected: sortMode === "urgency" }} style={({ pressed }) => [styles.sortChip, sortMode === "urgency" && styles.sortChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, sortMode === "urgency" && styles.filterChipTextActive]}>Urgency</Text></Pressable><Pressable onPress={() => setSortMode("recent")} accessibilityRole="radio" accessibilityState={{ selected: sortMode === "recent" }} style={({ pressed }) => [styles.sortChip, sortMode === "recent" && styles.sortChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, sortMode === "recent" && styles.filterChipTextActive]}>Last attempt</Text></Pressable></View></>}

        {visibleReports.length ? <View style={styles.list}>{visibleReports.map((queuedReport) => <QueuedReportCard key={queuedReport.clientRequestId} report={queuedReport} isOnline={isOnline} retrying={retryingId === queuedReport.clientRequestId} failed={failedId === queuedReport.clientRequestId} autoRetryPaused={autoRetryPaused} onRetry={retryReport} onClear={clearReport} onReviseLocation={() => router.push({ pathname: "/report", params: { reviseClientRequestId: queuedReport.clientRequestId } })} now={now} styles={styles} />)}</View> : queuedReports.length > 0 ? <View style={styles.filteredEmpty}><Text style={styles.emptyTitle}>{filterMode === "ready" ? "No reports ready right now" : filterMode === "due" ? "No retries are due right now" : filterMode === "scheduled" ? "No scheduled retries" : "No reports need manual attention"}</Text><Text style={styles.emptyBody}>{filterMode === "ready" ? "Reports may be waiting for a scheduled retry or may need manual attention first." : filterMode === "due" ? "The queue will show a Retry now action as soon as a scheduled retry reaches its due time." : filterMode === "scheduled" ? "Reports without a scheduled retry are either ready for action or already paused." : "Scheduled reports remain safely queued and will retry automatically while the Outbox is open."}</Text><Pressable onPress={() => setFilterMode("all")} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.secondaryButtonText}>Show all reports</Text></Pressable></View> : <View style={styles.emptyCard}><View style={styles.emptyIcon}><Text style={styles.emptyIconText}>✓</Text></View><Text style={styles.emptyTitle}>Outbox is clear</Text><Text style={styles.emptyBody}>New reports that cannot be sent immediately will appear here with their saved details.</Text><Link href="/report" asChild><Pressable style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.secondaryButtonText}>Report a hazard</Text></Pressable></Link></View>}

        {recentlyCleared && <GuardianStatusCard title="Report cleared" body="It was removed from this device’s outbox." meta={`Undo available for ${Math.max(0, Math.ceil(((undoExpiresAt ?? now) - now) / 1000))} seconds`} badge="Undo" tone="warning" accessibilityLabel={`Report cleared. Undo available for ${Math.max(0, Math.ceil(((undoExpiresAt ?? now) - now) / 1000))} seconds.`}><Pressable onPress={() => void undoClear()} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Restore cleared report"><Text style={styles.undoButtonText}>Undo</Text></Pressable></GuardianStatusCard>}
        {recentlyClearedSummary && <GuardianStatusCard title="Summary cleared" body="Only the recent batch summary was removed." meta={`Undo available for ${Math.max(0, Math.ceil(((summaryUndoExpiresAt ?? now) - now) / 1000))} seconds`} badge="Undo" tone="warning" accessibilityLabel={`Summary cleared. Undo available for ${Math.max(0, Math.ceil(((summaryUndoExpiresAt ?? now) - now) / 1000))} seconds.`}><Pressable onPress={() => void undoClearSummary()} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Restore cleared summary"><Text style={styles.undoButtonText}>Undo</Text></Pressable></GuardianStatusCard>}

        {activityEvents.length > 0 && <View style={styles.activitySection}><View style={styles.activityHeader}><Text style={styles.activityTitle}>Recent activity</Text><View style={styles.activityCount}><Text style={styles.activityCountText}>{visibleActivityEvents.length}/{activityEvents.length}</Text></View></View><View style={styles.filterRow} accessibilityRole="tablist"><Pressable onPress={() => setActivityManualOnly(false)} accessibilityRole="tab" accessibilityState={{ selected: !activityManualOnly }} style={({ pressed }) => [styles.filterChip, !activityManualOnly && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, !activityManualOnly && styles.filterChipTextActive]}>All</Text></Pressable><Pressable onPress={() => setActivityManualOnly(true)} accessibilityRole="tab" accessibilityState={{ selected: activityManualOnly }} style={({ pressed }) => [styles.filterChip, activityManualOnly && styles.filterChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, activityManualOnly && styles.filterChipTextActive]}>Manual attention ({manualActivityCount})</Text></Pressable></View><View style={styles.sortRow} accessibilityRole="radiogroup"><Text style={styles.sortLabel}>Order</Text><Pressable onPress={() => { setActivitySortNewest(true); void persistActivitySortNewest(true); }} accessibilityRole="radio" accessibilityState={{ selected: activitySortNewest }} style={({ pressed }) => [styles.sortChip, activitySortNewest && styles.sortChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, activitySortNewest && styles.filterChipTextActive]}>Newest</Text></Pressable><Pressable onPress={() => { setActivitySortNewest(false); void persistActivitySortNewest(false); }} accessibilityRole="radio" accessibilityState={{ selected: !activitySortNewest }} style={({ pressed }) => [styles.sortChip, !activitySortNewest && styles.sortChipActive, pressed && styles.pressed]}><Text style={[styles.filterChipText, !activitySortNewest && styles.filterChipTextActive]}>Oldest</Text></Pressable></View>{visibleActivityEvents.length > 0 ? visibleActivityEvents.slice(0, 6).map((event) => { const linkedReport = event.clientRequestId ? queuedReports.find((report) => report.clientRequestId === event.clientRequestId) : undefined; const isManualEvent = event.type === "auto_retry_exhausted"; return <View key={event.id} style={styles.activityRow}><View style={styles.activityDot} /><View style={styles.activityCopy}><Text style={styles.activityLabel}>{activityLabel(event.type)}</Text><Text style={styles.activityTime}>{new Date(event.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</Text>{isManualEvent && <Pressable disabled={!linkedReport || !isOnline || retryingId !== null} onPress={() => { if (!linkedReport) { setActivityManualOnly(true); return; } Alert.alert("Retry this report now?", "Guardian will try to submit the saved report now. If it fails, the report remains safely in your Outbox.", [{ text: "Cancel", style: "cancel", onPress: async () => { await appendActivityEvent("retry_cancelled", linkedReport.clientRequestId); setActivityEvents(await readActivityEvents()); } }, { text: "Retry now", onPress: async () => { await appendActivityEvent("retry_confirmed", linkedReport.clientRequestId); setActivityEvents(await readActivityEvents()); void retryReport(linkedReport); } }]); }} style={({ pressed }) => [styles.activityAction, (!linkedReport || !isOnline || retryingId !== null) && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={linkedReport ? "Retry this queued report now" : "Show queued reports needing manual attention"}><Text style={styles.activityActionText}>{linkedReport ? (retryingId === linkedReport.clientRequestId ? "Retrying…" : "Retry now") : "View queue"}</Text></Pressable>}</View></View>; }) : <View accessible accessibilityRole="text" style={styles.activityEmpty}><Text style={styles.activityEmptyText}>No automatic retries have reached the manual-attention limit.</Text></View>}</View>}

        <View style={styles.privacyNote}><Text style={styles.privacyTitle}>Local-first by design</Text><Text style={styles.privacyBody}>Queued report details remain in Guardian’s local app storage until a receipt is created. You can clear local data from Profile → Privacy.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function activityLabel(type: GuardianActivityEvent["type"]) {
  switch (type) {
    case "queued": return "Report saved to Outbox";
    case "retry_started": return "Report retry started";
    case "retry_failed": return "Report retry needs attention";
    case "submitted": return "Report receipt created";
    case "cleared": return "Report cleared from device";
    case "undo": return "Cleared report restored";
    case "auto_retry_paused": return "Automatic retries paused";
    case "auto_retry_resumed": return "Automatic retries resumed";
    case "auto_retry_exhausted": return "Automatic retries exhausted; manual action needed";
    case "retry_confirmed": return "Manual retry confirmed";
    case "retry_cancelled": return "Manual retry cancelled";
    case "batch_retry_started": return "Batch retry started";
    case "batch_retry_completed": return "Batch retry completed";
    case "batch_retry_cancelled": return "Batch retry cancelled";
    case "location_label_cleared": return "Cached location labels cleared";
    case "location_label_restored": return "Cached location labels restored";
    case "location_revised": return "Queued report location revised";
    case "external_map_opened": return "External map handoff confirmed";
    case "ai_feedback_reason_saved": return "AI feedback reason saved on device";
  }
}


function needsManualAttention(report: GuardianQueuedReport) {
  return report.autoRetryExhausted === true || Boolean(report.lastFailureReason && !report.nextRetryAt);
}

function lastAttemptTime(report: GuardianQueuedReport) {
  return report.lastAttemptAt ? new Date(report.lastAttemptAt).getTime() : 0;
}

function retryUrgencyTime(report: GuardianQueuedReport, now: number) {
  if (report.autoRetryExhausted || !report.nextRetryAt) return 0;
  const next = new Date(report.nextRetryAt).getTime();
  return next > now ? next : 0;
}

function isScheduledRetry(report: GuardianQueuedReport, now: number) {
  return !report.autoRetryExhausted && hasRetryScheduled(report.nextRetryAt, now);
}

function hasRetryScheduled(nextRetryAt: string | undefined, now: number) {
  return Boolean(nextRetryAt && new Date(nextRetryAt).getTime() > now);
}

function formatRetryCountdown(nextRetryAt: string | undefined, now: number) {
  if (!nextRetryAt) return "";
  const remaining = Math.max(0, new Date(nextRetryAt).getTime() - now);
  if (!remaining) return "Retry is due now";
  const seconds = Math.ceil(remaining / 1000);
  if (seconds < 60) return `Auto retry in ${seconds}s`;
  return `Auto retry in ${Math.ceil(seconds / 60)}m`;
}

function getLocationStatus(report: GuardianQueuedReport) {
  const { draft } = report;
  const timestamp = draft.locationRefreshedAt ?? draft.locationCapturedAt;
  const freshness = timestamp ? ` · ${draft.locationRefreshedAt ? "Last refreshed" : "Captured"} ${new Date(timestamp).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}` : "";
  const freshnessLabel = timestamp ? ` ${draft.locationRefreshedAt ? "Last refreshed" : "Captured"} ${new Date(timestamp).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}.` : "";
  if (!draft.latitude || !draft.longitude) return { title: "No location attached", detail: "This report does not include device coordinates.", label: "No location attached." };
  if (draft.locationSource === "saved-without-map") return { title: "Accepted without map", detail: `Saved coordinates remain attached; map preview was unavailable.${freshness}`, label: `Location accepted without map. Saved coordinates remain attached.${freshnessLabel}` };
  if (draft.locationRefreshedAt) return { title: "Location refreshed", detail: `Pin unchanged · ${draft.accuracy ? `±${Math.round(draft.accuracy)}m accuracy` : "accuracy estimate unavailable"}${freshness}`, label: `Location accuracy refreshed; confirmed pin unchanged.${freshnessLabel}` };
  if (draft.locationSource === "map") return { title: "Map-confirmed location", detail: `${draft.accuracy ? `Approximate accuracy · ±${Math.round(draft.accuracy)}m` : "Approximate accuracy estimate unavailable."}${freshness}`, label: `Map-confirmed location.${freshnessLabel} ${draft.accuracy ? `Approximate accuracy plus or minus ${Math.round(draft.accuracy)} meters.` : "Accuracy estimate unavailable."}` };
  return { title: "Approximate location", detail: `${draft.accuracy ? `Device coordinates · ±${Math.round(draft.accuracy)}m` : "Device coordinates saved locally."}${freshness}`, label: `Approximate location.${freshnessLabel} ${draft.accuracy ? `Accuracy plus or minus ${Math.round(draft.accuracy)} meters.` : "Coordinates saved locally."}` };
}

function QueuedReportCard({ report, isOnline, retrying, failed, autoRetryPaused, onRetry, onClear, onReviseLocation, now, styles }: { report: GuardianQueuedReport; isOnline: boolean; retrying: boolean; failed: boolean; autoRetryPaused: boolean; onRetry: (report: GuardianQueuedReport) => void; onClear: (report: GuardianQueuedReport) => void; onReviseLocation: () => void; now: number; styles: ReturnType<typeof createStyles> }) {
  const retryDueNow = Boolean(report.nextRetryAt && new Date(report.nextRetryAt).getTime() <= now && !report.autoRetryExhausted);
  const locationStatus = getLocationStatus(report);
  return <View style={styles.reportCard}><View style={styles.cardHeader}><View style={styles.queueBadge}><Text style={styles.queueBadgeText}>!</Text></View><View style={styles.cardCopy}><Text style={styles.cardTitle}>{report.draft.category || "Uncategorized hazard"}</Text><Text style={styles.cardMeta}>{report.draft.severity} priority · Queued {new Date(report.queuedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</Text></View></View><Text style={styles.description}>{report.draft.description}</Text>{report.retryCount > 0 && <Text style={styles.attemptMeta}>{report.retryCount} attempt{report.retryCount === 1 ? "" : "s"} · Auto {report.automaticRetryCount ?? 0} · Manual {report.manualRetryCount ?? 0}{report.lastAttemptAt ? ` · Last tried ${new Date(report.lastAttemptAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}` : ""}{formatRetryCountdown(report.nextRetryAt, now) ? ` · ${formatRetryCountdown(report.nextRetryAt, now)}` : ""}</Text>}<View style={styles.detailRow} accessible accessibilityRole="text" accessibilityLabel={locationStatus.label}><Text style={styles.detailLabel}>Location</Text><View style={styles.locationStatusCopy}><Text style={styles.locationStatusTitle}>{locationStatus.title}</Text><Text style={styles.locationStatusDetail}>{locationStatus.detail}</Text>{report.draft.location && <Text style={styles.locationStatusAddress}>{report.draft.location}</Text>}</View></View><View style={styles.detailRow}><Text style={styles.detailLabel}>Attachments</Text><Text style={styles.detailValue}>{report.draft.photoUri ? "Photo attached" : report.draft.latitude ? "Location attached" : "None"}</Text></View><View accessible accessibilityRole="text" accessibilityLabel={`${retrying ? "Retrying report." : failed ? "Retry did not complete." : report.autoRetryExhausted ? "Automatic retries paused." : hasRetryScheduled(report.nextRetryAt, now) ? "Retry scheduled." : isOnline ? "Ready for retry." : "Waiting for connection."} Automatic attempts ${report.automaticRetryCount ?? 0}. Manual attempts ${report.manualRetryCount ?? 0}. ${formatRetryCountdown(report.nextRetryAt, now)}`} style={styles.statusBox}><Text style={styles.statusTitle}>{retrying ? "Retrying report" : failed ? "Retry did not complete" : autoRetryPaused ? "Automatic retries paused" : report.autoRetryExhausted ? "Automatic retries exhausted" : hasRetryScheduled(report.nextRetryAt, now) ? "Retry scheduled" : report.nextRetryAt && new Date(report.nextRetryAt).getTime() <= now ? "Retry ready now" : isOnline ? "Ready for retry" : "Waiting for connection"}</Text><Text style={styles.statusBody}>{retrying ? "Guardian is sending this report and creating its receipt." : failed ? report.lastFailureReason ?? "This report remains safely queued. Try again when the connection is stable." : autoRetryPaused ? "Automatic retries are paused for this device. Manual retry remains available." : report.autoRetryExhausted ? `Guardian paused automatic retries after ${MAX_AUTOMATIC_RETRIES} attempts. Use manual retry when you are ready.` : hasRetryScheduled(report.nextRetryAt, now) ? `Guardian will retry this report automatically. ${formatRetryCountdown(report.nextRetryAt, now)}.` : report.nextRetryAt && new Date(report.nextRetryAt).getTime() <= now ? "This report is ready for an automatic retry now." : isOnline ? "Retry only this report without affecting the rest of your outbox." : "Guardian will retry when the internet becomes reachable."}</Text></View><Pressable onPress={onReviseLocation} style={({ pressed }) => [styles.reviseLocationButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Revise queued report location" accessibilityHint="Opens the report form with this queued draft so you can update its saved location before retrying."><Text style={styles.reviseLocationText}>Revise location</Text></Pressable><View style={styles.actionRow}><Pressable onPress={() => onRetry(report)} disabled={!isOnline || retrying} style={({ pressed }) => [styles.primaryButton, styles.actionButton, retryDueNow && styles.dueRetryButton, (!isOnline || retrying) && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={retrying ? "Retrying queued report" : retryDueNow && isOnline ? "Retry queued report now" : isOnline ? "Retry queued report" : "Queued report offline"} accessibilityHint="Attempts to send only this report; other queued reports are unchanged."><Text style={styles.primaryButtonText}>{retrying ? "Retrying…" : isOnline ? retryDueNow ? "Retry now" : report.autoRetryExhausted ? "Retry manually" : failed ? "Retry this report" : "Send this report" : "Offline"}</Text></Pressable><Pressable onPress={() => onClear(report)} disabled={retrying} style={({ pressed }) => [styles.clearButton, retrying && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear queued report" accessibilityHint="Removes this report from the device after confirmation."><Text style={styles.clearButtonText}>Clear</Text></Pressable></View></View>;
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 13 }, back: { alignSelf: "flex-start", minHeight: 40, paddingVertical: 8, justifyContent: "center" }, backText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, privacyLink: { alignSelf: "flex-start", paddingVertical: 2 }, privacyLinkText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1, marginTop: 14 }, titleRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 }, titleCopy: { flex: 1 }, title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "900", marginTop: 2 }, subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginTop: 7, marginBottom: 4, maxWidth: 420 }, countBadge: { minWidth: 32, height: 32, borderRadius: 16, backgroundColor: colors.warning, alignItems: "center", justifyContent: "center", marginTop: 5 },     refreshStatusButton: { alignSelf: "flex-start", minHeight: 42, borderRadius: 10, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 11, justifyContent: "center" }, refreshStatusText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, pauseButton: { alignSelf: "flex-start", minHeight: 42, borderRadius: 18, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 13, justifyContent: "center" }, pauseButtonActive: { backgroundColor: "#FFF7E8", borderColor: colors.warning }, pauseText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, pauseTextActive: { color: colors.foreground }, resetViewButton: { alignSelf: "flex-start", minHeight: 40, borderRadius: 11, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 12, justifyContent: "center" }, resetViewText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, resetConfirmation: { flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: colors.success + "18", borderColor: colors.success + "55", borderWidth: 1, borderRadius: 12, padding: 10 }, resetConfirmationText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800" }, resetConfirmationDismiss: { minHeight: 34, borderRadius: 8, borderWidth: 1, borderColor: colors.success + "66", paddingHorizontal: 9, alignItems: "center", justifyContent: "center" }, resetConfirmationDismissText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, filterRow: { flexDirection: "row", gap: 8, marginTop: 2, flexWrap: "wrap" }, queueSummaryActions: { flexDirection: "row", gap: 8, flexWrap: "wrap", marginTop: 2 }, sortRow: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: -4 }, sortLabel: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800", marginRight: 2 }, sortChip: { minHeight: 38, borderRadius: 16, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 10, alignItems: "center", justifyContent: "center" }, sortChipActive: { backgroundColor: colors.surface, borderColor: colors.primary }, filterChip: { minHeight: 36, borderRadius: 18, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 12, alignItems: "center", justifyContent: "center" }, filterChipActive: { backgroundColor: colors.primary, borderColor: colors.primary }, filterChipText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, filterChipTextActive: { color: "#FFFFFF" }, filteredEmpty: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 20, alignItems: "center", gap: 8 }, countText: { color: "#FFFFFF", fontSize: scaleTextSize(14, largeText), fontWeight: "900" }, networkBanner: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 7, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 }, online: { backgroundColor: "#EAF7EF" }, offline: { backgroundColor: "#FFF7E8" }, dot: { width: 7, height: 7, borderRadius: 4 }, networkText: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, list: { gap: 13, marginTop: 5 }, reportCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 16, gap: 14 }, cardHeader: { flexDirection: "row", alignItems: "center", gap: 11 }, queueBadge: { width: 40, height: 40, borderRadius: 13, backgroundColor: colors.warning, alignItems: "center", justifyContent: "center" }, queueBadgeText: { color: "#FFFFFF", fontSize: scaleTextSize(21, largeText), fontWeight: "900" }, cardCopy: { flex: 1 }, cardTitle: { color: colors.foreground, fontSize: scaleTextSize(16, largeText), fontWeight: "900" }, cardMeta: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: 3 }, description: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), lineHeight: 20 }, attemptMeta: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "700" }, detailRow: { flexDirection: "row", justifyContent: "space-between", gap: 12, borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 10 }, detailLabel: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, locationStatusCopy: { flex: 1, alignItems: "flex-end", gap: 2 }, locationStatusTitle: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "900", textAlign: "right" }, locationStatusDetail: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 14, textAlign: "right" }, locationStatusAddress: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 14, textAlign: "right" }, detailValue: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), flex: 1, textAlign: "right" }, statusBox: { backgroundColor: "#FFF7E8", borderColor: "#F3D49B", borderWidth: 1, borderRadius: 13, padding: 11, gap: 3 }, statusTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, statusBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, actionRow: { flexDirection: "row", gap: 9 }, actionButton: { flex: 1 },     primaryButton: { minHeight: 48, borderRadius: 14, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 18 }, dueRetryButton: { backgroundColor: colors.warning }, reviseLocationButton: { minHeight: 42, borderRadius: 12, borderColor: colors.primary + "66", borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 12 }, reviseLocationText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, primaryButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, clearButton: { minHeight: 48, borderRadius: 14, borderColor: colors.border, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 17 }, clearButtonText: { color: colors.muted, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, disabled: { opacity: 0.5 }, emptyCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 20, alignItems: "center", marginTop: 5 }, emptyIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: colors.success, alignItems: "center", justifyContent: "center", marginBottom: 13 }, emptyIconText: { color: "#FFFFFF", fontSize: scaleTextSize(24, largeText), fontWeight: "900" }, emptyTitle: { color: colors.foreground, fontSize: scaleTextSize(17, largeText), fontWeight: "900", textAlign: "center" }, emptyBody: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 19, textAlign: "center", marginTop: 7 }, secondaryButton: { minHeight: 46, borderRadius: 13, backgroundColor: colors.background, borderColor: colors.primary, borderWidth: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 18, marginTop: 17, width: "100%" }, secondaryButtonText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, undoBanner: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 12 }, undoCopy: { flex: 1, gap: 2 }, undoTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, undoBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, undoButton: { minHeight: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 14 }, undoButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, batchSummaryCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 12, gap: 3 }, batchSummaryTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, batchSummaryTime: { color: colors.muted, fontSize: scaleTextSize(10, largeText) }, batchSummaryBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, summaryClearButton: { alignSelf: "flex-start", minHeight: 32, borderRadius: 9, borderColor: colors.border, borderWidth: 1, justifyContent: "center", paddingHorizontal: 10, marginTop: 4 }, summaryClearText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, batchRetryPanel: { gap: 6, marginTop: 2 }, announcementPreference: { alignSelf: "flex-start", minHeight: 38, borderRadius: 10, borderColor: colors.border, borderWidth: 1, paddingHorizontal: 10, justifyContent: "center" }, announcementPreferenceText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" }, announcementPreferenceConfirmation: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.success + "18", borderColor: colors.success + "55", borderWidth: 1, borderRadius: 10, padding: 9 }, announcementPreferenceConfirmationText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 15, fontWeight: "800" }, announcementPreferenceDismiss: { minHeight: 32, borderRadius: 8, borderWidth: 1, borderColor: colors.success + "66", paddingHorizontal: 8, alignItems: "center", justifyContent: "center" }, announcementPreferenceDismissText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, batchAnnouncement: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 }, batchAnnouncementText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800" }, batchRetryButton: { width: "100%" }, batchRetryHint: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, activitySection: { borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 16, gap: 10 }, activityHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, activityTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, activityCount: { borderRadius: 10, backgroundColor: colors.surface, paddingHorizontal: 8, paddingVertical: 3 }, activityCountText: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, activityEmpty: { borderRadius: 12, backgroundColor: colors.surface, padding: 10 }, activityEmptyText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, activityAction: { alignSelf: "flex-start", marginTop: 4, minHeight: 38, borderRadius: 9, backgroundColor: colors.primary, paddingHorizontal: 9, justifyContent: "center" }, activityActionText: { color: "#FFFFFF", fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, activityRow: { flexDirection: "row", alignItems: "center", gap: 9 }, activityDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.primary }, activityCopy: { flex: 1, flexDirection: "row", justifyContent: "space-between", gap: 8 }, activityLabel: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "700" }, activityTime: { color: colors.muted, fontSize: scaleTextSize(10, largeText) }, privacyNote: { borderTopColor: colors.border, borderTopWidth: 1, paddingTop: 16, marginTop: 5 }, privacyTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "800" }, privacyBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 4 }, pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
