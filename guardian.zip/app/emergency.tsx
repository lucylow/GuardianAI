import { useMemo } from "react";
import { Linking, Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

export default function EmergencyScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5" containerClassName="bg-background">
      <View style={styles.content}>
        <View style={styles.topRow}><Text style={styles.brand}>GUARDIAN</Text><Text style={styles.mode}>EMERGENCY MODE</Text></View>
        <View style={styles.hero}><View style={styles.alertIcon}><Text style={styles.alertIconText}>!</Text></View><Text style={styles.title}>Are you in immediate danger?</Text><Text style={styles.subtitle}>If someone is hurt, there is a fire, or a crime is happening now, call 911.</Text></View>
        <Pressable onPress={() => Linking.openURL("tel:911")} style={({ pressed }) => [styles.callButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Call 911 now"><Text style={styles.callText}>CALL 911</Text><Text style={styles.callDetail}>Opens your phone dialer</Text></Pressable>
        <View style={styles.infoCard}><Text style={styles.infoTitle}>Guardian cannot dispatch help.</Text><Text style={styles.infoBody}>This app can share guidance and help with non-emergency reports. Do not wait for a chat response when a person needs immediate help.</Text></View>
        <Text style={styles.guidanceTitle}>While you wait for help</Text>
        <View style={styles.guidance}><Text style={styles.guidanceNumber}>01</Text><Text style={styles.guidanceText}>Move to a safe place if you can do so without increasing danger.</Text></View>
        <View style={styles.guidance}><Text style={styles.guidanceNumber}>02</Text><Text style={styles.guidanceText}>Keep the line open and follow the dispatcher&apos;s instructions.</Text></View>
        <Pressable onPress={() => Linking.openURL("https://www.ready.gov/")} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} accessibilityRole="link"><Text style={styles.secondaryText}>Open official preparedness resources</Text></Pressable>
      </View>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { flex: 1, paddingTop: 18, paddingBottom: 18 },
    topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
    brand: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900", letterSpacing: 1.4 },
    mode: { color: colors.error, fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 0.8 },
    hero: { alignItems: "center", marginTop: 42 },
    alertIcon: { width: 72, height: 72, borderRadius: 24, backgroundColor: colors.error, alignItems: "center", justifyContent: "center", marginBottom: 21 },
    alertIconText: { color: "#FFFFFF", fontSize: scaleTextSize(44, largeText), fontWeight: "900" },
    title: { color: colors.foreground, fontSize: scaleTextSize(29, largeText), fontWeight: "900", textAlign: "center", letterSpacing: -0.4 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(14, largeText), lineHeight: 21, textAlign: "center", marginTop: 11, maxWidth: 310 },
    callButton: { minHeight: 88, borderRadius: 20, backgroundColor: colors.error, alignItems: "center", justifyContent: "center", marginTop: 30 },
    callText: { color: "#FFFFFF", fontSize: scaleTextSize(22, largeText), fontWeight: "900", letterSpacing: 1 },
    callDetail: { color: "#FFE0E0", fontSize: scaleTextSize(11, largeText), marginTop: 4 },
    infoCard: { borderColor: colors.border, borderWidth: 1, borderRadius: 17, backgroundColor: colors.surface, padding: 15, marginTop: 17 },
    infoTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900" },
    infoBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 18, marginTop: 5 },
    guidanceTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900", marginTop: 24, marginBottom: 8 },
    guidance: { flexDirection: "row", gap: 12, paddingVertical: 9 },
    guidanceNumber: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900", width: 22 },
    guidanceText: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, flex: 1 },
    secondaryButton: { minHeight: 48, borderRadius: 15, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", marginTop: "auto" },
    secondaryText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
