import { boolean, decimal, index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const hazardReports = mysqlTable(
  "hazardReports",
  {
    id: int("id").autoincrement().primaryKey(),
    clientRequestId: varchar("clientRequestId", { length: 64 }).notNull().unique(),
    userId: int("userId"),
    category: varchar("category", { length: 64 }).notNull(),
    severity: mysqlEnum("severity", ["Low", "Medium", "High"]).notNull(),
    description: text("description").notNull(),
    locationText: varchar("locationText", { length: 255 }).notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 7 }),
    longitude: decimal("longitude", { precision: 10, scale: 7 }),
    accuracy: decimal("accuracy", { precision: 8, scale: 2 }),
    photoUri: text("photoUri"),
    source: mysqlEnum("source", ["mobile", "sms"]).default("mobile").notNull(),
    status: mysqlEnum("status", ["received", "queued", "triaged", "in_progress", "resolved", "rejected"]).default("received").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    statusIdx: index("hazardReports_status_idx").on(table.status),
    createdAtIdx: index("hazardReports_createdAt_idx").on(table.createdAt),
  }),
);

export type HazardReport = typeof hazardReports.$inferSelect;
export type InsertHazardReport = typeof hazardReports.$inferInsert;
