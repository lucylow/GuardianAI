CREATE TABLE `hazardReports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`clientRequestId` varchar(64) NOT NULL,
	`userId` int,
	`category` varchar(64) NOT NULL,
	`severity` enum('Low','Medium','High') NOT NULL,
	`description` text NOT NULL,
	`locationText` varchar(255) NOT NULL,
	`latitude` decimal(10,7),
	`longitude` decimal(10,7),
	`accuracy` decimal(8,2),
	`photoUri` text,
	`source` enum('mobile','sms') NOT NULL DEFAULT 'mobile',
	`status` enum('received','queued','triaged','in_progress','resolved','rejected') NOT NULL DEFAULT 'received',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hazardReports_id` PRIMARY KEY(`id`),
	CONSTRAINT `hazardReports_clientRequestId_unique` UNIQUE(`clientRequestId`)
);
--> statement-breakpoint
CREATE INDEX `hazardReports_status_idx` ON `hazardReports` (`status`);--> statement-breakpoint
CREATE INDEX `hazardReports_createdAt_idx` ON `hazardReports` (`createdAt`);