# Guardian Accessibility Verification

## Completed in the sandbox

The Profile bulk-retry announcement switch exposes an explicit On or Off label, `accessibilityRole="switch"`, and matching `accessibilityState.checked` semantics. The Profile example is exposed as one concise accessible description explaining the On and Off behaviors. Profile preference changes use a polite live alert with a dismissible action.

The Outbox announcement control uses the same switch role and checked state, persists through `guardian.setting.batchAnnounceSteps`, and exposes a polite live confirmation with an accessible Dismiss action. Essential batch start, completion, failure, and cancellation feedback remains available when repeated step announcements are disabled.

Automated TypeScript, lint, unit-test, server-build, and web visual checks passed. The implementation is platform-safe: it uses React Native accessibility props and does not depend on web-only APIs for the switch or live confirmation behavior.

## Physical-device verification status

A physical iOS or Android runtime was not attached to this sandbox, so VoiceOver and TalkBack speech output and announcement timing could not be directly observed here. The following device pass remains recommended before release:

| Platform | Flow | Expected result |
|---|---|---|
| iOS VoiceOver | Focus Profile > Bulk retry step announcements | VoiceOver announces the label, current On/Off state, and switch role. |
| iOS VoiceOver | Toggle the switch | The confirmation announces the new behavior and exposes Dismiss. |
| Android TalkBack | Focus the same Profile switch | TalkBack announces the label, current state, and switch role. |
| Android TalkBack | Toggle the switch | The confirmation is announced once, remains dismissible, and does not interrupt essential batch feedback. |
| iOS and Android | Open Outbox after changing Profile | Outbox reflects the persisted preference and uses the same confirmation semantics. |
