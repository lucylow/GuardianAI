import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system/legacy";
import * as Location from "expo-location";
import * as Network from "expo-network";
import * as SMS from "expo-sms";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ActivityIndicator, Alert, Image, Keyboard, KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { GuardianStatusCard } from "@/components/guardian/status-card";
import { buildSmsReportMessage, validateGuardianReport, type GuardianReportDraft } from "@/lib/guardian-report";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";
import { appendActivityEvent, removeQueuedReport, readQueuedReports, upsertQueuedReport, type GuardianQueuedReport } from "@/lib/guardian-queue";
import { NativeMapView, NativeMarker, NativeCircle } from "@/components/guardian/native-map";
import { trpc } from "@/lib/trpc";

const DRAFT_KEY = "guardian.report.draft";
const MAP_STYLE_KEY = "guardian.report.mapStyle";
const MAP_PROVIDER_KEY = "guardian.report.mapProvider.v1";
const HAPTICS_KEY = "guardian.setting.hapticsEnabled";
const LABEL_CACHE_KEY = "guardian.report.geocodedLabel";
const categories = ["Pothole", "Flooding", "Ice / snow", "Streetlight", "Traffic concern", "Other"];
const severities = ["Low", "Medium", "High"];
const aiFeedbackReasons = ["Wrong category", "Missed photo context", "Too uncertain", "Other"];

type ReportDraft = GuardianReportDraft & { photoUri?: string; latitude?: number; longitude?: number; accuracy?: number; locationCapturedAt?: number; locationRefreshedAt?: number; locationSource?: "map" | "saved-without-map" };
type QueuedReport = GuardianQueuedReport;
type MapStyle = "standard" | "satellite";
type MapProvider = "Apple Maps" | "Google Maps";
const initialDraft: ReportDraft = { category: "", severity: "Medium", description: "", location: "" };

function getAiContextHints(draft: ReportDraft) {
  const hints: string[] = [];
  if (draft.description.trim().length < 12) hints.push("what happened");
  if (!draft.location.trim() && !draft.latitude) hints.push("where it is");
  return hints;
}

function getCategoryGuidance(category: string) {
  switch (category) {
    case "Pothole": return "For a stronger AI suggestion, include approximate size, lane or sidewalk impact, and whether it is difficult to avoid.";
    case "Flooding": return "Include estimated water depth, whether water is moving, and whether a road, sidewalk, or entrance is blocked.";
    case "Ice / snow": return "Include the affected surface and whether people, vehicles, or mobility devices are at risk of slipping.";
    case "Streetlight": return "Include whether the light is out or flickering, the nearest landmark, and whether visibility is affected.";
    case "Traffic concern": return "Include the intersection or direction of travel, the obstruction or behavior, and any immediate safety impact.";
    case "Other": return "Include who or what is affected, where it is happening, and what makes the concern urgent or unusual.";
    default: return null;
  }
}

function getAiConfidenceGuidance(confidence: number, draft: ReportDraft) {
  const missingContext = getAiContextHints(draft);
  if (missingContext.length > 0) return "Limited context: treat this as a starting point and verify the category carefully.";
  if (confidence >= 0.8) return "Strong match: the description gives Guardian useful evidence, but your review is still required.";
  if (confidence >= 0.55) return "Tentative match: the available details support this category, but another category may fit better.";
  return "Limited match: Guardian is uncertain. Review the rationale or choose the category yourself.";
}

export function ReportScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const router = useRouter();
  const { reviseClientRequestId } = useLocalSearchParams<{ reviseClientRequestId?: string }>();
  const insets = useSafeAreaInsets();
  const [draft, setDraft] = useState<ReportDraft>(initialDraft);
  const [saved, setSaved] = useState(false);
  const [draftRestored, setDraftRestored] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [validationCursor, setValidationCursor] = useState(0);
  const [validationCompleted, setValidationCompleted] = useState(false);
  const [saveConfirmation, setSaveConfirmation] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submissionOutcome, setSubmissionOutcome] = useState<"submitted" | "queued" | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [receiptId, setReceiptId] = useState<string | null>(null);
  const [aiSuggestion, setAiSuggestion] = useState<{ category: string; confidence: number; rationale: string; safetyNote: string } | null>(null);
  const [aiApplied, setAiApplied] = useState(false);
  const [aiExplanationOpen, setAiExplanationOpen] = useState(false);
  const [aiDecision, setAiDecision] = useState<"applied" | "kept" | null>(null);
  const [aiFeedback, setAiFeedback] = useState<"helpful" | "not-helpful" | null>(null);
  const [aiFeedbackReason, setAiFeedbackReason] = useState("");
  const [aiFeedbackReasonSaved, setAiFeedbackReasonSaved] = useState(false);
  const [queuedReport, setQueuedReport] = useState<QueuedReport | null>(null);
  const networkState = Network.useNetworkState();
  const isOnline = networkState.isInternetReachable !== false && networkState.isConnected !== false;
  const wasOnline = useRef(isOnline);
  const [locating, setLocating] = useState(false);
  const [refreshingLocation, setRefreshingLocation] = useState(false);
  const [refreshConfirmation, setRefreshConfirmation] = useState(false);
  const [hapticsEnabled, setHapticsEnabled] = useState(true);
  const [locationStatus, setLocationStatus] = useState<"unknown" | "ready" | "denied" | "disabled" | "unavailable">("unknown");
  const [locationStatusMessage, setLocationStatusMessage] = useState("Location status has not been checked.");
  const [locationCapturedAt, setLocationCapturedAt] = useState<number | null>(null);
  const [pinConfirmed, setPinConfirmed] = useState(true);
  const [mapStyle, setMapStyle] = useState<MapStyle>("standard");
  const [preferredMapProvider, setPreferredMapProvider] = useState<MapProvider>(() => Platform.OS === "ios" ? "Apple Maps" : "Google Maps");
  const [preferredMapProviderLoaded, setPreferredMapProviderLoaded] = useState(false);
  const [geocoding, setGeocoding] = useState(false);
  const [addressSuggestion, setAddressSuggestion] = useState<string | null>(null);
  const [addressRefreshedAt, setAddressRefreshedAt] = useState<number | null>(null);
  const [mapInteractionFeedback, setMapInteractionFeedback] = useState<string | null>(null);
  const [mapStatus, setMapStatus] = useState<"loading" | "ready" | "unavailable">("loading");
  const [mapAttempt, setMapAttempt] = useState(0);
  const [mapFallbackAcknowledged, setMapFallbackAcknowledged] = useState(false);
  const [editingQueuedId, setEditingQueuedId] = useState<string | null>(null);
  const mapRef = useRef<any>(null);
  const mapFeedbackTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollRef = useRef<ScrollView | null>(null);
  const descriptionRef = useRef<TextInput | null>(null);
  const locationRef = useRef<TextInput | null>(null);
  const createReport = trpc.reports.create.useMutation();
  const categorize = trpc.reports.categorize.useMutation();

  const retryQueuedReport = useCallback(async () => {
    if (!queuedReport || !isOnline || submitting) return;
    try {
      setSubmitting(true);
      await appendActivityEvent("retry_started", queuedReport.clientRequestId);
      const receipt = await createReport.mutateAsync({
        clientRequestId: queuedReport.clientRequestId,
        category: queuedReport.draft.category,
        severity: queuedReport.draft.severity as "Low" | "Medium" | "High",
        description: queuedReport.draft.description.trim(),
        locationText: queuedReport.draft.location.trim(),
        latitude: queuedReport.draft.latitude,
        longitude: queuedReport.draft.longitude,
        accuracy: queuedReport.draft.accuracy,
        photoUri: queuedReport.draft.photoUri,
      });
      await AsyncStorage.setItem(`guardian.report.receipt.${queuedReport.clientRequestId}`, JSON.stringify(receipt));
      await removeQueuedReport(queuedReport.clientRequestId);
      await AsyncStorage.removeItem(DRAFT_KEY);
      setQueuedReport(null);
      setDraft(queuedReport.draft);
      setReceiptId(receipt.clientRequestId);
      await appendActivityEvent("submitted", queuedReport.clientRequestId);
      setSubmitted(true);
    } catch {
      await appendActivityEvent("retry_failed", queuedReport.clientRequestId);
      // Keep the queued report intact for another retry.
    } finally {
      setSubmitting(false);
    }
  }, [createReport, isOnline, queuedReport, submitting]);

  const refreshLocationStatus = useCallback(async () => {
    if (Platform.OS === "web") { setLocationStatus("unavailable"); setLocationStatusMessage("Native location status is available on the mobile app."); return; }
    try {
      const permission = await Location.getForegroundPermissionsAsync();
      if (permission.status !== "granted") { setLocationStatus("denied"); setLocationStatusMessage("Location access is not enabled. You can still enter a landmark manually."); return; }
      const enabled = await Location.hasServicesEnabledAsync();
      if (!enabled) { setLocationStatus("disabled"); setLocationStatusMessage("Device location services are off. Turn them on or enter a landmark manually."); return; }
      setLocationStatus("ready");
      setLocationStatusMessage("Ready to attach an approximate location when you choose.");
    } catch {
      setLocationStatus("unavailable");
      setLocationStatusMessage("Location status is temporarily unavailable. Manual entry remains available.");
    }
  }, []);

  useEffect(() => () => {
    if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current);
  }, []);

  useEffect(() => {
    if (Platform.OS === "web" || !draft.latitude || !draft.longitude) return;
    setMapStatus("loading");
    const timeout = setTimeout(() => setMapStatus((current) => current === "loading" ? "unavailable" : current), 6000);
    return () => clearTimeout(timeout);
  }, [draft.latitude, draft.longitude, mapAttempt]);

  useEffect(() => {
    void refreshLocationStatus();
    AsyncStorage.getItem(DRAFT_KEY).then((value) => { if (value) { const restored = JSON.parse(value) as ReportDraft; setDraft(restored); setDraftRestored(true); setSaved(true); if (restored.locationCapturedAt) setLocationCapturedAt(restored.locationCapturedAt); } }).catch(() => undefined);
    if (reviseClientRequestId) readQueuedReports().then((queue) => { const queued = queue.find((item) => item.clientRequestId === reviseClientRequestId); if (!queued) return; setDraft(queued.draft); setQueuedReport(queued); setEditingQueuedId(queued.clientRequestId); setDraftRestored(true); setSaved(true); setPinConfirmed(queued.draft.locationSource === "saved-without-map" || queued.draft.locationSource === "map"); if (queued.draft.locationCapturedAt) setLocationCapturedAt(queued.draft.locationCapturedAt); if (queued.draft.locationSource === "saved-without-map") setMapFallbackAcknowledged(true); }).catch(() => undefined);
    AsyncStorage.getItem(MAP_STYLE_KEY).then((value) => { if (value === "standard" || value === "satellite") setMapStyle(value); }).catch(() => undefined);
    AsyncStorage.getItem(MAP_PROVIDER_KEY).then((value) => { if (value === "Apple Maps" || value === "Google Maps") setPreferredMapProvider(value); }).catch(() => undefined).finally(() => setPreferredMapProviderLoaded(true));
    AsyncStorage.getItem(HAPTICS_KEY).then((value) => { setHapticsEnabled(value !== "false"); }).catch(() => undefined);
    AsyncStorage.getItem(LABEL_CACHE_KEY).then((value) => { if (value) { const cached = JSON.parse(value) as { latitude: number; longitude: number; label: string; refreshedAt?: number }; if (cached.label) { setAddressSuggestion(cached.label); setAddressRefreshedAt(cached.refreshedAt ?? null); } } }).catch(() => undefined);
    readQueuedReports().then((queue) => { if (queue[0]) setQueuedReport(queue[0]); }).catch(() => undefined);
    if (Platform.OS !== "web") {
      ImagePicker.getPendingResultAsync().then((result) => {
        if (result && "canceled" in result && !result.canceled && "assets" in result && result.assets && result.assets[0]) update({ photoUri: result.assets[0].uri });
      }).catch(() => undefined);
    }
    // Retry a queued report only when connectivity transitions from offline to online.
    // Intentionally hydrate the local draft only once when the screen mounts.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (preferredMapProviderLoaded) AsyncStorage.setItem(MAP_PROVIDER_KEY, preferredMapProvider).catch(() => undefined);
  }, [preferredMapProvider, preferredMapProviderLoaded]);

  useEffect(() => {
    const restored = !wasOnline.current && isOnline;
    wasOnline.current = isOnline;
    if (restored && queuedReport) void retryQueuedReport();
  }, [isOnline, queuedReport, retryQueuedReport]);

  const update = (patch: Partial<ReportDraft>) => {
    const next = { ...draft, ...patch };
    setDraft(next);
    setSaved(false);
    setDraftRestored(false);
    setSaveConfirmation(false);
    const nextErrors = { ...validationErrors };
    Object.keys(patch).forEach((key) => { delete nextErrors[key]; });
    if (Object.keys(validationErrors).length > 0 && Object.keys(nextErrors).length === 0) setValidationCompleted(true);
    setValidationErrors(nextErrors);
    AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(next)).catch(() => undefined);
  };

  const captureLocation = async () => {
    setLocating(true);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        setLocationStatus("denied");
        setLocationStatusMessage("Location access is not enabled. Manual entry remains available.");
        Alert.alert("Location is optional", "You can still enter a landmark or intersection manually.");
        return;
      }
      const enabled = await Location.hasServicesEnabledAsync();
      if (!enabled) {
        setLocationStatus("disabled");
        setLocationStatusMessage("Device location services are off. Manual entry remains available.");
        Alert.alert("Location services are off", "Turn on location services or enter a landmark manually.");
        return;
      }
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const capturedAt = Date.now();
      update({ latitude: current.coords.latitude, longitude: current.coords.longitude, accuracy: current.coords.accuracy ?? undefined, location: draft.location || "Current location", locationCapturedAt: capturedAt, locationSource: "map" });
      setLocationStatus("ready");
      setLocationStatusMessage("Location captured. Accuracy is approximate; verify the pin before submitting.");
      setLocationCapturedAt(capturedAt);
      setPinConfirmed(true);
      void lookupAddress(current.coords.latitude, current.coords.longitude);
    } catch {
      setLocationStatus("unavailable");
      setLocationStatusMessage("Could not read the device location. Manual entry remains available.");
      Alert.alert("Could not get location", "Enter a landmark or intersection manually instead.");
    } finally {
      setLocating(false);
    }
  };

  const refreshLocation = async () => {
    if (Platform.OS === "web" || !draft.latitude || !draft.longitude || refreshingLocation) return;
    setRefreshingLocation(true);
    setRefreshConfirmation(false);
    try {
      const permission = await Location.getForegroundPermissionsAsync();
      if (permission.status !== "granted") { setLocationStatus("denied"); setLocationStatusMessage("Location access is not enabled. Your confirmed map pin was not changed."); return; }
      const enabled = await Location.hasServicesEnabledAsync();
      if (!enabled) { setLocationStatus("disabled"); setLocationStatusMessage("Device location services are off. Your confirmed map pin was not changed."); return; }
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const capturedAt = Date.now();
      update({ accuracy: current.coords.accuracy ?? draft.accuracy, locationCapturedAt: capturedAt, locationRefreshedAt: capturedAt, locationSource: "map" });
      setLocationCapturedAt(capturedAt);
      setLocationStatus("ready");
      setLocationStatusMessage("Fresh signal reading captured. Your report text and confirmed map pin were not changed.");
      setRefreshConfirmation(true);
      setMapInteractionFeedback("Location accuracy refreshed. Confirmed pin unchanged.");
      if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current);
      mapFeedbackTimer.current = setTimeout(() => setMapInteractionFeedback(null), 5000);
      if (hapticsEnabled) void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    } catch {
      setLocationStatus("unavailable");
      setLocationStatusMessage("Could not refresh the location signal. Your confirmed map pin was not changed.");
    } finally {
      setRefreshingLocation(false);
    }
  };

  const recenterMap = () => {
    if (!draft.latitude || !draft.longitude || !mapRef.current) return;
    mapRef.current.animateToRegion({ latitude: draft.latitude, longitude: draft.longitude, latitudeDelta: 0.006, longitudeDelta: 0.006 }, 350);
    setMapInteractionFeedback("Map recentered on the attached location.");
    if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current);
    mapFeedbackTimer.current = setTimeout(() => setMapInteractionFeedback(null), 4000);
  };

  const retryMapLoad = () => {
    setMapFallbackAcknowledged(false);
    setMapStatus("loading");
    setMapAttempt((attempt) => attempt + 1);
  };

  const useSavedCoordinatesWithoutMap = () => {
    setPinConfirmed(true);
    update({ locationSource: "saved-without-map" });
    setMapFallbackAcknowledged(true);
    setMapInteractionFeedback("Saved coordinates accepted. You can submit without the map preview.");
    if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current);
    mapFeedbackTimer.current = setTimeout(() => setMapInteractionFeedback(null), 5000);
  };

  const updateMapPin = (latitude: number, longitude: number) => {
    update({ latitude, longitude, location: draft.location || "Pinned map location", locationSource: "map" });
    setPinConfirmed(false);
    setAddressSuggestion(null);
    setAddressRefreshedAt(null);
    setMapInteractionFeedback("Map pin moved. Review the location, then choose Use this pin to confirm it.");
    if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current);
    mapFeedbackTimer.current = setTimeout(() => setMapInteractionFeedback(null), 6000);
  };

  const lookupAddress = async (latitude: number, longitude: number) => {
    if (Platform.OS === "web") return;
    setGeocoding(true);
    try {
      const [place] = await Location.reverseGeocodeAsync({ latitude, longitude });
      const parts = [place?.name, place?.street, place?.city, place?.region].filter(Boolean);
      const label = parts.length ? parts.join(", ") : null;
      setAddressSuggestion(label);
      if (label) { const refreshedAt = Date.now(); setAddressRefreshedAt(refreshedAt); await AsyncStorage.setItem(LABEL_CACHE_KEY, JSON.stringify({ latitude, longitude, label, refreshedAt })); }
    } catch {
      setAddressSuggestion(null);
    } finally {
      setGeocoding(false);
    }
  };

  const confirmPin = () => {
    setPinConfirmed(true);
    update({ locationSource: "map" });
    setMapStatus((current) => current === "unavailable" ? "unavailable" : current);
    if (hapticsEnabled) void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    if (draft.latitude && draft.longitude) void lookupAddress(draft.latitude, draft.longitude);
  };

  const changeMapStyle = (nextStyle: MapStyle) => {
    setMapStyle(nextStyle);
    AsyncStorage.setItem(MAP_STYLE_KEY, nextStyle).catch(() => undefined);
  };

  const pickPhoto = async (source: "camera" | "library") => {
    try {
      if (source === "camera") {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (permission.status !== "granted") { Alert.alert("Camera permission needed", "You can continue without a photo."); return; }
      }
      const result = source === "camera"
        ? await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 3], quality: 0.7 })
        : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 3], quality: 0.7 });
      if (!result.canceled && result.assets[0]) update({ photoUri: result.assets[0].uri });
    } catch {
      Alert.alert("Photo unavailable", "The report can be submitted without an attachment.");
    }
  };

  const showPhotoOptions = () => Alert.alert("Add a photo", "Choose how to attach an image.", [
    { text: "Take photo", onPress: () => pickPhoto("camera") },
    { text: "Choose from library", onPress: () => pickPhoto("library") },
    { text: "Cancel", style: "cancel" },
  ]);

  const requestAiSuggestion = async () => {
    try {
      let photoDataUrl: string | undefined;
      if (draft.photoUri && Platform.OS !== "web") {
        const base64 = await FileSystem.readAsStringAsync(draft.photoUri, { encoding: FileSystem.EncodingType.Base64 });
        photoDataUrl = `data:image/jpeg;base64,${base64}`;
      }
      const suggestion = await categorize.mutateAsync({ description: draft.description.trim(), photoDataUrl });
      setAiApplied(false);
      setAiDecision(null);
      setAiFeedback(null);
      setAiFeedbackReason("");
      setAiFeedbackReasonSaved(false);
      setAiExplanationOpen(false);
      setAiSuggestion(suggestion);
    } catch {
      Alert.alert("Suggestion unavailable", "Guardian could not classify this report right now. You can choose a category manually. Your report can still be saved or submitted without AI.");
    }
  };

  const suggestCategory = () => {
    if (draft.description.trim().length < 3) {
      Alert.alert("Add a little more detail", "Describe the concern before asking Guardian to suggest a category.");
      return;
    }
    const hints = getAiContextHints(draft);
    if (hints.length > 0) {
      Alert.alert(
        "Help Guardian be more specific",
        `For a stronger suggestion, consider adding ${hints.join(" and ")}. You can still continue with the information already entered.`,
        [
          { text: "Keep editing", style: "cancel" },
          { text: "Suggest anyway", onPress: () => void requestAiSuggestion() },
        ],
      );
      return;
    }
    void requestAiSuggestion();
  };

  const applyAiSuggestion = () => {
    if (!aiSuggestion) return;
    update({ category: aiSuggestion.category });
    setAiApplied(true);
    setAiDecision("applied");
  };

  const keepMyCategory = () => {
    setAiSuggestion(null);
    setAiApplied(false);
    setAiExplanationOpen(false);
    setAiDecision("kept");
  };

  const saveAiFeedbackReason = async () => {
    const reason = aiFeedbackReason.trim();
    if (!reason) return;
    await appendActivityEvent("ai_feedback_reason_saved");
    setAiFeedbackReasonSaved(true);
  };

  const focusValidationIssue = useCallback((field: string) => {
    if (field === "description") {
      scrollRef.current?.scrollTo({ y: 300, animated: true });
      setTimeout(() => descriptionRef.current?.focus(), 250);
    } else if (field === "location") {
      scrollRef.current?.scrollTo({ y: 520, animated: true });
      setTimeout(() => locationRef.current?.focus(), 250);
    } else {
      scrollRef.current?.scrollTo({ y: 0, animated: true });
    }
  }, []);

  const focusNextValidationIssue = useCallback(() => {
    const fields = Object.keys(validationErrors);
    if (fields.length === 0) return;
    const nextIndex = (validationCursor + 1) % fields.length;
    setValidationCursor(nextIndex);
    focusValidationIssue(fields[nextIndex]);
  }, [focusValidationIssue, validationCursor, validationErrors]);

  const improveAiConfidence = () => {
    const missingContext = getAiContextHints(draft);
    if (missingContext.includes("what happened")) {
      focusValidationIssue("description");
      return;
    }
    if (missingContext.includes("where it is")) {
      focusValidationIssue("location");
      return;
    }
    setAiExplanationOpen(true);
  };

  const saveDraft = async () => {
    const errors = validateGuardianReport(draft);
    if (Object.keys(errors).length) {
      setValidationCompleted(false);
      setValidationErrors(errors);
      Alert.alert("A few details are needed", Object.values(errors).join("\\n"));
      const firstError = Object.keys(errors)[0];
      setValidationCursor(0);
      focusValidationIssue(firstError);
      return;
    }
    setValidationErrors({});
    setValidationCursor(0);
    setValidationCompleted(false);
    const clientRequestId = `guardian-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    try {
      setSubmitting(true);
      const receipt = await createReport.mutateAsync({
        clientRequestId,
        category: draft.category,
        severity: draft.severity as "Low" | "Medium" | "High",
        description: draft.description.trim(),
        locationText: draft.location.trim(),
        latitude: draft.latitude,
        longitude: draft.longitude,
        accuracy: draft.accuracy,
        photoUri: draft.photoUri,
      });
      await AsyncStorage.setItem(`guardian.report.receipt.${clientRequestId}`, JSON.stringify(receipt));
      await appendActivityEvent("submitted", clientRequestId);
      await AsyncStorage.removeItem(DRAFT_KEY);
      setReceiptId(receipt.clientRequestId);
      setSubmissionOutcome("submitted");
      setSubmitted(true);
      if (Platform.OS !== "web" && hapticsEnabled) void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    } catch {
      const queued = { draft, clientRequestId, queuedAt: new Date().toISOString(), retryCount: 0, automaticRetryCount: 0, manualRetryCount: 0 } satisfies QueuedReport;
      await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      await upsertQueuedReport(queued);
      await appendActivityEvent("queued", clientRequestId);
      setQueuedReport(queued);
      setSubmissionOutcome("queued");
      setSubmitted(true);
      Alert.alert("Report queued", isOnline ? "Guardian could not complete the request. Your report is saved on this device and can be retried." : "You are offline. Your report is saved on this device and will be retried when connectivity returns.");
    } finally {
      setSubmitting(false);
    }
  };

  const removePhoto = () => {
    Alert.alert("Remove attached photo?", "The photo will be removed from this local draft and will not be included if you submit.", [
      { text: "Keep photo", style: "cancel" },
      { text: "Remove photo", style: "destructive", onPress: () => update({ photoUri: undefined }) },
    ]);
  };

  const openSms = async () => {
    const available = await SMS.isAvailableAsync();
    if (!available) { Alert.alert("SMS is unavailable", "Use the app when you have a connection, or call 911 for immediate danger."); return; }
    await SMS.sendSMSAsync(["3175554827"], buildSmsReportMessage(draft));
  };

  const openInMaps = () => {
    if (typeof draft.latitude !== "number" || typeof draft.longitude !== "number") return;
    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${draft.latitude},${draft.longitude}`;
    const appleMapsUrl = `http://maps.apple.com/?ll=${draft.latitude},${draft.longitude}&q=Guardian%20report`;
    const confirmProvider = (provider: MapProvider, url: string) => {
      setPreferredMapProvider(provider);
      Alert.alert(`Open in ${provider}?`, `Guardian will leave this app and share the saved approximate coordinates with ${provider}. The report itself remains unchanged, and Guardian will keep provider and coordinate details out of its local activity history.`, [
        { text: "Cancel", style: "cancel" },
        { text: `Open ${provider}`, onPress: () => { setMapInteractionFeedback(`${provider} handoff confirmed. Provider and coordinates were not stored in activity history.`); void appendActivityEvent("external_map_opened").then(() => Linking.openURL(url)).catch(() => Alert.alert(`${provider} unavailable`, "The saved coordinates remain in Guardian. Try again when you have a connection.")); } },
      ]);
    };
    const chooseProvider = () => Alert.alert("Choose map service", "Select where to view this approximate saved location. Guardian will ask for confirmation before leaving the app.", [
      { text: "Apple Maps", onPress: () => confirmProvider("Apple Maps", appleMapsUrl) },
      { text: "Google Maps", onPress: () => confirmProvider("Google Maps", googleMapsUrl) },
      { text: "Cancel", style: "cancel" },
    ]);
    if (Platform.OS === "ios") {
      const preferredUrl = preferredMapProvider === "Apple Maps" ? appleMapsUrl : googleMapsUrl;
      Alert.alert(`Use ${preferredMapProvider}?`, `Guardian remembers ${preferredMapProvider} as your device-local preference. You can choose another service without changing the report.`, [
        { text: `Open ${preferredMapProvider}`, onPress: () => confirmProvider(preferredMapProvider, preferredUrl) },
        { text: "Choose another", onPress: chooseProvider },
        { text: "Cancel", style: "cancel" },
      ]);
      return;
    }
    confirmProvider("Google Maps", googleMapsUrl);
  };

  if (submitting) return <SubmissionLoading styles={styles} />;
  if (submitted) return <Confirmation draft={draft} receiptId={receiptId} outcome={submissionOutcome ?? "submitted"} locationAcceptedWithoutMap={mapFallbackAcknowledged} onReset={() => { setSubmitted(false); setSubmissionOutcome(null); setReceiptId(null); setQueuedReport(null); setAiSuggestion(null); setLocationCapturedAt(null); setMapFallbackAcknowledged(false); setDraft(initialDraft); }} onViewOutbox={() => router.push("/outbox")} styles={styles} />;
  const signalQuality = getSignalQuality(draft.accuracy);
  const validationFields = Object.keys(validationErrors);
  const activeValidationIssue = validationFields.length ? Math.min(validationCursor, validationFields.length - 1) + 1 : 0;
  const isSubmitReady = validationCompleted || Object.keys(validateGuardianReport(draft)).length === 0;
  const aiConfidenceGuidance = aiSuggestion ? getAiConfidenceGuidance(aiSuggestion.confidence, draft) : null;
  const aiConfidenceActionLabel = getAiContextHints(draft).includes("what happened") ? "Add description" : getAiContextHints(draft).includes("where it is") ? "Add location" : "Review rationale";
  const aiConfidencePercent = aiSuggestion ? Math.max(0, Math.min(100, Math.round(aiSuggestion.confidence * 100))) : 0;
  const mapHandoffLabel = Platform.OS === "ios" ? "Choose map service" : "Open Google Maps";
  const pinAccessibilityLabel = [
    pinConfirmed ? "Pin confirmed" : "Pin needs confirmation",
    draft.accuracy ? `Accuracy estimate plus or minus ${Math.round(draft.accuracy)} meters` : "Accuracy estimate unavailable",
    locationCapturedAt ? `Last updated ${new Date(locationCapturedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : null,
    refreshConfirmation ? "Location accuracy refreshed; confirmed pin unchanged" : null,
  ].filter(Boolean).join(". ");

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <KeyboardAvoidingView style={styles.keyboardShell} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={8}>
      <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View><Text style={styles.eyebrow}>COMMUNITY REPORT</Text><Text style={styles.title} accessibilityRole="header">Report a hazard</Text><Text style={styles.subtitle}>Help the right team understand what is happening.</Text></View><Text style={styles.draftState}>{saved ? "Saved locally" : draftRestored ? "Restored draft" : "Draft"}</Text></View>
        <View style={styles.progressRow} accessible accessibilityLabel="Report steps: describe, locate, submit"><View style={styles.progressStep}><View style={styles.progressDotActive}><Text style={styles.progressDotText}>1</Text></View><Text style={styles.progressLabelActive}>Describe</Text></View><View style={styles.progressLine} /><View style={styles.progressStep}><View style={styles.progressDot}><Text style={styles.progressDotTextMuted}>2</Text></View><Text style={styles.progressLabel}>Locate</Text></View><View style={styles.progressLine} /><View style={styles.progressStep}><View style={styles.progressDot}><Text style={styles.progressDotTextMuted}>3</Text></View><Text style={styles.progressLabel}>Submit</Text></View></View>
        <View style={styles.notice}><Text style={styles.noticeIcon}>i</Text><Text style={styles.noticeText}>For immediate danger, call 911. Guardian is for non-emergency concerns.</Text></View>
        {draftRestored && <GuardianStatusCard title="Draft restored" body="Your latest report details were recovered from this device. Review the fields before saving or submitting." badge="Local" tone="neutral" accessibilityLabel="Draft restored from local device storage." />}
        {saveConfirmation && <GuardianStatusCard title="Draft saved on this device" body="Your report details are stored locally and can be continued later. Saving does not submit the report." badge="Saved" tone="success" accessibilityLabel="Draft saved locally. The report was not submitted." />}
        {validationCompleted && <GuardianStatusCard title="Ready to submit" body="All required details are complete. Review the report once more, then submit when you are ready." badge="Ready" tone="success" accessibilityLabel="All required report details are complete. The report is ready to submit."><Pressable onPress={() => { Keyboard.dismiss(); scrollRef.current?.scrollToEnd({ animated: true }); }} style={({ pressed }) => [styles.reviewReportButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Review report before submitting" accessibilityHint="Dismisses the keyboard and moves to the final report actions."><Text style={styles.reviewReportText}>Review report</Text></Pressable></GuardianStatusCard>}
        {validationFields.length > 0 && <GuardianStatusCard title="Review before submitting" body={`Issue ${activeValidationIssue} of ${validationFields.length}. ${validationFields.length} detail${validationFields.length === 1 ? "" : "s"} still need attention. Guardian moved you to the active incomplete field.`} meta={validationFields.length > 1 ? `${validationFields.length - 1} more issue${validationFields.length === 2 ? "" : "s"} remaining after this one.` : "This is the only remaining issue."} badge="Action needed" tone="warning" accessibilityLabel={`Review before submitting. Issue ${activeValidationIssue} of ${validationFields.length}. ${validationFields.length} details still need attention.`}>{validationFields.length > 1 && <Pressable onPress={focusNextValidationIssue} style={({ pressed }) => [styles.validationNextButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Go to next incomplete report field, issue ${activeValidationIssue === validationFields.length ? 1 : activeValidationIssue + 1} of ${validationFields.length}`} accessibilityHint="Moves focus to the next field that needs attention."><Text style={styles.validationNextText}>Next issue · {activeValidationIssue === validationFields.length ? 1 : activeValidationIssue + 1} of {validationFields.length}</Text></Pressable>}</GuardianStatusCard>}
        {queuedReport && <GuardianStatusCard title="Report waiting to send" body={isOnline ? "A previous report is saved and ready to retry." : "It will stay on this device until you are back online."} badge={isOnline ? "Ready" : "Offline"} tone={isOnline ? "warning" : "neutral"} accessibilityLabel={`Report waiting to send. ${isOnline ? "Ready to retry while online." : "Stored on this device until connectivity returns."}`}><Pressable onPress={() => void retryQueuedReport()} disabled={!isOnline || submitting} style={({ pressed }) => [styles.queueButton, (!isOnline || submitting) && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ disabled: !isOnline || submitting, busy: submitting }} accessibilityHint="Retries the saved report without changing its contents."><Text style={styles.queueButtonText}>{isOnline ? "Retry" : "Offline"}</Text></Pressable></GuardianStatusCard>}
        <Text style={styles.fieldLabel} accessibilityRole="header">What are you seeing?</Text>
        <View style={styles.choiceGrid}>{categories.map((category) => <Pressable key={category} onPress={() => update({ category })} style={({ pressed }) => [styles.choice, draft.category === category && styles.choiceActive, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ selected: draft.category === category }}><Text style={[styles.choiceText, draft.category === category && styles.choiceTextActive]}>{category}</Text></Pressable>)}</View>{validationErrors.category && <Text style={styles.validationText} accessibilityLiveRegion="polite">{validationErrors.category}</Text>}{getCategoryGuidance(draft.category) && <View style={styles.categoryGuidance} accessible accessibilityLabel={`AI context tip. ${getCategoryGuidance(draft.category)}`}><Text style={styles.categoryGuidanceTitle}>AI context tip</Text><Text style={styles.categoryGuidanceText}>{getCategoryGuidance(draft.category)}</Text></View>}
        <Text style={styles.fieldLabel} accessibilityRole="header">How urgent is it?</Text>
        <View style={styles.segmented}>{severities.map((severity) => <Pressable key={severity} onPress={() => update({ severity })} style={({ pressed }) => [styles.segment, draft.severity === severity && styles.segmentActive, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ selected: draft.severity === severity }}><Text style={[styles.segmentText, draft.severity === severity && styles.segmentTextActive]}>{severity}</Text></Pressable>)}</View>
        <Text style={styles.fieldLabel} accessibilityRole="header">Describe the concern</Text>
        <TextInput ref={descriptionRef} value={draft.description} onChangeText={(description) => { update({ description }); setAiSuggestion(null); setAiApplied(false); setAiDecision(null); setAiFeedback(null); setAiFeedbackReason(""); setAiFeedbackReasonSaved(false); setAiExplanationOpen(false); }} placeholder="Example: Large pothole is blocking the bike lane" placeholderTextColor={colors.muted} multiline numberOfLines={4} textAlignVertical="top" style={[styles.textInput, validationErrors.description && styles.inputError]} accessibilityLabel="Hazard description" />
        <View style={styles.descriptionMeta}><Text style={styles.descriptionHint}>{draft.description.trim().length >= 3 ? "Add the details that help a reviewer understand the concern." : "Use at least 3 characters and include what is happening."}</Text><Text style={styles.characterCount}>{draft.description.length} characters</Text></View>
        {validationErrors.description && <Text style={styles.validationText} accessibilityLiveRegion="polite">{validationErrors.description}</Text>}
        <Pressable onPress={suggestCategory} disabled={categorize.isPending} style={({ pressed }) => [styles.aiButton, categorize.isPending && { opacity: 0.6 }, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.aiButtonText}>{categorize.isPending ? "Analyzing description…" : "Suggest category with Guardian AI"}</Text></Pressable>
        {aiDecision === "kept" && <GuardianStatusCard title="Your category is unchanged" body="You kept your selected category. AI suggestions never override your choice." badge="Manual" tone="neutral" accessibilityLabel="Your selected category was kept. The AI suggestion did not change the report." />}{aiSuggestion && <View style={styles.aiCard} accessible accessibilityLabel={`Guardian AI suggests ${aiSuggestion.category}. ${Math.round(aiSuggestion.confidence * 100)} percent confidence. ${aiConfidenceGuidance ?? "Review the suggestion carefully."} ${aiApplied ? "Applied after your confirmation." : "Review before applying."}`}><Text style={styles.aiTitle}>Guardian AI suggests: {aiSuggestion.category}</Text><Text style={styles.aiConfidence}>{aiSuggestion.confidence >= 0.8 ? "High confidence" : aiSuggestion.confidence >= 0.55 ? "Moderate confidence" : "Low confidence"} · {aiConfidencePercent}%</Text><View style={styles.aiMeterBlock} accessible accessibilityRole="progressbar" accessibilityLabel={`AI confidence ${aiConfidencePercent} percent`} accessibilityValue={{ min: 0, max: 100, now: aiConfidencePercent }}><View style={styles.aiMeterTrack}><View style={[styles.aiMeterFill, { width: `${aiConfidencePercent}%` }]} /></View><Text style={styles.aiMeterText}>Confidence level: {aiConfidencePercent} of 100</Text></View>{aiConfidenceGuidance && <Text style={styles.aiConfidenceGuidance}>{aiConfidenceGuidance}</Text>}<Pressable onPress={improveAiConfidence} style={({ pressed }) => [styles.aiConfidenceAction, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="What would improve confidence?" accessibilityHint="Moves focus to the report detail that could help Guardian evaluate the suggestion." accessibilityLiveRegion="polite"><Text style={styles.aiConfidenceActionText}>{aiConfidenceActionLabel}</Text></Pressable><Pressable onPress={() => setAiExplanationOpen((open) => !open)} style={({ pressed }) => [styles.aiExplainButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ expanded: aiExplanationOpen }} accessibilityLabel="Why this suggestion?" accessibilityHint="Shows or hides the AI rationale and safety context."><Text style={styles.aiExplainText}>{aiExplanationOpen ? "Hide explanation" : "Why this suggestion?"}</Text></Pressable>{aiExplanationOpen && <Text style={styles.aiBody}>{aiSuggestion.rationale}</Text>}{aiSuggestion.safetyNote ? <Text style={styles.aiSafety}>{aiSuggestion.safetyNote}</Text> : null}<Text style={styles.aiReviewNote}>{aiApplied ? "Applied after your confirmation. You can still choose another category above." : "AI suggestions are guidance only. Review the category before applying."}</Text><View style={styles.aiFeedbackRow}><Text style={styles.aiFeedbackLabel}>Was this useful?</Text><Pressable onPress={() => setAiFeedback("helpful")} style={({ pressed }) => [styles.aiFeedbackButton, aiFeedback === "helpful" && styles.aiFeedbackButtonActive, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ selected: aiFeedback === "helpful" }} accessibilityLabel="AI suggestion was helpful"><Text style={[styles.aiFeedbackText, aiFeedback === "helpful" && styles.aiFeedbackTextActive]}>Helpful</Text></Pressable><Pressable onPress={() => { setAiFeedback("not-helpful"); setAiFeedbackReasonSaved(false); }} style={({ pressed }) => [styles.aiFeedbackButton, aiFeedback === "not-helpful" && styles.aiFeedbackButtonActive, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ selected: aiFeedback === "not-helpful" }} accessibilityLabel="AI suggestion was not helpful"><Text style={[styles.aiFeedbackText, aiFeedback === "not-helpful" && styles.aiFeedbackTextActive]}>Not helpful</Text></Pressable></View>{aiFeedback === "not-helpful" && <View style={styles.aiReasonBox}><Text style={styles.aiReasonHint}>Optional: tell us what seemed wrong. This stays on your device.</Text><View style={styles.aiReasonChips} accessibilityRole="radiogroup" accessibilityLabel="Common reasons for AI feedback">{aiFeedbackReasons.map((reason) => <Pressable key={reason} onPress={() => { setAiFeedbackReason(reason); setAiFeedbackReasonSaved(false); }} style={({ pressed }) => [styles.aiReasonChip, aiFeedbackReason === reason && styles.aiReasonChipActive, pressed && styles.pressed]} accessibilityRole="radio" accessibilityState={{ selected: aiFeedbackReason === reason }} accessibilityLabel={reason}><Text style={[styles.aiReasonChipText, aiFeedbackReason === reason && styles.aiReasonChipTextActive]}>{reason}</Text></Pressable>)}</View><TextInput value={aiFeedbackReason} onChangeText={(reason) => { setAiFeedbackReason(reason); setAiFeedbackReasonSaved(false); }} placeholder="Example: The photo shows flooding, not a pothole" placeholderTextColor={colors.muted} multiline numberOfLines={2} style={styles.aiReasonInput} accessibilityLabel="Optional reason for AI feedback" /><Pressable onPress={() => void saveAiFeedbackReason()} style={({ pressed }) => [styles.aiReasonButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Save optional AI feedback reason" accessibilityHint="Saves the optional reason locally without changing your report."><Text style={styles.aiReasonButtonText}>{aiFeedbackReasonSaved ? "Reason saved" : "Save reason"}</Text></Pressable></View>}{aiFeedback && <Text style={styles.aiFeedbackConfirmation} accessibilityLiveRegion="polite">Feedback saved on this device.</Text>}{!aiApplied && <View style={styles.aiActions}><Pressable onPress={applyAiSuggestion} style={({ pressed }) => [styles.aiApplyButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`Apply AI suggested category ${aiSuggestion.category}`} accessibilityHint="Applies the suggestion to the report category after your review."><Text style={styles.aiApplyText}>Apply suggestion</Text></Pressable><Pressable onPress={keepMyCategory} style={({ pressed }) => [styles.aiKeepButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Keep my selected category" accessibilityHint="Dismisses the suggestion without changing your selected category."><Text style={styles.aiKeepText}>Keep my category</Text></Pressable></View>}</View>}
        <Text style={styles.fieldLabel} accessibilityRole="header">Where is it?</Text>
        <TextInput ref={locationRef} value={draft.location} onChangeText={(location) => update({ location })} placeholder="Intersection, landmark, or address" placeholderTextColor={colors.muted} style={[styles.textInputSingle, validationErrors.location && styles.inputError]} accessibilityLabel="Hazard location" />{validationErrors.location && <Text style={styles.validationText} accessibilityLiveRegion="polite">{validationErrors.location}</Text>}
        <Pressable onPress={captureLocation} style={({ pressed }) => [styles.locationButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Use my current location" accessibilityHint="Adds an approximate device location to this report."><Text style={styles.locationButtonText}>{locating ? "Finding your location…" : draft.latitude ? `Location attached · ±${Math.round(draft.accuracy ?? 0)}m` : "Use my current location"}</Text></Pressable>
        {Platform.OS !== "web" && <GuardianStatusCard title="Location signal" body={`${locationStatusMessage} Signal quality: ${signalQuality.label}. ${signalQuality.detail}`} meta={[draft.accuracy ? `Current accuracy estimate: ±${Math.round(draft.accuracy)}m` : null, locationCapturedAt ? `Last captured ${new Date(locationCapturedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : null].filter(Boolean).join(" · ") || undefined} badge={locationStatus === "ready" ? "Ready" : locationStatus === "unknown" ? "Checking" : "Needs attention"} tone={locationStatus === "ready" ? "success" : locationStatus === "unknown" ? "neutral" : "warning"} accessibilityLabel={`Location signal. ${locationStatusMessage} Signal quality: ${signalQuality.label}.`}><View>{refreshConfirmation && <View style={styles.refreshConfirmation} accessible accessibilityLiveRegion="polite"><Text style={styles.refreshConfirmationText}>Fresh reading saved. Pin unchanged.</Text><Pressable onPress={() => setRefreshConfirmation(false)} style={({ pressed }) => [styles.refreshConfirmationDismiss, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Dismiss location refresh confirmation"><Text style={styles.refreshConfirmationDismissText}>Dismiss</Text></Pressable></View>}<View style={styles.locationStatusActions}>{draft.latitude && <Pressable onPress={() => void refreshLocation()} disabled={refreshingLocation} style={({ pressed }) => [styles.locationStatusButton, refreshingLocation && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Refresh current location accuracy" accessibilityState={{ busy: refreshingLocation }} accessibilityHint="Updates accuracy metadata without changing your report text or map pin."><Text style={styles.locationStatusButtonText}>{refreshingLocation ? "Refreshing…" : "Refresh location"}</Text></Pressable>}<Pressable onPress={() => void refreshLocationStatus()} style={({ pressed }) => [styles.locationStatusButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Refresh location signal status"><Text style={styles.locationStatusButtonText}>Refresh status</Text></Pressable>{(locationStatus === "denied" || locationStatus === "disabled") && <Pressable onPress={() => void Linking.openSettings()} style={({ pressed }) => [styles.locationStatusButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Open device location settings"><Text style={styles.locationStatusButtonText}>Open settings</Text></Pressable>}</View></View></GuardianStatusCard>}
        {draft.latitude && draft.longitude && NativeMapView && NativeMarker && NativeCircle ? <View style={styles.mapCard}><Text style={styles.mapTitle} accessibilityRole="header">Confirm the map pin</Text><Text style={styles.mapBody}>Drag the pin or tap the map to adjust the report location. Accuracy is approximate and can vary indoors or near tall buildings.</Text><View style={styles.mapActions}><View style={styles.mapStyleToggle} accessibilityRole="tablist" accessibilityLabel="Map style"><Pressable onPress={() => changeMapStyle("standard")} style={({ pressed }) => [styles.mapStyleOption, mapStyle === "standard" && styles.mapStyleOptionActive, pressed && styles.pressed]} accessibilityRole="tab" accessibilityState={{ selected: mapStyle === "standard" }}><Text style={[styles.mapStyleText, mapStyle === "standard" && styles.mapStyleTextActive]}>Standard</Text></Pressable><Pressable onPress={() => changeMapStyle("satellite")} style={({ pressed }) => [styles.mapStyleOption, mapStyle === "satellite" && styles.mapStyleOptionActive, pressed && styles.pressed]} accessibilityRole="tab" accessibilityState={{ selected: mapStyle === "satellite" }}><Text style={[styles.mapStyleText, mapStyle === "satellite" && styles.mapStyleTextActive]}>Satellite</Text></Pressable></View><Pressable onPress={recenterMap} style={({ pressed }) => [styles.recenterButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Recenter map on attached location"><Text style={styles.recenterText}>Recenter map</Text></Pressable><Pressable onPress={openInMaps} style={({ pressed }) => [styles.externalMapButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={mapHandoffLabel} accessibilityHint="Asks you to choose or confirm a map service before leaving Guardian and sharing the approximate saved coordinates."><Text style={styles.externalMapButtonText}>{mapHandoffLabel}</Text></Pressable>{!pinConfirmed ? <Pressable onPress={confirmPin} style={({ pressed }) => [styles.confirmPinButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Use this pin for the report" accessibilityHint="Confirms the adjusted map coordinates for this report."><Text style={styles.confirmPinText}>Use this pin</Text></Pressable> : <Text style={styles.confirmedPinText} accessibilityRole="text">Pin confirmed</Text>}</View>{geocoding ? <Text style={styles.geocodingText} accessibilityLiveRegion="polite">Finding a nearby street label…</Text> : addressSuggestion ? <View style={styles.addressSuggestion}><Text style={styles.addressSuggestionLabel}>Nearby label</Text><Text style={styles.addressApproximate}>Approximate guidance from device location services. Verify the label before submitting.</Text><Text style={styles.addressSuggestionText}>{addressSuggestion}</Text>{addressRefreshedAt ? <Text style={styles.addressFreshness}>Last refreshed {new Date(addressRefreshedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}</Text> : <Text style={styles.addressFreshness}>Saved locally</Text>}<View style={styles.addressActions}><Pressable onPress={() => update({ location: addressSuggestion })} style={({ pressed }) => [styles.useAddressButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Use suggested location label"><Text style={styles.useAddressText}>Use this label</Text></Pressable><Pressable onPress={() => { if (draft.latitude && draft.longitude) void lookupAddress(draft.latitude, draft.longitude); }} style={({ pressed }) => [styles.refreshAddressButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Refresh nearby street label"><Text style={styles.refreshAddressText}>Refresh label</Text></Pressable></View></View> : <Pressable onPress={() => { if (draft.latitude && draft.longitude) void lookupAddress(draft.latitude, draft.longitude); }} style={({ pressed }) => [styles.refreshAddressButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Find nearby street label"><Text style={styles.refreshAddressText}>Find nearby label</Text></Pressable>}<View style={styles.pinSummary} accessible accessibilityLabel={pinAccessibilityLabel}><View style={[styles.pinSummaryDot, pinConfirmed ? styles.pinSummaryDotReady : styles.pinSummaryDotReview]} /><View style={styles.pinSummaryCopy}><Text style={styles.pinSummaryTitle}>{pinConfirmed ? "Pin confirmed" : "Review pin before submitting"}</Text><Text style={styles.pinSummaryMeta}>{draft.accuracy ? `Accuracy estimate · ±${Math.round(draft.accuracy)}m` : "Accuracy estimate unavailable"}{locationCapturedAt ? ` · Updated ${new Date(locationCapturedAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : ""}</Text>{refreshConfirmation && <Text style={styles.pinSummaryRefresh}>Signal refreshed · pin unchanged</Text>}</View></View><View style={styles.mapFreshnessLegend} accessible accessibilityLabel="Map freshness guide. Captured means device coordinates were saved. Refreshed means accuracy was updated without moving the confirmed pin. Accepted without map means saved coordinates remain attached even when the preview is unavailable."><Text style={styles.mapFreshnessTitle}>Map freshness</Text><Text style={styles.mapFreshnessItem}>• Captured · device coordinates saved</Text><Text style={styles.mapFreshnessItem}>• Refreshed · accuracy updated, pin unchanged</Text><Text style={styles.mapFreshnessItem}>• Accepted without map · coordinates preserved</Text></View>{mapStatus === "loading" && <View style={styles.mapState} accessible accessibilityLiveRegion="polite" accessibilityLabel="Map loading. Preparing the interactive pin map."><ActivityIndicator size="small" color={colors.primary} /><Text style={styles.mapStateText}>Preparing interactive map…</Text></View>}{mapStatus === "unavailable" && <View style={styles.mapState} accessible accessibilityRole={mapFallbackAcknowledged ? "text" : "alert"} accessibilityLiveRegion="polite" accessibilityLabel={mapFallbackAcknowledged ? "Saved coordinates accepted without map preview. You can submit this report using the saved location." : "Map unavailable. You can still use the saved coordinates without the map or try loading it again."}><Text style={styles.mapStateText}>{mapFallbackAcknowledged ? "Saved coordinates accepted. You can submit without the map preview." : "Map preview is unavailable right now. Your coordinates are still saved locally. You can accept them without the preview or try loading the map again."}</Text>{!mapFallbackAcknowledged && <Pressable onPress={useSavedCoordinatesWithoutMap} style={({ pressed }) => [styles.mapStateButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Use saved coordinates without map" accessibilityHint="Confirms the saved coordinates so you can continue without the map preview."><Text style={styles.mapStateButtonText}>Use saved coordinates</Text></Pressable>}<Pressable onPress={retryMapLoad} style={({ pressed }) => [styles.mapStateButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Try loading the map again"><Text style={styles.mapStateButtonText}>Try again</Text></Pressable></View>}{mapInteractionFeedback && <View style={styles.mapFeedback} accessible accessibilityRole="alert" accessibilityLiveRegion="polite" accessibilityLabel={mapInteractionFeedback}><Text style={styles.mapFeedbackText}>{mapInteractionFeedback}</Text><Pressable onPress={() => { setMapInteractionFeedback(null); if (mapFeedbackTimer.current) clearTimeout(mapFeedbackTimer.current); }} style={({ pressed }) => [styles.mapFeedbackDismiss, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Dismiss map feedback"><Text style={styles.mapFeedbackDismissText}>Dismiss</Text></Pressable></View>}<NativeMapView key={`guardian-map-${mapAttempt}`} ref={mapRef} mapType={mapStyle} style={styles.map} initialRegion={{ latitude: draft.latitude, longitude: draft.longitude, latitudeDelta: 0.006, longitudeDelta: 0.006 }} onMapReady={() => { setMapStatus("ready"); setMapInteractionFeedback("Interactive map ready. Tap or drag the pin to adjust the report location."); }} onPress={(event: { nativeEvent: { coordinate: { latitude: number; longitude: number } } }) => { updateMapPin(event.nativeEvent.coordinate.latitude, event.nativeEvent.coordinate.longitude); }}><NativeCircle center={{ latitude: draft.latitude, longitude: draft.longitude }} radius={Math.max(draft.accuracy ?? 0, 25)} fillColor={colors.primary + "22"} strokeColor={colors.primary + "88"} /><NativeMarker coordinate={{ latitude: draft.latitude, longitude: draft.longitude }} draggable onDragEnd={(event: { nativeEvent: { coordinate: { latitude: number; longitude: number } } }) => { updateMapPin(event.nativeEvent.coordinate.latitude, event.nativeEvent.coordinate.longitude); }} title="Report location" description="Approximate location attached to this report" /></NativeMapView></View> : draft.latitude && draft.longitude ? <GuardianStatusCard title="Saved location preview" body="Your coordinates are attached and ready for submission. The interactive pin map is available in the native app; this web preview stays local and does not send your location anywhere." meta={draft.accuracy ? `Accuracy estimate · ±${Math.round(draft.accuracy)}m` : "Accuracy estimate unavailable"} badge="Attached" tone="success" accessibilityLabel={`Saved location preview. Coordinates are attached locally. ${draft.accuracy ? `Accuracy estimate plus or minus ${Math.round(draft.accuracy)} meters.` : "Accuracy estimate unavailable."}`}><View style={styles.webMapPreview} accessible accessibilityLabel={`Coordinate preview showing latitude ${draft.latitude.toFixed(5)} and longitude ${draft.longitude.toFixed(5)}. The location remains stored locally.`}><View style={styles.webMapGrid}><View style={styles.webMapGridLineHorizontal} /><View style={styles.webMapGridLineVertical} /><View style={styles.webMapPin}><Text style={styles.webMapPinText}>●</Text></View></View><Text style={styles.webMapCoordinates}>{draft.latitude.toFixed(5)}, {draft.longitude.toFixed(5)}</Text><Text style={styles.webMapHint}>Saved coordinates only · no live map tiles loaded</Text><Pressable onPress={openInMaps} style={({ pressed }) => [styles.externalMapButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={mapHandoffLabel} accessibilityHint="Asks you to choose or confirm a map service before leaving Guardian and sharing the approximate saved coordinates."><Text style={styles.externalMapButtonText}>{mapHandoffLabel}</Text></Pressable></View></GuardianStatusCard> : null}
        <View style={styles.locationHint}><Text style={styles.locationPin}>⌖</Text><Text style={styles.locationHintText}>Location is only requested when you tap the button and remains optional.</Text></View>
        {draft.photoUri ? <View style={styles.photoCard}><Image source={{ uri: draft.photoUri }} style={styles.photo} accessibilityLabel="Attached hazard photo" /><View style={styles.photoMeta}><View style={styles.photoMetaCopy}><Text style={styles.photoTitle}>Photo attached</Text><Text style={styles.photoPrivacy}>Optional evidence. It stays with this draft until you submit or remove it.</Text></View><View style={styles.photoActions}><Pressable onPress={showPhotoOptions} style={({ pressed }) => [styles.changePhoto, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Change attached photo" accessibilityHint="Opens camera and library options to replace the current photo."><Text style={styles.changePhotoText}>Change</Text></Pressable><Pressable onPress={removePhoto} style={({ pressed }) => [styles.removePhoto, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Remove attached photo" accessibilityHint="Asks for confirmation before removing the photo from this draft."><Text style={styles.removePhotoText}>Remove</Text></Pressable></View></View></View> : <Pressable onPress={showPhotoOptions} style={({ pressed }) => [styles.photoButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.photoButtonIcon}>＋</Text><View><Text style={styles.photoButtonTitle}>Add a photo</Text><Text style={styles.photoButtonDetail}>Optional evidence for the reviewing team</Text></View></Pressable>}
        <Pressable onPress={openSms} style={({ pressed }) => [styles.smsButton, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.smsButtonText}>Use SMS fallback</Text></Pressable>
        {editingQueuedId && <GuardianStatusCard title="Revising queued report" body="Update the saved location before retrying. Changes remain on this device until you save them." badge="Local edit" tone="neutral" accessibilityLabel="Revising a queued report locally. Save your location changes to return to Outbox." />}
        <Text style={styles.privacy}>Only share details needed to help locate and understand the hazard.</Text>
      </ScrollView>
      <View style={[styles.finalActionBar, { paddingBottom: Math.max(insets.bottom, 8) }]} accessibilityLabel="Report final actions"><Pressable onPress={async () => {     if (editingQueuedId) {
      const queued = queuedReport;
      if (queued) {
        await upsertQueuedReport({ ...queued, draft: { ...queued.draft, ...draft }, nextRetryAt: undefined, lastFailureReason: undefined, autoRetryExhausted: false });
        await appendActivityEvent("location_revised", editingQueuedId);
        await appendActivityEvent("retry_confirmed", editingQueuedId);
      }
      setSaved(true);
      router.replace({ pathname: "/outbox", params: { from: "location-revised" } });
      return;
    }
    await AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    setSaved(true);
    setDraftRestored(false);
    setSaveConfirmation(true); }} style={({ pressed }) => [styles.finalSaveButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Stores this report draft only on this device."><Text style={styles.finalSaveText}>{editingQueuedId ? "Save location changes" : "Save draft"}</Text></Pressable><Pressable onPress={saveDraft} disabled={submitting || createReport.isPending} style={({ pressed }) => [styles.finalSubmitButton, isSubmitReady && styles.finalSubmitButtonReady, (submitting || createReport.isPending) && styles.disabled, pressed && styles.pressed]} accessibilityRole="button" accessibilityState={{ busy: submitting || createReport.isPending, disabled: submitting || createReport.isPending }} accessibilityHint="Sends the report online or saves it to the offline outbox if needed.">{submitting || createReport.isPending ? <View style={styles.submitLoading}><ActivityIndicator size="small" color="#FFFFFF" /><Text style={styles.finalSubmitText}>Submitting…</Text></View> : <Text style={styles.finalSubmitText}>{isSubmitReady ? "Submit report" : "Complete required fields"}</Text>}</Pressable></View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function SubmissionLoading({ styles }: { styles: ReturnType<typeof createStyles> }) {
  return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.loadingState}><View style={styles.loadingOrb}><ActivityIndicator size="large" color="#FFFFFF" /></View><Text style={styles.loadingTitle}>Sending your report</Text><Text style={styles.loadingBody}>Guardian is securely saving the details so the right team can review them.</Text><View style={styles.loadingSteps}><Text style={styles.loadingStep}>✓  Validating report details</Text><Text style={styles.loadingStep}>•  Sending to Guardian</Text><Text style={styles.loadingStepMuted}>○  Creating your receipt</Text></View></View></ScreenContainer>;
}

function Confirmation({ draft, receiptId, outcome, locationAcceptedWithoutMap, onReset, onViewOutbox, styles }: { draft: ReportDraft; receiptId: string | null; outcome: "submitted" | "queued"; locationAcceptedWithoutMap: boolean; onReset: () => void; onViewOutbox: () => void; styles: ReturnType<typeof createStyles> }) {
  const queued = outcome === "queued";
  const reference = queued ? "Waiting to send" : receiptId ? `GDN-${receiptId.slice(-6).toUpperCase()}` : "GDN-PENDING";
  const detail = `${draft.category} · ${draft.severity} priority${draft.photoUri ? " · photo attached" : ""}${draft.latitude ? " · location attached" : ""}`;
  return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.confirmation}><GuardianStatusCard title={queued ? "Report saved offline" : "Report received"} body={queued ? "Your report is safely stored on this device and will be retried when connectivity returns." : "Your report was submitted and saved with a local receipt. Keep this reference if you need to follow up."} meta={`${queued ? "Outbox status" : "Reference"}: ${reference} · ${detail}`} badge={queued ? "Waiting" : "Complete"} tone={queued ? "warning" : "success"} accessibilityLabel={`${queued ? "Report saved offline" : "Report received"}. ${queued ? "Waiting to send." : `Reference ${reference}.`}`}><View>{locationAcceptedWithoutMap && <View style={styles.savedLocationReview} accessible accessibilityRole="text" accessibilityLabel="Location accepted without map preview. Saved coordinates remain attached to this report."><Text style={styles.savedLocationReviewTitle}>Location accepted without map</Text><Text style={styles.savedLocationReviewBody}>Saved coordinates remain attached to this report. The map preview was unavailable, but submission is not affected.</Text></View>}{queued && <Pressable style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]} onPress={onViewOutbox} accessibilityRole="button" accessibilityHint="Opens the offline outbox to review or retry this report."><Text style={styles.secondaryButtonText}>View Outbox</Text></Pressable>}<Pressable style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]} onPress={onReset} accessibilityRole="button"><Text style={styles.primaryButtonText}>Create another report</Text></Pressable></View></GuardianStatusCard></View></ScreenContainer>;
}

function getSignalQuality(accuracy?: number) {
  if (typeof accuracy !== "number") return { label: "Approximate", detail: "Capture a location to estimate signal quality.", tone: "approximate" as const };
  if (accuracy <= 25) return { label: "Strong", detail: "The current estimate is suitable for confirming a nearby hazard location.", tone: "strong" as const };
  if (accuracy <= 75) return { label: "Approximate", detail: "Review the pin and nearby label before submitting.", tone: "approximate" as const };
  return { label: "Weak", detail: "Consider moving outdoors or adjusting the pin manually.", tone: "weak" as const };
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    keyboardShell: { flex: 1 }, finalActionBar: { flexDirection: "row", gap: 9, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.background, paddingTop: 10, paddingBottom: 4 }, finalSaveButton: { flex: 1, minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center", paddingHorizontal: 10 }, finalSaveText: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, finalSubmitButton: { flex: 1.35, minHeight: 48, borderRadius: 14, backgroundColor: colors.muted, alignItems: "center", justifyContent: "center", paddingHorizontal: 10 }, finalSubmitButtonReady: { backgroundColor: colors.primary, elevation: 3 }, finalSubmitText: { color: "#FFFFFF", fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, submitLoading: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }, content: { paddingTop: 22, paddingBottom: 40, gap: 15 }, queueCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#FFF7E8", borderColor: "#F3D49B", borderWidth: 1, borderRadius: 15, padding: 13 }, queueCopy: { flex: 1, gap: 3 }, queueTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, queueBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, queueButton: { backgroundColor: colors.primary, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9 }, queueButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" },     disabled: { opacity: 0.5 }, validationText: { color: colors.error, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800", marginTop: -8 }, validationNextButton: { alignSelf: "flex-start", minHeight: 36, borderRadius: 10, backgroundColor: colors.warning, justifyContent: "center", paddingHorizontal: 12, marginTop: 4 }, validationNextText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, reviewReportButton: { alignSelf: "flex-start", minHeight: 38, borderRadius: 11, backgroundColor: colors.primary, justifyContent: "center", paddingHorizontal: 13, marginTop: 4 }, reviewReportText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, inputError: { borderColor: colors.error, backgroundColor: colors.error + "08" }, descriptionMeta: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 10, marginTop: -8 }, descriptionHint: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, flex: 1 }, characterCount: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" },     header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 0 }, eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1 }, title: { color: colors.foreground, fontSize: scaleTextSize(29, largeText), fontWeight: "800", marginTop: 7 }, subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginTop: 5, maxWidth: 270 }, draftState: { color: colors.success, fontSize: scaleTextSize(12, largeText), fontWeight: "800", marginTop: 4 },     progressRow: { flexDirection: "row", alignItems: "center", paddingVertical: 2 }, progressStep: { alignItems: "center", gap: 4 }, progressDotActive: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" }, progressDot: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, alignItems: "center", justifyContent: "center" }, progressDotText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, progressDotTextMuted: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, progressLabelActive: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, progressLabel: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, progressLine: { flex: 1, height: 1, backgroundColor: colors.border, marginHorizontal: 8, marginBottom: 14 }, notice: { flexDirection: "row", gap: 10, padding: 14, borderRadius: 16, backgroundColor: "#FFF3E8", borderWidth: 1, borderColor: "#F6D0A5", marginBottom: 3 }, noticeIcon: { width: 20, height: 20, borderRadius: 10, textAlign: "center", color: "#FFFFFF", backgroundColor: colors.warning, fontWeight: "900" }, noticeText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(12, largeText), lineHeight: 17 },     fieldLabel: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900", marginTop: 8 }, choiceGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },     choice: { borderWidth: 1, borderColor: colors.border, borderRadius: 14, paddingVertical: 13, paddingHorizontal: 13, minHeight: 46, justifyContent: "center", backgroundColor: colors.surface }, choiceActive: { backgroundColor: colors.primary, borderColor: colors.primary }, choiceText: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "700" }, choiceTextActive: { color: "#FFFFFF" }, categoryGuidance: { backgroundColor: colors.primary + "0D", borderColor: colors.primary + "44", borderWidth: 1, borderRadius: 13, padding: 11, gap: 3, marginTop: -7 }, categoryGuidanceTitle: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 0.7, textTransform: "uppercase" }, categoryGuidanceText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 },     segmented: { flexDirection: "row", borderRadius: 14, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, overflow: "hidden", minHeight: 48 }, segment: { flex: 1, paddingVertical: 12, alignItems: "center" }, segmentActive: { backgroundColor: colors.foreground }, segmentText: { color: colors.muted, fontSize: scaleTextSize(13, largeText), fontWeight: "800" }, segmentTextActive: { color: "#FFFFFF" },     textInput: { minHeight: 116, borderWidth: 1, borderColor: colors.border, borderRadius: 16, padding: 15, color: colors.foreground, backgroundColor: colors.surface, fontSize: scaleTextSize(14, largeText), lineHeight: 21 },     textInputSingle: { minHeight: 54, borderWidth: 1, borderColor: colors.border, borderRadius: 16, paddingHorizontal: 15, color: colors.foreground, backgroundColor: colors.surface, fontSize: scaleTextSize(14, largeText) }, locationButton: { minHeight: 44, borderRadius: 13, borderColor: colors.primary, borderWidth: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary + "12" },     locationButtonText: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    refreshConfirmation: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, borderRadius: 10, backgroundColor: colors.success + "18", paddingHorizontal: 10, paddingVertical: 8 },
    refreshConfirmationText: { flex: 1, color: colors.success, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    refreshConfirmationDismiss: { paddingHorizontal: 5, paddingVertical: 3 },
    refreshConfirmationDismissText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    locationStatusActions: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 2 },
    locationStatusButton: { borderRadius: 9, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 9, paddingVertical: 6 },
    locationStatusButtonText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },     mapCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 12, gap: 7 },
    map: { width: "100%", height: 190, borderRadius: 13, overflow: "hidden" },
    mapActions: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
    mapStyleToggle: { flexDirection: "row", borderRadius: 10, borderWidth: 1, borderColor: colors.border, overflow: "hidden" },
    mapStyleOption: { paddingHorizontal: 9, paddingVertical: 7, backgroundColor: colors.background },
    mapStyleOptionActive: { backgroundColor: colors.foreground },
    mapStyleText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "800" },
    mapStyleTextActive: { color: "#FFFFFF" },
    recenterButton: { borderRadius: 10, borderWidth: 1, borderColor: colors.primary, paddingHorizontal: 10, paddingVertical: 7 },
    recenterText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    confirmPinButton: { borderRadius: 10, backgroundColor: colors.primary, paddingHorizontal: 10, paddingVertical: 7 },
    confirmPinText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    confirmedPinText: { color: colors.success, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    geocodingText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 },
    addressSuggestion: { borderRadius: 12, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, padding: 10, gap: 4 },
    addressActions: { flexDirection: "row", alignItems: "center", gap: 8, flexWrap: "wrap" },
    addressSuggestionLabel: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "900", letterSpacing: 0.8, textTransform: "uppercase" },
    addressSuggestionText: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), lineHeight: 17 },
    addressFreshness: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 },
    addressApproximate: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 },
    useAddressButton: { alignSelf: "flex-start", borderRadius: 9, borderWidth: 1, borderColor: colors.primary, paddingHorizontal: 9, paddingVertical: 6, marginTop: 2 },
    useAddressText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    refreshAddressButton: { alignSelf: "flex-start", borderRadius: 9, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 9, paddingVertical: 6, marginTop: 2 },
    refreshAddressText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    mapTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, webMapPreview: { gap: 6, marginTop: 4 }, webMapGrid: { height: 130, borderRadius: 12, backgroundColor: colors.primary + "0D", borderWidth: 1, borderColor: colors.primary + "44", overflow: "hidden", justifyContent: "center", alignItems: "center" }, webMapGridLineHorizontal: { position: "absolute", left: 0, right: 0, top: "50%", height: 1, backgroundColor: colors.primary + "33" }, webMapGridLineVertical: { position: "absolute", top: 0, bottom: 0, left: "50%", width: 1, backgroundColor: colors.primary + "33" }, webMapPin: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", borderWidth: 4, borderColor: colors.background }, webMapPinText: { color: "#FFFFFF", fontSize: scaleTextSize(13, largeText) }, webMapCoordinates: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, webMapHint: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 }, externalMapButton: { alignSelf: "flex-start", minHeight: 38, borderRadius: 10, backgroundColor: colors.primary, justifyContent: "center", paddingHorizontal: 12, marginTop: 2 }, externalMapButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, mapFreshnessLegend: { borderRadius: 10, backgroundColor: colors.background, borderColor: colors.border, borderWidth: 1, padding: 9, gap: 3 }, mapFreshnessTitle: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, mapFreshnessItem: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 }, pinSummary: { flexDirection: "row", alignItems: "center", gap: 9, backgroundColor: colors.background, borderColor: colors.border, borderWidth: 1, borderRadius: 11, padding: 9 }, pinSummaryDot: { width: 9, height: 9, borderRadius: 5 }, pinSummaryDotReady: { backgroundColor: colors.success }, pinSummaryDotReview: { backgroundColor: colors.warning }, pinSummaryCopy: { flex: 1 }, pinSummaryTitle: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },     pinSummaryMeta: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 14, marginTop: 2 }, pinSummaryRefresh: { color: colors.success, fontSize: scaleTextSize(10, largeText), lineHeight: 14, fontWeight: "900", marginTop: 2 }, mapState: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 9 }, mapStateText: { flex: 1, color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 14, fontWeight: "700" }, mapStateButton: { minHeight: 32, borderRadius: 8, borderWidth: 1, borderColor: colors.primary + "66", paddingHorizontal: 8, alignItems: "center", justifyContent: "center" }, mapStateButtonText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    mapBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, mapFeedback: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.warning + "18", borderColor: colors.warning + "55", borderWidth: 1, borderRadius: 10, padding: 9 }, mapFeedbackText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 15, fontWeight: "800" }, mapFeedbackDismiss: { minHeight: 32, borderRadius: 8, borderWidth: 1, borderColor: colors.warning + "66", paddingHorizontal: 8, alignItems: "center", justifyContent: "center" }, mapFeedbackDismissText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    coordinateCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 13, gap: 5 },
    locationHint: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 4 }, locationPin: { color: colors.primary, fontSize: scaleTextSize(20, largeText) }, locationHintText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, flex: 1 },     photoButton: { minHeight: 72, borderRadius: 16, borderWidth: 1, borderColor: colors.primary + "66", borderStyle: "dashed", backgroundColor: colors.primary + "08", padding: 14, flexDirection: "row", alignItems: "center", gap: 12 }, photoButtonIcon: { color: colors.primary, fontSize: scaleTextSize(24, largeText), fontWeight: "300" }, photoButtonTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "800" }, photoButtonDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: 3 },     photoCard: { borderRadius: 16, overflow: "hidden", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, elevation: 1 }, photo: { width: "100%", height: 170 }, photoMeta: { flexDirection: "row", alignItems: "center", gap: 10, padding: 13 }, photoMetaCopy: { flex: 1, gap: 3 }, photoTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, photoPrivacy: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 }, photoActions: { flexDirection: "row", alignItems: "center", gap: 6 }, changePhoto: { borderRadius: 10, borderWidth: 1, borderColor: colors.primary + "66", paddingHorizontal: 10, paddingVertical: 8 }, changePhotoText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, removePhoto: { borderRadius: 10, borderWidth: 1, borderColor: colors.error + "66", paddingHorizontal: 10, paddingVertical: 8 }, removePhotoText: { color: colors.error, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, aiButton: { minHeight: 42, borderRadius: 12, borderWidth: 1, borderColor: colors.primary, backgroundColor: colors.primary + "10", alignItems: "center", justifyContent: "center" }, aiButtonText: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" }, aiCard: { borderRadius: 14, borderWidth: 1, borderColor: "#B8E3E8", backgroundColor: "#E8F5F7", padding: 12, gap: 4 }, aiTitle: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "900" }, aiConfidence: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, aiMeterBlock: { gap: 4, marginTop: 2 }, aiMeterTrack: { height: 7, borderRadius: 4, backgroundColor: colors.border, overflow: "hidden" }, aiMeterFill: { height: "100%", borderRadius: 4, backgroundColor: colors.primary }, aiMeterText: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, aiConfidenceGuidance: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, fontWeight: "700" }, aiConfidenceAction: { alignSelf: "flex-start", minHeight: 30, borderRadius: 9, borderWidth: 1, borderColor: colors.primary + "66", backgroundColor: colors.surface, justifyContent: "center", paddingHorizontal: 9 }, aiConfidenceActionText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, aiExplainButton: { alignSelf: "flex-start", minHeight: 30, justifyContent: "center" }, aiExplainText: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, aiBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, aiSafety: { color: colors.error, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800" }, aiReviewNote: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, fontWeight: "700" }, aiFeedbackRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 7, marginTop: 3 }, aiFeedbackLabel: { color: colors.muted, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, aiFeedbackButton: { minHeight: 30, borderRadius: 9, borderWidth: 1, borderColor: colors.border, justifyContent: "center", paddingHorizontal: 9 }, aiFeedbackButtonActive: { backgroundColor: colors.primary, borderColor: colors.primary }, aiFeedbackText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, aiFeedbackTextActive: { color: "#FFFFFF" }, aiFeedbackConfirmation: { color: colors.success, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, aiReasonBox: { gap: 6, marginTop: 3 }, aiReasonChips: { flexDirection: "row", flexWrap: "wrap", gap: 6 }, aiReasonChip: { minHeight: 30, borderRadius: 9, borderWidth: 1, borderColor: colors.border, justifyContent: "center", paddingHorizontal: 9 }, aiReasonChipActive: { backgroundColor: colors.primary, borderColor: colors.primary }, aiReasonChipText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "800" }, aiReasonChipTextActive: { color: "#FFFFFF" }, aiReasonHint: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15 }, aiReasonInput: { minHeight: 58, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, color: colors.foreground, backgroundColor: colors.surface, fontSize: scaleTextSize(11, largeText), lineHeight: 16 }, aiReasonButton: { alignSelf: "flex-start", minHeight: 32, borderRadius: 9, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.primary, justifyContent: "center", paddingHorizontal: 10 }, aiReasonButtonText: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" }, aiActions: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 8, marginTop: 4 }, aiApplyButton: { minHeight: 36, borderRadius: 10, backgroundColor: colors.primary, justifyContent: "center", paddingHorizontal: 12 }, aiApplyText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, aiKeepButton: { minHeight: 36, borderRadius: 10, borderWidth: 1, borderColor: colors.border, justifyContent: "center", paddingHorizontal: 12 }, aiKeepText: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, loadingState: { flex: 1, justifyContent: "center", alignItems: "center", paddingBottom: 70 }, loadingOrb: { width: 88, height: 88, borderRadius: 44, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", marginBottom: 22 }, loadingTitle: { color: colors.foreground, fontSize: scaleTextSize(24, largeText), fontWeight: "800" }, loadingBody: { color: colors.muted, fontSize: scaleTextSize(14, largeText), lineHeight: 21, textAlign: "center", maxWidth: 300, marginTop: 9 }, loadingSteps: { alignSelf: "stretch", marginTop: 25, gap: 10, padding: 16, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }, loadingStep: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "800" }, loadingStepMuted: { color: colors.muted, fontSize: scaleTextSize(12, largeText), fontWeight: "700" },     primaryButton: { minHeight: 56, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary, marginTop: 5, elevation: 2 }, primaryButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(14, largeText), fontWeight: "900" },     secondaryButton: { minHeight: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, marginTop: 7 }, secondaryButtonText: { color: colors.foreground, fontSize: scaleTextSize(13, largeText), fontWeight: "800" }, smsButton: { alignItems: "center", paddingVertical: 9 }, smsButtonText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "800" }, privacy: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, textAlign: "center", paddingHorizontal: 16 },     savedLocationReview: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 12, padding: 10, marginBottom: 10 }, savedLocationReviewTitle: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "900" }, savedLocationReviewBody: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 14, marginTop: 3 },
    confirmation: { flex: 1, justifyContent: "center", alignItems: "center", paddingBottom: 50 },  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
