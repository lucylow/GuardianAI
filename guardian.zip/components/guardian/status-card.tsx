import { View, Text, StyleSheet } from "react-native";
import type { ReactNode } from "react";

import { useColors } from "@/hooks/use-colors";

type StatusTone = "neutral" | "success" | "warning" | "error";

export interface GuardianStatusCardProps {
  title: string;
  body?: string;
  meta?: string;
  badge?: string;
  tone?: StatusTone;
  children?: ReactNode;
  accessibilityLabel?: string;
}

/**
 * Shared status presentation for report recovery, location, and submission states.
 * The card owns visual hierarchy while actions remain caller-owned children so each
 * screen can preserve its native behavior and accessibility semantics.
 */
export function GuardianStatusCard({
  title,
  body,
  meta,
  badge,
  tone = "neutral",
  children,
  accessibilityLabel,
}: GuardianStatusCardProps) {
  const colors = useColors();
  const toneColor = {
    neutral: colors.primary,
    success: colors.success,
    warning: colors.warning,
    error: colors.error,
  }[tone];

  return (
    <View
      style={[styles.card, { borderColor: colors.border, borderLeftColor: toneColor, backgroundColor: colors.surface }]}
      accessible={Boolean(accessibilityLabel)}
      accessibilityLabel={accessibilityLabel}
    >
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]} accessibilityRole="header">
          {title}
        </Text>
        {badge ? (
          <Text style={[styles.badge, { color: toneColor, borderColor: toneColor }]}>
            {badge}
          </Text>
        ) : null}
      </View>
      {body ? <Text style={[styles.body, { color: colors.muted }]}>{body}</Text> : null}
      {meta ? <Text style={[styles.meta, { color: colors.muted }]}>{meta}</Text> : null}
      {children ? <View style={styles.actions}>{children}</View> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 3,
    borderRadius: 18,
    padding: 16,
    gap: 9,
    elevation: 1,
  },
  header: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  title: {
    flex: 1,
    fontSize: 16,
    fontWeight: "700",
  },
  badge: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 999,
    fontSize: 11,
    fontWeight: "700",
    overflow: "hidden",
    paddingHorizontal: 8,
    paddingVertical: 3,
    textTransform: "uppercase",
  },
  body: {
    fontSize: 13,
    lineHeight: 19,
  },
  meta: {
    fontSize: 12,
    lineHeight: 17,
  },
  actions: {
    gap: 9,
    marginTop: 5,
  },
});

type GuardianStatusTone = StatusTone;
export type { GuardianStatusTone };
