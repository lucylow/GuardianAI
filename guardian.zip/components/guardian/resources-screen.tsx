import { useMemo } from "react";
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

const resources = [
  { title: "Emergency services", detail: "Immediate danger, fire, crime, or medical emergency", action: "Call 911", url: "tel:911", tone: "emergency" as const },
  { title: "City services", detail: "Non-emergency reports and neighborhood requests", action: "Open indy.gov", url: "https://www.indy.gov/", tone: "primary" as const },
  { title: "Weather and shelter", detail: "Official warnings, warming centers, and severe weather support", action: "View resources", url: "https://www.weather.gov/", tone: "warning" as const },
  { title: "Accessibility help", detail: "Services and support for residents with access needs", action: "Find support", url: "https://www.indy.gov/activity/disability-services", tone: "success" as const },
];

export function ResourcesScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>TRUSTED SUPPORT</Text>
        <Text style={styles.title}>Resources</Text>
        <Text style={styles.subtitle}>Keep these official pathways close when you need help or information.</Text>
        <View style={styles.safetyCard}><Text style={styles.safetyTitle}>Guardian is not dispatch.</Text><Text style={styles.safetyBody}>For immediate danger, use the emergency button or call 911 directly.</Text></View>
        {resources.map((resource) => (
          <Pressable key={resource.title} onPress={() => Linking.openURL(resource.url)} style={({ pressed }) => [styles.resourceCard, pressed && styles.pressed]} accessibilityRole="link" accessibilityLabel={`${resource.title}. ${resource.detail}. ${resource.action}`}>
            <View style={[styles.resourceIcon, { backgroundColor: resource.tone === "emergency" ? colors.error : resource.tone === "warning" ? colors.warning : resource.tone === "success" ? colors.success : colors.primary }]}><Text style={styles.resourceIconText}>{resource.tone === "emergency" ? "!" : "⌖"}</Text></View>
            <View style={styles.resourceCopy}><Text style={styles.resourceTitle}>{resource.title}</Text><Text style={styles.resourceDetail}>{resource.detail}</Text><Text style={styles.resourceAction}>{resource.action}  ›</Text></View>
          </Pressable>
        ))}
        <View style={styles.smsCard}><Text style={styles.smsTitle}>No internet? Use SMS.</Text><Text style={styles.smsBody}>From your phone&apos;s messaging app, send a short description and landmark to your saved Guardian contact.</Text><Text style={styles.smsExample}>“FLOOD at 5th and Meridian”</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 12 },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "800", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginBottom: 8 },
    safetyCard: { backgroundColor: colors.foreground, borderRadius: 17, padding: 16, marginBottom: 3 },
    safetyTitle: { color: "#FFFFFF", fontSize: scaleTextSize(15, largeText), fontWeight: "900" },
    safetyBody: { color: "#C9D6E3", fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 5 },
    resourceCard: { flexDirection: "row", alignItems: "center", gap: 13, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 15 },
    resourceIcon: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
    resourceIconText: { color: "#FFFFFF", fontSize: scaleTextSize(22, largeText), fontWeight: "900" },
    resourceCopy: { flex: 1 },
    resourceTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "800" },
    resourceDetail: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 4 },
    resourceAction: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900", marginTop: 7 },
    smsCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 17, padding: 16, marginTop: 3 },
    smsTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "800" },
    smsBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 5 },
    smsExample: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900", marginTop: 10 },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
