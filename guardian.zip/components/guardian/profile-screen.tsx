import AsyncStorage from "@react-native-async-storage/async-storage";
import { Link, useFocusEffect } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/hooks/use-auth";
import { startOAuthLogin } from "@/constants/oauth";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

export function ProfileScreen() {
  const colors = useColors();
  const { largeText, setLargeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  const [notifications, setNotifications] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [hapticsEnabled, setHapticsEnabled] = useState(true);
  const [announceBatchSteps, setAnnounceBatchSteps] = useState(true);
  const [largeTextConfirmation, setLargeTextConfirmation] = useState<string | null>(null);
  const { user, loading: authLoading, isAuthenticated, refresh, logout } = useAuth();

  useFocusEffect(useMemo(() => () => { refresh(); }, [refresh]));

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem("guardian.setting.highContrast"),
      AsyncStorage.getItem("guardian.setting.largeText"),
      AsyncStorage.getItem("guardian.setting.notifications"),
      AsyncStorage.getItem("guardian.setting.hapticsEnabled"),
      AsyncStorage.getItem("guardian.setting.batchAnnounceSteps"),
    ]).then(([storedHighContrast, storedLargeText, storedNotifications, storedHaptics, storedAnnounceBatchSteps]) => {
      if (storedHighContrast === "true" || storedHighContrast === "false") setHighContrast(storedHighContrast === "true");
      if (storedLargeText === "true" || storedLargeText === "false") setLargeText(storedLargeText === "true");
      if (storedNotifications === "true" || storedNotifications === "false") setNotifications(storedNotifications === "true");
      if (storedHaptics === "true" || storedHaptics === "false") setHapticsEnabled(storedHaptics === "true");
      if (storedAnnounceBatchSteps === "true" || storedAnnounceBatchSteps === "false") setAnnounceBatchSteps(storedAnnounceBatchSteps === "true");
    }).catch(() => undefined);
  }, [setLargeText]);

  useEffect(() => {
    if (!largeTextConfirmation) return;
    const timeout = setTimeout(() => setLargeTextConfirmation(null), 5000);
    return () => clearTimeout(timeout);
  }, [largeTextConfirmation]);

  const updateLargeText = (enabled: boolean) => {
    setLargeText(enabled);
    setLargeTextConfirmation(enabled ? "Larger text is on. Reading size increased across Guardian." : "Larger text is off. Guardian returned to the standard reading size.");
  };

  const updateHighContrast = (enabled: boolean) => {
    setHighContrast(enabled);
    saveSetting("highContrast", enabled);
    setLargeTextConfirmation(enabled ? "High-contrast emergency mode is on. Urgent actions now use stronger contrast." : "High-contrast emergency mode is off. Standard contrast has been restored.");
  };

  const updateNotifications = (enabled: boolean) => {
    setNotifications(enabled);
    saveSetting("notifications", enabled);
    setLargeTextConfirmation(enabled ? "Safety alerts are on. Guardian can show weather, city, and neighborhood updates." : "Safety alerts are off. Guardian will not show alert updates in this setting.");
  };

  const updateHaptics = (enabled: boolean) => {
    setHapticsEnabled(enabled);
    saveSetting("hapticsEnabled", enabled);
    setLargeTextConfirmation(enabled ? "Haptic feedback is on. Supported devices will provide subtle confirmation feedback." : "Haptic feedback is off. Guardian will use visual confirmations only.");
  };

  const updateBatchAnnouncements = (enabled: boolean) => {
    setAnnounceBatchSteps(enabled);
    saveSetting("batchAnnounceSteps", enabled);
    setLargeTextConfirmation(enabled ? "Bulk retry step announcements are on. Guardian will announce each completed retry." : "Bulk retry step announcements are off. Guardian will still announce batch start, completion, failures, and cancellation.");
  };

  const signIn = async () => {
    await startOAuthLogin();
  };

  const signOut = () => {
    Alert.alert("Sign out of Guardian?", "Your local drafts will stay on this device.", [
      { text: "Cancel", style: "cancel" },
      { text: "Sign out", style: "destructive", onPress: () => { logout(); } },
    ]);
  };

  const saveSetting = (key: string, value: boolean) => {
    AsyncStorage.setItem(`guardian.setting.${key}`, String(value)).catch(() => undefined);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>YOUR GUARDIAN SETTINGS</Text>
        <Text style={styles.title}>Profile</Text>
        <Text style={styles.subtitle}>Make Guardian work the way you need it to.</Text>
        <View style={styles.profileCard}><View style={styles.avatar}><Text style={styles.avatarText}>{isAuthenticated ? (user?.name?.slice(0, 1).toUpperCase() ?? "G") : "G"}</Text></View><View style={styles.profileCopy}><Text style={styles.profileName}>{authLoading ? "Checking account…" : isAuthenticated ? (user?.name ?? "Guardian member") : "Guest mode"}</Text><Text style={styles.profileDetail}>{isAuthenticated ? (user?.email ?? "Signed in") : "Your drafts stay on this device"}</Text></View>{!isAuthenticated && <Pressable onPress={signIn} style={({ pressed }) => [styles.signInSmall, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Opens Guardian sign-in."><Text style={styles.signInSmallText}>Sign in</Text></Pressable>}</View>
        <Text style={styles.sectionTitle}>Your activity</Text>
        <Link href="/report-history" asChild><Pressable style={({ pressed }) => [styles.historyCard, pressed && styles.historyCardPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Opens your submitted report history."><View style={styles.historyIcon}><Text style={styles.historyIconText}>✓</Text></View><View style={styles.historyCopy}><Text style={styles.historyTitle}>Report history</Text><Text style={styles.historyDetail}>Track submitted hazards and status updates</Text></View><Text style={styles.historyChevron}>›</Text></Pressable></Link>
        <Text style={styles.sectionTitle}>Accessibility</Text>
        <View style={styles.settingsCard}>
          <SettingRow title="High-contrast emergency mode" detail="Stronger contrast for urgent actions" status={highContrast ? "On" : "Off"} value={highContrast} onValueChange={updateHighContrast} styles={styles} colors={colors} /><SettingRow title="Larger text" detail="Increase reading size across the app" status={largeText ? "On" : "Off"} value={largeText} onValueChange={updateLargeText} styles={styles} colors={colors} last /></View>{largeTextConfirmation && <View style={styles.confirmationBanner} accessible accessibilityRole="alert" accessibilityLiveRegion="polite" accessibilityLabel={largeTextConfirmation}><Text style={styles.confirmationText}>{largeTextConfirmation}</Text><Pressable onPress={() => setLargeTextConfirmation(null)} style={({ pressed }) => [styles.confirmationDismiss, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Dismiss preference confirmation"><Text style={styles.confirmationDismissText}>Dismiss</Text></Pressable></View>}
        <Text style={styles.sectionTitle}>Feedback</Text>
        <View style={styles.settingsCard}><SettingRow title="Haptic feedback" detail="Vibrate for successful actions on supported devices" status={hapticsEnabled ? "On" : "Off"} value={hapticsEnabled} onValueChange={updateHaptics} styles={styles} colors={colors} /><SettingRow title="Bulk retry step announcements" detail="Announce each completed report during bulk retry" status={announceBatchSteps ? "On" : "Off"} value={announceBatchSteps} onValueChange={updateBatchAnnouncements} styles={styles} colors={colors} last /></View><View style={styles.announcementExampleCard} accessible accessibilityLabel="Bulk retry announcement examples. On announces each completed report. Off announces only batch start, completion, failures, and cancellation."><Text style={styles.announcementExampleTitle}>What changes?</Text><View style={styles.announcementExampleRow}><Text style={styles.announcementExampleBadge}>On</Text><Text style={styles.announcementExampleText}>Announces each completed report during a bulk retry.</Text></View><View style={styles.announcementExampleRow}><Text style={styles.announcementExampleBadge}>Off</Text><Text style={styles.announcementExampleText}>Announces the batch start, completion, failures, and cancellation only.</Text></View></View><Text style={styles.preferencePrivacyNote} accessibilityLabel="Feedback preferences are device-only. Guardian does not send activity data for these settings.">Device-only preferences. Guardian does not send activity data for feedback settings.</Text>
        <Text style={styles.sectionTitle}>Notifications</Text>
        <View style={styles.settingsCard}><SettingRow title="Safety alerts" detail="Weather, city, and neighborhood updates" status={notifications ? "On" : "Off"} value={notifications} onValueChange={updateNotifications} styles={styles} colors={colors} last /></View>
        {isAuthenticated && <Pressable onPress={signOut} style={({ pressed }) => [styles.signOutButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Signs out while keeping local drafts on this device."><Text style={styles.signOutText}>Sign out of Guardian</Text></Pressable>}
        <Text style={styles.sectionTitle}>Support Guardian</Text>
        <Link href="/support" asChild><Pressable style={({ pressed }) => [styles.supportCard, pressed && styles.supportCardPressed, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Opens Guardian support options."><View style={styles.supportIcon}><Text style={styles.supportIconText}>♡</Text></View><View style={styles.supportCopy}><Text style={styles.supportTitle}>Help keep safety tools free</Text><Text style={styles.supportDetail}>Optional supporter plans and one-time donations</Text></View><Text style={styles.historyChevron}>›</Text></Pressable></Link>
        <Text style={styles.sectionTitle}>About Guardian</Text>
        <View style={styles.infoCard}><Text style={styles.infoTitle}>A civic safety companion</Text><Text style={styles.infoBody}>Guardian helps you find trusted information and report non-emergency hazards. It does not replace 911 or official dispatch.</Text><Link href="/privacy" asChild><Pressable style={({ pressed }) => [styles.linkButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityHint="Opens privacy and local data choices."><Text style={styles.linkText}>Privacy and data choices  ›</Text></Pressable></Link></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function SettingRow({ title, detail, status, value, onValueChange, styles, colors, last = false }: { title: string; detail: string; status?: string; value: boolean; onValueChange: (value: boolean) => void; styles: ReturnType<typeof createStyles>; colors: ReturnType<typeof useColors>; last?: boolean }) {
  return <View style={[styles.settingRow, !last && styles.settingBorder]}><View style={styles.settingCopy}><Text style={styles.settingTitle}>{title}</Text><Text style={styles.settingDetail}>{detail}</Text></View>{status && <Text style={[styles.settingStatus, value ? styles.settingStatusOn : styles.settingStatusOff]} accessibilityLabel={`${title}: ${status}`}>{status}</Text>}<Switch value={value} onValueChange={onValueChange} trackColor={{ false: colors.border, true: colors.primary }} thumbColor="#FFFFFF" accessibilityLabel={`${title}, ${value ? "on" : "off"}`} accessibilityState={{ checked: value }} /></View>;
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 22, paddingBottom: 38, gap: 14 },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "800", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginBottom: 8 },
    profileCard: { backgroundColor: colors.foreground, borderRadius: 20, padding: 18, minHeight: 82, flexDirection: "row", alignItems: "center", gap: 13, marginBottom: 7, elevation: 3 },
    avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
    avatarText: { color: "#FFFFFF", fontSize: scaleTextSize(20, largeText), fontWeight: "900" },
    profileName: { color: "#FFFFFF", fontSize: scaleTextSize(16, largeText), fontWeight: "800" },
    profileDetail: { color: "#C9D6E3", fontSize: scaleTextSize(12, largeText), marginTop: 4 },
    profileCopy: { flex: 1 },
    signInSmall: { borderRadius: 10, backgroundColor: colors.primary, paddingHorizontal: 10, paddingVertical: 8 },
    signInSmallText: { color: "#FFFFFF", fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    signOutButton: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.error + "55", backgroundColor: colors.error + "0D", alignItems: "center", justifyContent: "center", marginTop: 5 },
    signOutText: { color: colors.error, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    sectionTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900", marginTop: 6 },
    settingsCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, paddingHorizontal: 16, elevation: 1 },
    supportCard: { backgroundColor: "#F0ECFF", borderColor: "#D9D0FF", borderWidth: 1, borderRadius: 18, padding: 16, minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12, elevation: 1 },
    supportCardPressed: { backgroundColor: "#E8E0FF", borderColor: colors.primary },
    supportIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
    supportIconText: { color: colors.primary, fontSize: scaleTextSize(20, largeText), fontWeight: "900" },
    supportCopy: { flex: 1 },
    supportTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    supportDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: 4 },
    historyCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 16, minHeight: 72, flexDirection: "row", alignItems: "center", gap: 12, elevation: 1 },
    historyCardPressed: { backgroundColor: colors.primary + "12", borderColor: colors.primary },
    historyIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#E8F5F7", alignItems: "center", justifyContent: "center" },
    historyIconText: { color: colors.primary, fontSize: scaleTextSize(18, largeText), fontWeight: "900" },
    historyCopy: { flex: 1 },
    historyTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    historyDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), marginTop: 4 },
    historyChevron: { color: colors.primary, fontSize: scaleTextSize(24, largeText), fontWeight: "300" },
    settingRow: { minHeight: 74, flexDirection: "row", alignItems: "center", gap: 10 },
    settingBorder: { borderBottomColor: colors.border, borderBottomWidth: 1 },
    settingCopy: { flex: 1 },
    settingTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    settingDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, marginTop: 4 },
    settingStatus: { fontSize: scaleTextSize(10, largeText), fontWeight: "900", minWidth: 22, textAlign: "right" },
    settingStatusOn: { color: colors.primary },
    settingStatusOff: { color: colors.muted },
    announcementExampleCard: { backgroundColor: colors.primary + "0B", borderColor: colors.primary + "33", borderWidth: 1, borderRadius: 14, padding: 12, gap: 9 },
    announcementExampleTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    announcementExampleRow: { flexDirection: "row", alignItems: "flex-start", gap: 9 },
    announcementExampleBadge: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "900", minWidth: 24 },
    announcementExampleText: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16, flex: 1 },
    preferencePrivacyNote: { color: colors.muted, fontSize: scaleTextSize(10, largeText), lineHeight: 15, marginTop: -7, paddingHorizontal: 4 },
    confirmationBanner: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.success + "18", borderColor: colors.success + "55", borderWidth: 1, borderRadius: 12, padding: 10 },
    confirmationText: { flex: 1, color: colors.foreground, fontSize: scaleTextSize(11, largeText), lineHeight: 16, fontWeight: "800" },
    confirmationDismiss: { minHeight: 34, borderRadius: 8, borderWidth: 1, borderColor: colors.success + "66", paddingHorizontal: 9, alignItems: "center", justifyContent: "center" },
    confirmationDismissText: { color: colors.foreground, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    infoCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 18, padding: 17 },
    infoTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    infoBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 18, marginTop: 5 },
    linkButton: { paddingTop: 12 },
    linkText: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
