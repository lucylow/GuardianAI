import MapView, { Circle, Marker } from "react-native-maps";

export const NativeMapView = MapView;
export const NativeMarker = Marker;
export const NativeCircle = Circle;
