import { Link } from "expo-router";
import { useMemo } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";

const alerts = [
  { title: "Heat advisory", source: "National Weather Service", time: "Updated 18 min ago", severity: "Caution", body: "Limit prolonged outdoor activity and check on neighbors who may need support.", tone: "warning" as const },
  { title: "Road work near Broad Ripple", source: "Indy Public Works", time: "Updated 42 min ago", severity: "Moderate", body: "Use alternate routes near Broad Ripple Avenue through this evening.", tone: "primary" as const },
  { title: "School-zone reminder", source: "Indianapolis Public Safety", time: "Today · 2:30 PM", severity: "Info", body: "Slow down and watch for pedestrians during afternoon dismissal.", tone: "success" as const },
];

export function AlertsScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);
  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>OFFICIAL UPDATES</Text>
        <Text style={styles.title}>Safety alerts</Text>
        <Text style={styles.subtitle}>Current information from trusted civic and weather sources.</Text>
        <View style={styles.filterRow}><Text style={styles.filterActive}>Nearby</Text><Text style={styles.filter}>All Indianapolis</Text><Text style={styles.updated}>Freshness shown on every alert</Text></View>
        {alerts.map((alert) => (
          <Link key={alert.title} href={{ pathname: "/alert-detail", params: { title: alert.title, body: alert.body, source: alert.source, time: alert.time } }} asChild>
            <Pressable style={({ pressed }) => [styles.card, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel={`${alert.title}. ${alert.severity}. ${alert.body}`}>
              <View style={styles.cardTop}><View style={[styles.statusDot, { backgroundColor: alert.tone === "warning" ? colors.warning : alert.tone === "success" ? colors.success : colors.primary }]} /><Text style={styles.severity}>{alert.severity}</Text><Text style={styles.time}>{alert.time}</Text></View>
              <Text style={styles.cardTitle}>{alert.title}</Text>
              <Text style={styles.cardBody}>{alert.body}</Text>
              <View style={styles.cardFooter}><Text style={styles.source}>{alert.source}</Text><Text style={styles.chevron}>›</Text></View>
            </Pressable>
          </Link>
        ))}
        <View style={styles.footerCard}><Text style={styles.footerTitle}>Want fewer notifications?</Text><Text style={styles.footerBody}>Choose alert categories and quiet hours in Profile.</Text><Link href="/profile" asChild><Pressable style={({ pressed }) => [styles.settingsButton, pressed && styles.pressed]}><Text style={styles.settingsText}>Manage preferences</Text></Pressable></Link></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 12 },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1 },
    title: { color: colors.foreground, fontSize: scaleTextSize(30, largeText), fontWeight: "800", marginTop: 2 },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 18, marginBottom: 8 },
    filterRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 4 },
    filterActive: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    filter: { color: colors.muted, fontSize: scaleTextSize(12, largeText), fontWeight: "700" },
    updated: { color: colors.muted, fontSize: scaleTextSize(10, largeText), marginLeft: "auto", flexShrink: 1, textAlign: "right" },
    card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 18, padding: 16, gap: 8 },
    cardTop: { flexDirection: "row", alignItems: "center", gap: 7 },
    statusDot: { width: 9, height: 9, borderRadius: 5 },
    severity: { color: colors.foreground, fontSize: scaleTextSize(11, largeText), fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.5 },
    time: { color: colors.muted, fontSize: scaleTextSize(10, largeText), marginLeft: "auto" },
    cardTitle: { color: colors.foreground, fontSize: scaleTextSize(17, largeText), fontWeight: "800", marginTop: 3 },
    cardBody: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 19 },
    cardFooter: { flexDirection: "row", alignItems: "center", marginTop: 3 },
    source: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", flex: 1 },
    chevron: { color: colors.primary, fontSize: scaleTextSize(25, largeText), fontWeight: "300" },
    footerCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 18, padding: 16, marginTop: 4 },
    footerTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    footerBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 17, marginTop: 4 },
    settingsButton: { marginTop: 10, alignSelf: "flex-start", paddingVertical: 7 },
    settingsText: { color: colors.primary, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
