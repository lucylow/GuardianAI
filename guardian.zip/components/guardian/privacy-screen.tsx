import { Link, useFocusEffect } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { GuardianStatusCard } from "@/components/guardian/status-card";
import { useColors } from "@/hooks/use-colors";
import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";
import { clearBatchSummary, readActivityEvents, readBatchSummary, setBatchSummary, type GuardianBatchSummary } from "@/lib/guardian-queue";

export function PrivacyScreen() {
  const colors = useColors();
  const { largeText } = useAccessibilityPreferences();
  const styles = createStyles(colors, largeText);
  const [summary, setSummary] = useState<GuardianBatchSummary | null>(null);
  const [activityCount, setActivityCount] = useState(0);
  const [recentlyCleared, setRecentlyCleared] = useState<GuardianBatchSummary | null>(null);
  const [undoExpiresAt, setUndoExpiresAt] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());

  const refresh = useCallback(() => {
    Promise.all([readBatchSummary(), readActivityEvents()]).then(([storedSummary, events]) => {
      setSummary(storedSummary);
      setActivityCount(events.length);
    }).catch(() => {
      setSummary(null);
      setActivityCount(0);
    });
  }, []);

  useFocusEffect(useCallback(() => {
    refresh();
  }, [refresh]));

  useEffect(() => {
    if (!recentlyCleared) return undefined;
    const interval = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(interval);
  }, [recentlyCleared]);

  const clearSummary = () => {
    if (!summary) return;
    Alert.alert("Clear recent batch summary?", "This removes only the local summary. Queued reports, drafts, receipts, and activity history will stay unchanged.", [
      { text: "Keep summary", style: "cancel" },
      { text: "Clear summary", style: "destructive", onPress: async () => { await clearBatchSummary(); setRecentlyCleared(summary); setUndoExpiresAt(Date.now() + 6000); setSummary(null); } },
    ]);
  };

  const undoClear = async () => {
    if (!recentlyCleared) return;
    await setBatchSummary(recentlyCleared);
    setSummary(recentlyCleared);
    setRecentlyCleared(null);
    setUndoExpiresAt(null);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Link href="/(tabs)/profile" asChild><Pressable style={({ pressed }) => [styles.back, pressed && styles.pressed]} accessibilityRole="button"><Text style={styles.backText}>‹  Profile</Text></Pressable></Link>
        <Text style={styles.eyebrow}>PRIVACY AND DATA CHOICES</Text>
        <Text style={styles.title}>Your data, your control</Text>
        <Text style={styles.subtitle}>Guardian keeps safety work local until you choose to submit it. These controls explain and manage what stays on this device.</Text>

        <GuardianStatusCard title="Local-first boundary" body="Queued reports, incomplete drafts, and the recent batch summary stay in local app storage. Activity history stores safe event labels and timestamps, not report descriptions or locations." badge="On device" tone="neutral" accessibilityLabel="Local-first boundary. Safety drafts and queued reports remain on this device." />

        <Text style={styles.sectionTitle}>Local records</Text>
        <View style={styles.recordsCard}>
          <View style={styles.recordRow}><View style={styles.recordCopy}><Text style={styles.recordTitle}>Outbox activity history</Text><Text style={styles.recordDetail}>{activityCount} safe event{activityCount === 1 ? "" : "s"} stored locally</Text></View><Text style={styles.recordStatus}>Local</Text></View>
          <View style={styles.divider} />
          <View style={styles.recordRow}><View style={styles.recordCopy}><Text style={styles.recordTitle}>Recent batch retry summary</Text><Text style={styles.recordDetail}>{summary ? `${summary.submitted} submitted · ${summary.failed} failed · ${summary.remaining} remaining` : "No summary stored"}</Text></View>{summary && <Pressable onPress={clearSummary} style={({ pressed }) => [styles.clearButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Clear recent batch retry summary"><Text style={styles.clearText}>Clear</Text></Pressable>}</View>
        </View>

        {recentlyCleared && <GuardianStatusCard title="Summary cleared" body="Only the recent batch summary was removed." meta={`Undo available for ${Math.max(0, Math.ceil(((undoExpiresAt ?? now) - now) / 1000))} seconds`} badge="Undo" tone="warning" accessibilityLabel={`Summary cleared. Undo available for ${Math.max(0, Math.ceil(((undoExpiresAt ?? now) - now) / 1000))} seconds.`}><Pressable onPress={() => void undoClear()} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]} accessibilityRole="button" accessibilityLabel="Restore cleared summary"><Text style={styles.undoButtonText}>Undo</Text></Pressable></GuardianStatusCard>}

        <View style={styles.noteCard}><Text style={styles.cardTitle}>What this does not change</Text><Text style={styles.cardBody}>Clearing the batch summary does not delete queued reports, report drafts, submission receipts, server history, or activity events.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {
  return StyleSheet.create({
    content: { paddingTop: 18, paddingBottom: 34, gap: 13 },
    back: { alignSelf: "flex-start", paddingVertical: 4 },
    backText: { color: colors.primary, fontSize: scaleTextSize(13, largeText), fontWeight: "900" },
    eyebrow: { color: colors.primary, fontSize: scaleTextSize(11, largeText), fontWeight: "800", letterSpacing: 1.1, marginTop: 12 },
    title: { color: colors.foreground, fontSize: scaleTextSize(29, largeText), fontWeight: "800" },
    subtitle: { color: colors.muted, fontSize: scaleTextSize(13, largeText), lineHeight: 19 },
    boundaryCard: { backgroundColor: "#E8F5F7", borderColor: "#B8E3E8", borderWidth: 1, borderRadius: 17, padding: 16, gap: 5 },
    cardTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "900" },
    cardBody: { color: colors.muted, fontSize: scaleTextSize(12, largeText), lineHeight: 18 },
    sectionTitle: { color: colors.foreground, fontSize: scaleTextSize(15, largeText), fontWeight: "900", marginTop: 5 },
    recordsCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, paddingHorizontal: 15 },
    recordRow: { minHeight: 74, flexDirection: "row", alignItems: "center", gap: 12 },
    recordCopy: { flex: 1, gap: 4 },
    recordTitle: { color: colors.foreground, fontSize: scaleTextSize(14, largeText), fontWeight: "800" },
    recordDetail: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 },
    recordStatus: { color: colors.primary, fontSize: scaleTextSize(10, largeText), fontWeight: "900" },
    divider: { height: 1, backgroundColor: colors.border },
    clearButton: { minHeight: 34, borderColor: colors.error + "55", borderWidth: 1, borderRadius: 9, paddingHorizontal: 11, justifyContent: "center" },
    clearText: { color: colors.error, fontSize: scaleTextSize(11, largeText), fontWeight: "900" },
    noteCard: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 17, padding: 16, gap: 5 },
    undoBanner: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 12 },
    undoCopy: { flex: 1, gap: 2 },
    undoTitle: { color: colors.foreground, fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    undoBody: { color: colors.muted, fontSize: scaleTextSize(11, largeText), lineHeight: 16 },
    undoButton: { minHeight: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", paddingHorizontal: 14 },
    undoButtonText: { color: "#FFFFFF", fontSize: scaleTextSize(12, largeText), fontWeight: "900" },
    pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
  });
}
