import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

type AccessibilityContextValue = {
  largeText: boolean;
  setLargeText: (enabled: boolean) => void;
};

const AccessibilityContext = createContext<AccessibilityContextValue | null>(null);

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [largeText, setLargeTextState] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem("guardian.setting.largeText")
      .then((value) => {
        if (value === "true" || value === "false") setLargeTextState(value === "true");
      })
      .catch(() => undefined);
  }, []);

  const setLargeText = useCallback((enabled: boolean) => {
    setLargeTextState(enabled);
    AsyncStorage.setItem("guardian.setting.largeText", String(enabled)).catch(() => undefined);
  }, []);

  const value = useMemo(() => ({ largeText, setLargeText }), [largeText, setLargeText]);
  return <AccessibilityContext.Provider value={value}>{children}</AccessibilityContext.Provider>;
}

export function useAccessibilityPreferences(): AccessibilityContextValue {
  const context = useContext(AccessibilityContext);
  if (!context) throw new Error("useAccessibilityPreferences must be used within AccessibilityProvider");
  return context;
}

export function scaleTextSize(size: number, largeText: boolean): number {
  return largeText ? Math.round(size * 1.18) : size;
}
