export type GuardianExportReport = {
  reportId: number;
  clientRequestId: string;
  category: string;
  severity: string;
  description: string;
  locationText: string;
  latitude: string | null;
  longitude: string | null;
  accuracy: string | null;
  status: string;
  source: string;
  createdAt: Date | string;
  updatedAt: Date | string;
  hasPhotoAttachment: boolean;
};

export function buildGuardianExportFilename(date = new Date()) {
  return `guardian-report-data-${date.toISOString().slice(0, 10)}.json`;
}

export function serializeGuardianExport(payload: { exportedAt: Date | string; account: { userId: number; email: string | null }; reports: GuardianExportReport[] }) {
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: payload.exportedAt,
    account: payload.account,
    reports: payload.reports.map((report) => ({
      ...report,
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : report.createdAt,
      updatedAt: report.updatedAt instanceof Date ? report.updatedAt.toISOString() : report.updatedAt,
    })),
  }, null, 2);
}
