export type GuardianReportDraft = {
  category: string;
  severity: string;
  description: string;
  location: string;
};

export function validateGuardianReport(draft: GuardianReportDraft) {
  const errors: Partial<Record<keyof GuardianReportDraft, string>> = {};
  if (!draft.category) errors.category = "Choose a category.";
  if (!draft.description.trim()) errors.description = "Add a short description.";
  if (!draft.location.trim()) errors.location = "Add a landmark, intersection, or address.";
  return errors;
}

export function buildSmsReportMessage(draft: GuardianReportDraft) {
  return `${draft.category || "SAFETY"} at ${draft.location || "my location"}: ${draft.description || "Please review this concern."}`;
}
