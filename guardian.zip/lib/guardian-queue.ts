import AsyncStorage from "@react-native-async-storage/async-storage";

import type { GuardianReportDraft } from "@/lib/guardian-report";

export const QUEUED_REPORT_KEY = "guardian.report.queued.v1";
export const OUTBOX_ACTIVITY_KEY = "guardian.outbox.activity.v1";
export const MAX_AUTOMATIC_RETRIES = 3;
export const AUTO_RETRY_PAUSED_KEY = "guardian.outbox.autoRetryPaused.v1";
export const OUTBOX_ACTIVITY_SORT_KEY = "guardian.outbox.activitySort.v1";
export const OUTBOX_BATCH_SUMMARY_KEY = "guardian.outbox.batchSummary.v1";

export type GuardianActivityType = "queued" | "retry_started" | "retry_failed" | "submitted" | "cleared" | "undo" | "auto_retry_paused" | "auto_retry_resumed" | "auto_retry_exhausted" | "retry_confirmed" | "retry_cancelled" | "batch_retry_started" | "batch_retry_completed" | "batch_retry_cancelled" | "location_label_cleared" | "location_label_restored" | "location_revised" | "external_map_opened" | "ai_feedback_reason_saved";

export type GuardianActivityEvent = {
  id: string;
  type: GuardianActivityType;
  at: string;
  clientRequestId?: string;
};

export type GuardianBatchSummary = {
  completedAt: string;
  total: number;
  submitted: number;
  failed: number;
  remaining: number;
  cancelled: boolean;
};

export type GuardianQueuedDraft = GuardianReportDraft & {
  photoUri?: string;
  latitude?: number;
  longitude?: number;
  accuracy?: number;
  locationCapturedAt?: number;
  locationRefreshedAt?: number;
  locationSource?: "map" | "saved-without-map";
};

export type GuardianQueuedReport = {
  draft: GuardianQueuedDraft;
  clientRequestId: string;
  queuedAt: string;
  retryCount: number;
  lastAttemptAt?: string;
  lastFailureReason?: string;
  nextRetryAt?: string;
  autoRetryExhausted?: boolean;
  automaticRetryCount?: number;
  manualRetryCount?: number;
};

export function parseQueuedReports(raw: string | null): GuardianQueuedReport[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as GuardianQueuedReport | GuardianQueuedReport[];
    const reports = Array.isArray(parsed) ? parsed : [parsed];
    return reports.filter(isQueuedReport).map(normalizeQueuedReport);
  } catch {
    return [];
  }
}

function normalizeQueuedReport(report: GuardianQueuedReport): GuardianQueuedReport {
  return {
    ...report,
    retryCount: typeof report.retryCount === "number" ? report.retryCount : 0,
    nextRetryAt: typeof report.nextRetryAt === "string" ? report.nextRetryAt : undefined,
    autoRetryExhausted: report.autoRetryExhausted === true,
    automaticRetryCount: typeof report.automaticRetryCount === "number" ? report.automaticRetryCount : 0,
    manualRetryCount: typeof report.manualRetryCount === "number" ? report.manualRetryCount : 0,
  };
}

function isQueuedReport(value: unknown): value is GuardianQueuedReport {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<GuardianQueuedReport>;
  return typeof candidate.clientRequestId === "string" && typeof candidate.queuedAt === "string" && Boolean(candidate.draft);
}

export async function readQueuedReports() {
  return parseQueuedReports(await AsyncStorage.getItem(QUEUED_REPORT_KEY));
}

export async function readAutoRetryPaused() {
  return (await AsyncStorage.getItem(AUTO_RETRY_PAUSED_KEY)) === "true";
}

export async function readActivitySortNewest() {
  return (await AsyncStorage.getItem(OUTBOX_ACTIVITY_SORT_KEY)) !== "oldest";
}

export async function setActivitySortNewest(newest: boolean) {
  await AsyncStorage.setItem(OUTBOX_ACTIVITY_SORT_KEY, newest ? "newest" : "oldest");
  return newest;
}

export async function readBatchSummary(): Promise<GuardianBatchSummary | null> {
  const raw = await AsyncStorage.getItem(OUTBOX_BATCH_SUMMARY_KEY);
  try {
    const parsed = raw ? JSON.parse(raw) as Partial<GuardianBatchSummary> : null;
    if (!parsed || typeof parsed.completedAt !== "string" || typeof parsed.total !== "number" || typeof parsed.submitted !== "number" || typeof parsed.failed !== "number" || typeof parsed.remaining !== "number" || typeof parsed.cancelled !== "boolean") return null;
    return parsed as GuardianBatchSummary;
  } catch {
    return null;
  }
}

export async function setBatchSummary(summary: GuardianBatchSummary) {
  await AsyncStorage.setItem(OUTBOX_BATCH_SUMMARY_KEY, JSON.stringify(summary));
  return summary;
}

export async function clearBatchSummary() {
  await AsyncStorage.removeItem(OUTBOX_BATCH_SUMMARY_KEY);
}

export async function setAutoRetryPaused(paused: boolean) {
  await AsyncStorage.setItem(AUTO_RETRY_PAUSED_KEY, paused ? "true" : "false");
  return paused;
}

export async function upsertQueuedReport(report: GuardianQueuedReport) {
  const queue = await readQueuedReports();
  const next = [...queue.filter((item) => item.clientRequestId !== report.clientRequestId), report];
  await AsyncStorage.setItem(QUEUED_REPORT_KEY, JSON.stringify(next));
  return next;
}

export async function appendActivityEvent(type: GuardianActivityType, clientRequestId?: string) {
  const existing = await AsyncStorage.getItem(OUTBOX_ACTIVITY_KEY);
  let events: GuardianActivityEvent[] = [];
  try {
    const parsed = existing ? JSON.parse(existing) : [];
    if (Array.isArray(parsed)) events = parsed.filter((item): item is GuardianActivityEvent => Boolean(item && typeof item.id === "string" && typeof item.type === "string" && typeof item.at === "string"));
  } catch {
    events = [];
  }
  const event: GuardianActivityEvent = { id: `activity-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, type, at: new Date().toISOString(), clientRequestId };
  await AsyncStorage.setItem(OUTBOX_ACTIVITY_KEY, JSON.stringify([event, ...events].slice(0, 20)));
}

export async function readActivityEvents() {
  const raw = await AsyncStorage.getItem(OUTBOX_ACTIVITY_KEY);
  try {
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((item): item is GuardianActivityEvent => Boolean(item && typeof item.id === "string" && typeof item.type === "string" && typeof item.at === "string")) : [];
  } catch {
    return [];
  }
}

export async function removeQueuedReport(clientRequestId: string) {
  const next = (await readQueuedReports()).filter((item) => item.clientRequestId !== clientRequestId);
  if (next.length) await AsyncStorage.setItem(QUEUED_REPORT_KEY, JSON.stringify(next));
  else await AsyncStorage.removeItem(QUEUED_REPORT_KEY);
  return next;
}
