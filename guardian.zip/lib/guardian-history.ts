export type GuardianHistoryReport = {
  category: string;
  severity: string;
  status: string;
  clientRequestId: string;
  createdAt: Date | string;
  updatedAt: Date | string;
};

export function filterAndSortReports(reports: GuardianHistoryReport[], severityFilter: string, sortOrder: "newest" | "oldest") {
  return [...reports]
    .filter((report) => severityFilter === "All" || report.severity === severityFilter)
    .sort((a, b) => {
      const delta = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      return sortOrder === "newest" ? -delta : delta;
    });
}
