/** @type {const} */
const themeColors = {
  primary: { light: '#0E7490', dark: '#67D1E6' },
  background: { light: '#F7F8FA', dark: '#0B1220' },
  surface: { light: '#FFFFFF', dark: '#142033' },
  foreground: { light: '#0B1F33', dark: '#F4F7FA' },
  muted: { light: '#5B6B7A', dark: '#A8B6C4' },
  border: { light: '#D7E0E8', dark: '#2C3D52' },
  success: { light: '#1F7A4D', dark: '#68D391' },
  warning: { light: '#D97706', dark: '#F6C453' },
  error: { light: '#C62828', dark: '#FF8D8D' },
};

module.exports = { themeColors };
