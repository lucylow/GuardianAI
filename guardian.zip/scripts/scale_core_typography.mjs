import fs from "node:fs";

const files = [
  "app/(tabs)/index.tsx",
  "components/guardian/alerts-screen.tsx",
  "components/guardian/report-screen.tsx",
  "components/guardian/resources-screen.tsx",
  "components/guardian/profile-screen.tsx",
];

for (const file of files) {
  const source = fs.readFileSync(file, "utf8");
  const transformed = source.replace(/fontSize: (\d+(?:\.\d+)?)/g, "fontSize: scaleTextSize($1, largeText)");
  fs.writeFileSync(file, transformed);
}
