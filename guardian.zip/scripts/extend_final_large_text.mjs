import fs from "node:fs";

const configs = [
  { file: "app/alert-detail.tsx", importAfter: 'import { useColors } from "@/hooks/use-colors";', importText: 'import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";', oldHook: '  const colors = useColors();\n  const styles = useMemo(() => createStyles(colors), [colors]);', newHook: '  const colors = useColors();\n  const { largeText } = useAccessibilityPreferences();\n  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);' },
  { file: "app/emergency.tsx", importAfter: 'import { useColors } from "@/hooks/use-colors";', importText: 'import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";', oldHook: '  const colors = useColors();\n  const styles = useMemo(() => createStyles(colors), [colors]);', newHook: '  const colors = useColors();\n  const { largeText } = useAccessibilityPreferences();\n  const styles = useMemo(() => createStyles(colors, largeText), [colors, largeText]);' },
  { file: "app/support.tsx", importAfter: 'import { useColors } from "@/hooks/use-colors";', importText: 'import { useAccessibilityPreferences, scaleTextSize } from "@/lib/accessibility-provider";', oldHook: '  const colors = useColors();\n  const styles = createStyles(colors);', newHook: '  const colors = useColors();\n  const { largeText } = useAccessibilityPreferences();\n  const styles = createStyles(colors, largeText);' },
];

for (const config of configs) {
  let source = fs.readFileSync(config.file, "utf8");
  if (!source.includes(config.importText)) source = source.replace(config.importAfter, `${config.importAfter}\n${config.importText}`);
  source = source.replace(config.oldHook, config.newHook);
  source = source.replace('function createStyles(colors: ReturnType<typeof useColors>) {', 'function createStyles(colors: ReturnType<typeof useColors>, largeText: boolean) {');
  source = source.replace(/fontSize: (\d+(?:\.\d+)?)/g, "fontSize: scaleTextSize($1, largeText)");
  fs.writeFileSync(config.file, source);
}
